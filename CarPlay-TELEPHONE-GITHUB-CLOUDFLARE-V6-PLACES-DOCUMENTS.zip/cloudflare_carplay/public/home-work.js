(function(){
  var path=location.pathname.replace(/\/+$/,'')||'/';
  function homeExtras(){
    var grid=document.querySelector('.grid');if(!grid||document.getElementById('homeWorkLinks'))return;
    var links=document.createElement('div');links.id='homeWorkLinks';links.className='homeWorkLinks';
    links.innerHTML='<a class="homeWorkBtn place" href="/ou-trouver-place.html"><span class="homeWorkIcon">📍</span><span>OÙ TROUVER UNE PLACE</span></a><a class="homeWorkBtn docs" href="/documents-travail.html"><span class="homeWorkIcon">📄</span><span>DOCUMENTS DE TRAVAIL</span></a>';
    grid.insertAdjacentElement('beforebegin',links);
    var article=document.createElement('button');article.id='homeArticleBtn';article.type='button';article.innerHTML='<span>🧰</span>ARTICLE<br>DE TRAVAIL';
    var modal=document.createElement('div');modal.id='homeArticleModal';modal.innerHTML='<div class="panel"><h2>🧰 Article de travail</h2><p>Ici, je rajouterai tout ce qui concerne le travail : carnet de factures, cartes de visite, modification des papiers de travail, décennale, etc.</p><button type="button">FERMER</button></div>';
    article.onclick=function(){modal.classList.add('open')};modal.onclick=function(e){if(e.target===modal||e.target.tagName==='BUTTON')modal.classList.remove('open')};document.body.appendChild(article);document.body.appendChild(modal);
  }
  function belgiqueLock(){
    if(!/documents-travail\.html$/i.test(path))return;var card=document.getElementById('papierBelgiqueCard');if(!card)return;
    var oldLock=document.getElementById('belgiqueLock'),protectedBox=document.getElementById('belgiqueProtected');if(oldLock)oldLock.style.display='none';if(protectedBox)protectedBox.style.display='none';
    var box=document.createElement('div');box.className='belgiqueContactLock';box.innerHTML='<strong>🔒 PAPIER BELGIQUE BLOQUÉ</strong><p>Contactez Steve Suzon sur Snapchat pour l’ouverture des papiers.</p>';card.appendChild(box);
    card.onclick=function(){box.animate([{transform:'scale(1)'},{transform:'scale(1.03)'},{transform:'scale(1)'}],{duration:380})};
  }
  function marketsUpdateOnly(){
    if(path!=='/'&&path!=='/index.html')return;
    var menu=document.getElementById('updateMenu');if(!menu)return;
    var head=menu.previousElementSibling,headText=head&&head.querySelector('span');if(headText)headText.textContent='🔄 Mise à jour des marchés';
    menu.innerHTML='<button id="marketUpdateBtn" type="button">METTRE À JOUR LES MARCHÉS</button><div class="settingNote" id="marketUpdateStatus">Télécharge uniquement les marchés de France et de Belgique dans cet appareil.</div><button id="appUpdateBtn" type="button">METTRE À JOUR L’APPLICATION</button><div class="settingNote">Pour installer les nouvelles fonctions et les modifications complètes de l’application.</div>';
    document.getElementById('marketUpdateBtn').onclick=async function(){
      var btn=this,status=document.getElementById('marketUpdateStatus');btn.disabled=true;btn.textContent='MISE À JOUR EN COURS…';
      try{
        var files=['/market-data-fr.js','/market-data-be.js','/market-final.js','/market-clean.js','/markets-final.css','/markets-clean.css'];
        var stamp=Date.now();var responses=await Promise.all(files.map(function(file){return fetch(file+'?market_update='+stamp,{cache:'reload'});}));
        if(responses.some(function(r){return !r.ok;}))throw new Error('download');
        var live=await fetch('/api/markets?market_update='+stamp,{cache:'no-store'});if(!live.ok)throw new Error('download');var liveData=await live.json();
        localStorage.setItem('server_markets',JSON.stringify(liveData.markets||[]));
        localStorage.setItem('markets_last_update',new Date().toISOString());
        status.textContent='Marchés France et Belgique enregistrés dans cet appareil.';alert('Mise à jour des marchés terminée.');
      }catch(e){status.textContent='Mise à jour impossible. Vérifie la connexion Internet.';alert(status.textContent);}
      btn.disabled=false;btn.textContent='METTRE À JOUR LES MARCHÉS';
    };
    document.getElementById('appUpdateBtn').onclick=function(){
      location.href='https://raw.githubusercontent.com/stevesuzon/Carlplay-apk/main/LATEST-APK.apk?update='+Date.now();
    };
  }
  if(path==='/'||path==='/index.html'){homeExtras();marketsUpdateOnly()}belgiqueLock();
})();
