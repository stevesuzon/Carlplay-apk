PROJET APK — LES 4 PAUVRES DIABLES

Ce ZIP contient UNIQUEMENT le projet Android APK et GitHub Actions.
Le mode Web n'est pas inclus et n'est pas modifie.

Depuis iPhone :
1. Cree ou ouvre un depot GitHub.
2. Envoie TOUT le contenu de ce dossier a la racine du depot.
   Important : le dossier cache .github doit aussi etre envoye.
3. Ouvre l'onglet Actions du depot.
4. Ouvre le workflow "Compiler APK".
5. Appuie sur "Run workflow" si necessaire.
6. Quand le workflow est termine, ouvre son execution.
7. Dans Artifacts, telecharge "Les4PauvresDiables-APK".
8. Le ZIP telecharge contient app-debug.apk.

Le workflow se lance aussi automatiquement quand les fichiers sont envoyes sur la branche main ou master.
