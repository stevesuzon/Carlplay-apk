(function(){
  var path=location.pathname.replace(/\/+$/,'')||'/';
  function removeBigArticleButton(){
    ['homeArticleBtn','homeArticleModal'].forEach(function(id){var el=document.getElementById(id);if(el)el.remove()});
    document.querySelectorAll('.articleTile').forEach(function(el){el.remove()});
    document.querySelectorAll('.grid a,.grid button,.grid .card,#homeWorkLinks a,#homeWorkLinks button').forEach(function(el){
      if(el.id==='directArticle')return;
      var t=(el.textContent||'').replace(/\s+/g,' ').trim().toUpperCase();
      if(t==='ARTICLE DE TRAVAIL'||t.indexOf('ARTICLE DE TRAVAIL')!==-1){el.remove()}
    });
  }
  function homeExtras(){
    removeBigArticleButton();
    var grid=document.querySelector('.grid');if(!grid)return;
    /* Le gros bouton Article de travail est volontairement supprimé. Le petit bouton flottant #directArticle reste le seul accès. */
  }
  function belgiqueLock(){
    if(!/documents-travail\.html$/i.test(path))return;var card=document.getElementById('papierBelgiqueCard');if(!card)return;
    var oldLock=document.getElementById('belgiqueLock'),protectedBox=document.getElementById('belgiqueProtected');if(oldLock)oldLock.style.display='none';if(protectedBox)protectedBox.style.display='none';
    var box=document.createElement('div');box.className='belgiqueContactLock';box.innerHTML='<strong>🔒 PAPIER BELGIQUE BLOQUÉ</strong><p>Contactez Steve Suzon sur Snapchat pour l’ouverture des papiers.</p>';card.appendChild(box);
    card.onclick=function(){box.animate([{transform:'scale(1)'},{transform:'scale(1.03)'},{transform:'scale(1)'}],{duration:380})};
  }
  function syncMarketsAutomatically(){
    if(path!=='/'&&path!=='/index.html')return;
    var menu=document.getElementById('updateMenu'),row=menu&&menu.closest('.settingRow');if(row)row.remove();
    if(!navigator.onLine)return;
    var stamp=Date.now();
    fetch('/api/markets?automatic_update='+stamp,{cache:'no-store'}).then(function(r){if(!r.ok)throw new Error('sync');return r.json()}).then(function(j){
      localStorage.setItem('server_markets',JSON.stringify(j.markets||[]));
      localStorage.setItem('markets_last_update',new Date().toISOString());
    }).catch(function(){});
  }
  if(path==='/'||path==='/index.html'){
    homeExtras();syncMarketsAutomatically();
    addEventListener('load',removeBigArticleButton);
    setTimeout(removeBigArticleButton,250);
    setTimeout(removeBigArticleButton,1200);
  }
  belgiqueLock();
})();
