(function () {
  if (document.getElementById("weatherBubble")) return;

  var style = document.createElement("style");
  style.textContent = "#weatherBubble{position:fixed;z-index:2147483000;top:max(4px,env(safe-area-inset-top));left:50%;right:auto;transform:translateX(-50%);box-sizing:border-box;width:auto;max-width:calc(100vw - 20px);min-width:280px;padding:7px 13px;border-radius:18px;border:2px solid #f39b19;background:rgba(5,10,18,.96);color:#fff;text-align:center;font:900 15px/1.15 Arial;box-shadow:0 5px 14px #0008;overflow:hidden;transition:opacity .18s ease,transform .18s ease}#weatherBubble .weatherMain{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#weatherBubble .weatherDay{margin-top:3px;font-size:12px;color:#fff}body:not(.homePage){padding-top:62px!important}body.weatherScrolled #weatherBubble{opacity:0!important;pointer-events:none!important;transform:translate(-50%,-90px)!important}@media(max-width:720px){#weatherBubble{top:max(3px,env(safe-area-inset-top));max-width:calc(100vw - 18px);min-width:0;width:auto;padding:6px 10px;font-size:12px}#weatherBubble .weatherDay{font-size:10px}}"+
  "#dangerWeatherOverlay{position:fixed;inset:0;z-index:2147483646;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;padding:18px;font-family:Arial,sans-serif}#dangerWeatherOverlay[hidden]{display:none!important}#dangerWeatherCard{width:min(680px,94vw);border-radius:28px;padding:25px 22px;text-align:center;color:#fff;box-shadow:0 15px 50px #000;border:4px solid #ffb000;background:linear-gradient(145deg,#3b1700,#c45a00)}#dangerWeatherOverlay.level2 #dangerWeatherCard{border-color:#ff4b32;background:linear-gradient(145deg,#410000,#b51515)}#dangerWeatherOverlay.level3 #dangerWeatherCard{border-color:#fff;background:linear-gradient(145deg,#210000,#840000);box-shadow:0 0 0 6px #ff1e1e,0 18px 55px #000}#dangerWeatherTitle{font-size:clamp(30px,7vw,52px);font-weight:1000;line-height:1.02;margin:0 0 13px}#dangerWeatherSpeed{font-size:clamp(38px,10vw,74px);font-weight:1000;margin:8px 0}#dangerWeatherText{font-size:clamp(19px,4vw,28px);font-weight:900;line-height:1.25}#dangerWeatherSub{margin-top:14px;font-size:14px;font-weight:800;opacity:.9}#dangerWeatherHint{margin-top:18px;font-size:13px;font-weight:800;opacity:.8}";
  document.head.appendChild(style);

  var bubble = document.createElement("div");
  bubble.id = "weatherBubble";
  bubble.dataset.weather = localStorage.getItem("last_weather_text") || "🌤️ MÉTÉO — EN ATTENTE INTERNET/GPS";
  document.body.appendChild(bubble);

  var overlay=document.createElement('div');overlay.id='dangerWeatherOverlay';overlay.hidden=true;
  overlay.innerHTML='<div id="dangerWeatherCard"><div id="dangerWeatherTitle"></div><div id="dangerWeatherSpeed"></div><div id="dangerWeatherText"></div><div id="dangerWeatherSub"></div><div id="dangerWeatherHint">Touchez à côté de cette alerte pour la fermer.</div></div>';
  document.body.appendChild(overlay);
  overlay.addEventListener('click',function(e){if(e.target===overlay){overlay.hidden=true;overlay.className='';}});
  document.getElementById('dangerWeatherCard').addEventListener('click',function(e){e.stopPropagation();});

  function render() {
    var n = new Date();
    var jour = n.toLocaleDateString("fr-FR", {weekday:"long"}).toUpperCase();
    var court = String(n.getDate()).padStart(2,"0") + "/" + String(n.getMonth()+1).padStart(2,"0") + "/" + String(n.getFullYear()).slice(-2);
    bubble.innerHTML = '<div class="weatherMain">' + bubble.dataset.weather + '</div><div class="weatherDay">' + jour + ' / ' + court + '</div>';
  }

  function message(percent, code) {
    percent = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
    var icon = code >= 51 && code <= 99 ? "🌧️" : code <= 1 ? "☀️" : "⛅";
    var text = percent === 0 ? "TRÈS BON JOUR POUR TRAVAILLER" : percent < 60 ? "TU PEUX ENCORE ALLER TRAVAILLER" : percent < 80 ? "T’ES VAILLANT" : "RESTE CHEZ TOI, C’EST MIEUX";
    return icon + " " + percent + " % — " + text;
  }

  function refresh() {
    if (!navigator.onLine || !navigator.geolocation) { render(); return; }
    navigator.geolocation.getCurrentPosition(function (position) {
      var url = "https://api.open-meteo.com/v1/forecast?latitude=" + position.coords.latitude + "&longitude=" + position.coords.longitude + "&current=weather_code&hourly=precipitation_probability&forecast_days=1&timezone=auto";
      fetch(url).then(function (response) { return response.json(); }).then(function (data) {
        var percent = 0;
        var code = data.current && data.current.weather_code || 0;
        if (data.hourly && data.hourly.precipitation_probability) {
          var values = data.hourly.precipitation_probability;
          var times = data.hourly.time || [];
          var now = Date.now();
          var closest = Infinity;
          for (var i = 0; i < times.length; i++) {
            var distance = Math.abs(new Date(times[i]).getTime() - now);
            if (distance < closest) { closest = distance; percent = values[i]; }
          }
        }
        var value = message(percent, code);
        bubble.dataset.weather = value;
        localStorage.setItem("last_weather_text", value);
        render();
      }).catch(function () { render(); });
    }, function () { render(); }, { enableHighAccuracy: false, timeout: 8000, maximumAge: 600000 });
  }

  function severityFromWind(kmh){return kmh>=110?3:kmh>=90?2:1}
  function showDanger(kind,maxGust,hailSize){
    var title=document.getElementById('dangerWeatherTitle'),speed=document.getElementById('dangerWeatherSpeed'),text=document.getElementById('dangerWeatherText'),sub=document.getElementById('dangerWeatherSub');
    overlay.className='';
    if(kind==='hail'){
      overlay.classList.add('level'+(hailSize&&hailSize>=4?3:hailSize&&hailSize>=2?2:1));
      title.textContent='⚠️ RISQUE DE GRÊLE'; speed.textContent='';
      text.innerHTML='Préparez les <strong>filets anti-grêle</strong> et protégez votre véhicule, votre caravane et votre matériel.';
      sub.textContent=hailSize?'Grêlons possibles : environ '+hailSize+' cm.':'Taille des grêlons non précisée : aucune estimation n’est inventée.';
    }else{
      var sev=severityFromWind(maxGust); overlay.classList.add('level'+sev);
      title.textContent=sev>=2?'🔴 VENT VIOLENT':'⚠️ VENT FORT'; speed.textContent=Math.round(maxGust)+' KM/H';
      text.textContent='Rafales annoncées près de votre emplacement enregistré. Pensez à sécuriser votre véhicule, votre caravane et votre matériel.';
      sub.textContent='Alerte affichée uniquement à partir de 70 km/h.';
    }
    overlay.hidden=false;
  }

  var lastDangerCheck=0;
  function checkSavedPlaceDanger(force){
    if(!navigator.onLine)return;
    var lat=parseFloat(localStorage.getItem('return_lat')),lon=parseFloat(localStorage.getItem('return_lon'));
    if(!Number.isFinite(lat)||!Number.isFinite(lon))return;
    var now=Date.now();if(!force&&now-lastDangerCheck<5*60*1000)return;lastDangerCheck=now;
    var u='https://api.open-meteo.com/v1/forecast?latitude='+encodeURIComponent(lat)+'&longitude='+encodeURIComponent(lon)+'&hourly=weather_code,wind_gusts_10m&forecast_days=2&timezone=auto&wind_speed_unit=kmh';
    fetch(u).then(function(r){if(!r.ok)throw new Error('weather');return r.json()}).then(function(d){
      var times=d.hourly&&d.hourly.time||[],codes=d.hourly&&d.hourly.weather_code||[],gusts=d.hourly&&d.hourly.wind_gusts_10m||[];
      var end=now+12*3600*1000,maxG=0,hail=false;
      for(var i=0;i<times.length;i++){var t=new Date(times[i]).getTime();if(t<now-3600000||t>end)continue;var g=Number(gusts[i])||0;if(g>maxG)maxG=g;var c=Number(codes[i]);if(c===96||c===99)hail=true;}
      // Priority to hail: the requested anti-hail message is more specific.
      if(hail) showDanger('hail',0,null); else if(maxG>=70) showDanger('wind',maxG,null);
    }).catch(function(){});
  }

  function scrollState(){ document.body.classList.toggle('weatherScrolled',(window.scrollY||0)>45); }
  addEventListener('scroll',scrollState,{passive:true});
  addEventListener('focus',function(){checkSavedPlaceDanger(true)});
  document.addEventListener('visibilitychange',function(){if(!document.hidden)checkSavedPlaceDanger(true)});
  scrollState(); render(); refresh(); checkSavedPlaceDanger(true);
  setInterval(render,30000); setInterval(refresh,900000); setInterval(function(){checkSavedPlaceDanger(false)},900000);
  addEventListener("online", function(){refresh();checkSavedPlaceDanger(true)});
})();
