(function () {
  if ("serviceWorker" in navigator) addEventListener("load", function () { navigator.serviceWorker.register("/sw.js").catch(function () {}); });
  var KEY = "carplay_shared_subscription";
  function id() {
    var v = localStorage.getItem("carplay_device_id");
    if (!v) { v = (crypto.randomUUID ? crypto.randomUUID() : "dev-" + Date.now() + "-" + Math.random().toString(36).slice(2)); localStorage.setItem("carplay_device_id", v); }
    return v;
  }
  function saved() { try { return JSON.parse(localStorage.getItem(KEY) || "null"); } catch (_) { return null; } }
  function valid(s) { return s && (s.lifetime || (s.expiresAt && Date.parse(s.expiresAt) > Date.now())); }
  function overlay() {
    if (document.getElementById("subscriptionGate")) return;
    var box = document.createElement("div"); box.id = "subscriptionGate";
    box.innerHTML = '<div class="sub-card"><h1>ACTIVER L’APPLICATION</h1><p>Entrez votre code d’abonnement à 6 chiffres.</p><input id="subCode" inputmode="numeric" maxlength="6" placeholder="000 000"><div class="sub-types"><button data-type="autoradio">AUTORADIO</button><button data-type="phone">TÉLÉPHONE</button></div><button id="subActivate">ACTIVER</button><div id="subMessage"></div><small>Le même code fonctionne sur 1 autoradio et 1 téléphone Android ou iPhone.</small></div>';
    document.documentElement.appendChild(box);
    var deviceType = /Android/i.test(navigator.userAgent) && Math.min(screen.width, screen.height) >= 600 ? "autoradio" : "phone";
    box.querySelectorAll("[data-type]").forEach(function (b) { b.onclick = function () { deviceType = b.dataset.type; box.querySelectorAll("[data-type]").forEach(function (x) { x.classList.toggle("chosen", x === b); }); }; if (b.dataset.type === deviceType) b.classList.add("chosen"); });
    box.querySelector("#subActivate").onclick = function () {
      var code = box.querySelector("#subCode").value.replace(/\D/g, ""); var msg = box.querySelector("#subMessage");
      if (code.length !== 6) { msg.textContent = "ENTREZ EXACTEMENT 6 CHIFFRES"; return; }
      msg.textContent = "VÉRIFICATION…";
      fetch("/api/activate", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ code: code, deviceId: id(), deviceType: deviceType }) })
        .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw j; return j; }); })
        .then(function (j) { localStorage.setItem(KEY, JSON.stringify(j)); msg.textContent = "ABONNEMENT ACTIVÉ"; setTimeout(function () { box.remove(); }, 700); })
        .catch(function (e) { msg.textContent = e.error === "ABONNEMENT_EXPIRE" ? "ABONNEMENT EXPIRÉ" : e.error && e.error.indexOf("DEJA_UTILISE") > -1 ? "CET EMPLACEMENT EST DÉJÀ UTILISÉ" : "CODE INCORRECT OU INTERNET INDISPONIBLE"; });
    };
  }
  document.addEventListener("DOMContentLoaded", function () { if (!valid(saved())) overlay(); });
})();

