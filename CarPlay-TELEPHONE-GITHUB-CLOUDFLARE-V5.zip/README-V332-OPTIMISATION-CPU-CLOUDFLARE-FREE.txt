COUTEAU SUISSE — V332 — OPTIMISATION CPU CLOUDFLARE FREE
Date : 21/09/2026

PROBLÈME TRAITÉ
Cloudflare signalait que le Worker dépassait la limite CPU du forfait gratuit au moins 100 fois sur 24 h.
Le forfait Workers Free autorise 10 ms de CPU par requête HTTP et 10 ms par Cron Trigger.

CAUSES IMPORTANTES TROUVÉES DANS LE ZIP
1. wrangler.jsonc utilisait assets.run_worker_first=true : CHAQUE fichier statique (HTML, JS, CSS, images, etc.) passait d’abord par le gros Worker de plus de 400 Ko.
2. Les pages HTML étaient transformées à la volée avec HTMLRewriter, y compris index.html (~223 Ko).
3. Le Cron horaire lançait un import Jours-de-Marché/Brocabrac pouvant charger et analyser de nombreuses pages HTML puis faire de nombreux upserts D1. Ce traitement n’est pas adapté à la limite CPU de 10 ms du forfait gratuit.

CORRECTIONS V332
- Worker-first devient sélectif : /api/*, /download-autoradio.apk, /sw.js et /app-version.json seulement.
- Les fichiers statiques sont servis directement par Cloudflare Static Assets sans exécuter src/index.js.
- Les CSS/JS communs auparavant ajoutés par HTMLRewriter sont maintenant intégrés directement dans les pages HTML concernées.
- L’injection market-live et la correction file:///android_asset/ sont également intégrées dans les HTML statiques.
- Le Cron reste déclaré mais le scraping lourd ne démarre que si la variable Cloudflare MARKET_AUTO_REFRESH=1 est définie. Sans cette variable, le Cron sort immédiatement et ne consomme pratiquement pas de CPU.
- Passage application/service worker en V332 pour forcer la mise à jour du cache.

DONNÉES CONSERVÉES
Aucune donnée D1, photo R2, abonnement, point concours, fiche marché, adresse, devis, fiche d’achat, station ou préférence utilisateur n’est supprimée.
Les marchés déjà présents restent disponibles. Seul le rafraîchissement serveur automatique lourd est mis en pause par défaut sur le forfait gratuit.

POUR RÉACTIVER L’IMPORT AUTOMATIQUE
Après passage à Workers Paid, définir la variable d’environnement MARKET_AUTO_REFRESH=1. Le code d’import existant reste présent dans src/index.js.

VÉRIFICATIONS EFFECTUÉES
- Syntaxe JavaScript src/index.js : OK.
- Syntaxe JavaScript des fichiers public/*.js : contrôlée.
- JSON app-version.json et wrangler.jsonc : contrôlés après retrait des commentaires JSONC pour validation structurelle.
- Les pages exclues auparavant du HTMLRewriter (admin.html, import-marches.html, installer.html) restent exclues.
