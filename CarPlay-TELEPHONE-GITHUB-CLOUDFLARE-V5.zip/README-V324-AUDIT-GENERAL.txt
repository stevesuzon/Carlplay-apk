COUTEAU SUISSE — V324 — AUDIT GÉNÉRAL / CORRECTIFS DE COHÉRENCE

Base : V323.

Contrôles effectués :
- syntaxe de tous les fichiers JavaScript du projet ;
- syntaxe des scripts JavaScript intégrés dans les pages HTML ;
- références locales HTML (scripts, CSS, images, liens) ;
- fichiers mis en cache par le Service Worker ;
- doublons d'identifiants HTML ;
- cohérence des routes API principales ;
- logique d'import progressif Jours-de-Marché : ajout uniquement, jour inclus dans l'empreinte, aucune suppression des marchés locaux absents de la source ;
- conservation des compléments brocantes / foires / vide-greniers déjà présents ;
- contrôle du système « Effacer emplacement » : confirmation noire + rappel après effacement toujours présent.

Correctifs V324 :
1. app-version.json annonçait encore V322 dans la V323 : corrigé en V324.
2. sw.js utilisait encore le cache de base V322 : nouveau cache V324 pour forcer la vraie mise à jour.
3. Toutes les inscriptions du Service Worker pointent vers la version V324.
4. Deux pages pointaient vers des icônes supprimées (assets/icon-pauvres-192/512.png) : remplacées par les icônes Couteau Suisse existantes.
5. Marqueur User-Agent de l'import Jours-de-Marché actualisé en V324.

Important : cet audit valide la cohérence statique du ZIP. Les services externes (Cloudflare D1/R2/AI, e-mail, notifications Push et sites sources) nécessitent le déploiement réel pour un test de bout en bout.
