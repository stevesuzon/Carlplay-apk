V245 — BOIS ET CHAMPIGNONS

- Base conservée : V244 abonnement + trajet champignons.
- Accès Champignons gratuit pendant la période d’essai de Couteau Suisse.
- Code Champignons demandé seulement après la fin de l’essai.
- 18 bois ajoutés en Île-de-France et en Bretagne.
- Mention claire pour les fiches issues de Google et les bois privés.
- Point GPS conseillé à l’endroit où se garer, sans afficher d’adresse.
- Photo en direct du champignon encore en terre.
- GPS de la photo accepté à 200 m maximum du point enregistré.
- Toutes les fiches peuvent être modifiées par les abonnés.
- Suppression après cinq demandes différentes.
- Suppression immédiate disponible dans l’administration de Steve.
- Données existantes conservées avec migrations non destructives.
