const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, POST, OPTIONS",
  "access-control-allow-headers": "content-type, authorization"
};
const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { ...cors, "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});

async function hashCode(code, pepper) {
  const bytes = new TextEncoder().encode(`${pepper}:${code}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, "0")).join("");
}


const ADMIN_FALLBACK_SHA256 = "9bf84a9825fcf66c467a2a73d1369ab3ba5f4d5a86c146046dfe46881eed0e49";

async function sha256Text(value) {
  const bytes = new TextEncoder().encode(String(value || ""));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, "0")).join("");
}

async function adminAuthorized(request, env) {
  const auth = request.headers.get("authorization") || "";
  const supplied = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!supplied) return false;
  if (env.ADMIN_SECRET && supplied === String(env.ADMIN_SECRET).trim()) return true;
  return (await sha256Text(supplied)) === ADMIN_FALLBACK_SHA256;
}

async function body(request) {
  try { return await request.json(); } catch { return {}; }
}

function normalizeCode(value) {
  return String(value || "").toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .replace(/[OI]/g, c => ({ O:"Q", I:"L" }[c]))
    .slice(0, 6);
}
function validCode(value) { return /^[A-HJ-NP-Z0-9]{6}$/.test(normalizeCode(value)); }
function validDevice(value) { return /^[a-zA-Z0-9-]{16,80}$/.test(String(value || "")); }

async function activate(request, env) {
  const data = await body(request);
  const code = normalizeCode(data.code);
  const deviceId = String(data.deviceId || "");
  const type = data.deviceType === "autoradio" ? "autoradio" : "phone";
  if (!validCode(code) || !validDevice(deviceId)) return json({ ok: false, error: "DONNEES_INVALIDES" }, 400);
  const codeHash = await hashCode(code, env.CODE_PEPPER);
  const row = await env.DB.prepare("SELECT * FROM subscriptions WHERE code_hash = ? AND active = 1").bind(codeHash).first();
  if (!row) return json({ ok: false, error: "CODE_INCORRECT" }, 403);
  if (!row.lifetime && (!row.expires_at || Date.parse(row.expires_at) <= Date.now())) return json({ ok: false, error: "ABONNEMENT_EXPIRE" }, 403);
  const column = type === "autoradio" ? "autoradio_device" : "phone_device";
  const registered = row[column];
  if (registered && registered !== deviceId) return json({ ok: false, error: "APPAREIL_DEJA_UTILISE" }, 409);
  if (!registered) await env.DB.prepare(`UPDATE subscriptions SET ${column} = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).bind(deviceId, row.id).run();
  return json({ ok: true, lifetime: !!row.lifetime, expiresAt: row.expires_at || null, deviceType: type });
}

async function subscriptionStatus(request, env) {
  const data = await body(request);
  const code = normalizeCode(data.code);
  const deviceId = String(data.deviceId || "");
  const type = data.deviceType === "autoradio" ? "autoradio" : "phone";
  if (!validCode(code) || !validDevice(deviceId)) return json({ ok: false, error: "DONNEES_INVALIDES" }, 400);
  const codeHash = await hashCode(code, env.CODE_PEPPER);
  const row = await env.DB.prepare("SELECT * FROM subscriptions WHERE code_hash = ? AND active = 1").bind(codeHash).first();
  if (!row) return json({ ok: false, error: "CODE_INCORRECT" }, 403);
  if (!row.lifetime && (!row.expires_at || Date.parse(row.expires_at) <= Date.now())) return json({ ok: false, error: "ABONNEMENT_EXPIRE" }, 403);
  const registered = type === "autoradio" ? row.autoradio_device : row.phone_device;
  if (registered !== deviceId) return json({ ok: false, error: "APPAREIL_REMPLACE" }, 409);
  return json({ ok: true, lifetime: !!row.lifetime, expiresAt: row.expires_at || null, deviceType: type });
}

async function createSubscription(request, env) {
  if (!(await adminAuthorized(request, env))) return json({ ok: false, error: "SECRET_INCORRECT" }, 401);
  const data = await body(request);
  const code = normalizeCode(data.code);
  if (!validCode(code)) return json({ ok: false, error: "CODE_6_CARACTERES_REQUIS" }, 400);
  const lifetime = data.lifetime === true;
  const days = Math.max(1, Math.min(3650, Number(data.days) || 365));
  const expires = lifetime ? null : new Date(Date.now() + days * 86400000).toISOString();
  const codeHash = await hashCode(code, env.CODE_PEPPER);
  const existing = await env.DB.prepare("SELECT * FROM subscriptions WHERE code_hash = ?").bind(codeHash).first();

  if (existing) {
    const stillReserved = !!existing.lifetime || (existing.expires_at && Date.parse(existing.expires_at) > Date.now());
    if (stillReserved) return json({ ok: false, error: "CODE_DEJA_UTILISE" }, 409);

    await env.DB.prepare(
      "UPDATE subscriptions SET expires_at=?, lifetime=?, active=1, updated_at=CURRENT_TIMESTAMP WHERE id=?"
    ).bind(expires, lifetime ? 1 : 0, existing.id).run();

    return json({ ok: true, code, lifetime, expiresAt: expires, renewed: true });
  }

  await env.DB.prepare("INSERT INTO subscriptions(code_hash, expires_at, lifetime, active) VALUES (?, ?, ?, 1)")
    .bind(codeHash, expires, lifetime ? 1 : 0).run();

  return json({ ok: true, code, lifetime, expiresAt: expires, renewed: false });
}

async function subscriptionAction(request, env) {
  if (!(await adminAuthorized(request, env))) return json({ ok: false, error: "SECRET_INCORRECT" }, 401);
  const data = await body(request);
  const code = normalizeCode(data.code);
  if (!validCode(code)) return json({ ok: false, error: "CODE_6_CARACTERES_REQUIS" }, 400);
  const codeHash = await hashCode(code, env.CODE_PEPPER);
  const row = await env.DB.prepare("SELECT id FROM subscriptions WHERE code_hash = ?").bind(codeHash).first();
  if (!row) return json({ ok: false, error: "CODE_INTROUVABLE" }, 404);
  if (data.action === "reset_devices") {
    await env.DB.prepare("UPDATE subscriptions SET autoradio_device = NULL, phone_device = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(row.id).run();
    return json({ ok: true, action: "reset_devices" });
  }
  return json({ ok: false, error: "ACTION_INCONNUE" }, 400);
}





async function ensureMailCounterTable(env) {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS mail_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`).run();
  await env.DB.prepare("CREATE INDEX IF NOT EXISTS mail_events_category ON mail_events(category)").run();
}

function normalizeMailCategory(value) {
  const key = String(value || "").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 40);
  const allowed = new Set(["papiers_travail", "mypos_go2", "mypos_ultra", "mypos_flex", "autre"]);
  return allowed.has(key) ? key : "autre";
}

async function recordMailEvent(request, env) {
  if (!env.DB) return json({ ok: false, error: "DB_INDISPONIBLE" }, 503);
  await ensureMailCounterTable(env);
  const data = await body(request);
  const category = normalizeMailCategory(data.category);
  await env.DB.prepare("INSERT INTO mail_events(category) VALUES (?)").bind(category).run();
  return json({ ok: true, category });
}

async function adminMailCounters(request, env) {
  if (!(await adminAuthorized(request, env))) return json({ ok: false, error: "SECRET_INCORRECT" }, 401);
  if (!env.DB) return json({ ok: false, error: "DB_INDISPONIBLE" }, 503);
  await ensureMailCounterTable(env);
  const rows = await env.DB.prepare("SELECT category, COUNT(*) AS count FROM mail_events GROUP BY category").all();
  const counts = { papiers_travail: 0, mypos_go2: 0, mypos_ultra: 0, mypos_flex: 0, autre: 0 };
  let total = 0;
  for (const row of rows.results || []) {
    const n = Number(row.count || 0);
    counts[row.category] = n;
    total += n;
  }
  return json({ ok: true, total, counts });
}


async function ensureAdminPresenceTable(env) {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS admin_presence (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    active INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`).run();
}

async function adminPresenceStatus(env) {
  if (!env.DB) return json({ ok: true, active: false });
  await ensureAdminPresenceTable(env);
  const row = await env.DB.prepare("SELECT active FROM admin_presence WHERE id = 1").first();
  return json({ ok: true, active: !!(row && Number(row.active) === 1) });
}

async function adminPresenceAction(request, env) {
  if (!(await adminAuthorized(request, env))) return json({ ok: false, error: "SECRET_INCORRECT" }, 401);
  if (!env.DB) return json({ ok: false, error: "DB_INDISPONIBLE" }, 503);
  await ensureAdminPresenceTable(env);
  const data = await body(request);
  const active = data.active === true ? 1 : 0;
  await env.DB.prepare(`INSERT INTO admin_presence(id, active, updated_at) VALUES(1, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET active=excluded.active, updated_at=CURRENT_TIMESTAMP`).bind(active).run();
  return json({ ok: true, active: !!active });
}

async function presence(request, env) {
  if (!env.DB) return json({ ok: false, error: "DB_INDISPONIBLE", count: 0 }, 503);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS app_presence (
    device_id TEXT PRIMARY KEY,
    last_seen INTEGER NOT NULL
  )`).run();
  const now = Math.floor(Date.now() / 1000);
  if (request.method === "POST") {
    const data = await body(request);
    const deviceId = String(data.deviceId || "").slice(0, 100);
    if (!deviceId) return json({ ok: false, error: "APPAREIL_INVALIDE" }, 400);
    await env.DB.prepare("INSERT INTO app_presence(device_id,last_seen) VALUES(?,?) ON CONFLICT(device_id) DO UPDATE SET last_seen=excluded.last_seen")
      .bind(deviceId, now).run();
    await env.DB.prepare("DELETE FROM app_presence WHERE last_seen < ?").bind(now - 600).run();
  }
  const row = await env.DB.prepare("SELECT COUNT(*) AS count FROM app_presence WHERE last_seen >= ?").bind(now - 120).first();
  return json({ ok: true, count: Number(row && row.count || 0) });
}


async function ensureInstallationsTable(env) {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS app_installations (
    device_id TEXT PRIMARY KEY,
    platform TEXT NOT NULL DEFAULT 'unknown',
    first_seen INTEGER NOT NULL,
    last_seen INTEGER NOT NULL
  )`).run();
}

async function installations(request, env) {
  if (!env.DB) return json({ ok: false, error: "DB_INDISPONIBLE", count: 0 }, 503);
  await ensureInstallationsTable(env);
  if (request.method === "POST") {
    const data = await body(request);
    const deviceId = String(data.deviceId || "").slice(0, 100);
    const platform = String(data.platform || "unknown").slice(0, 32);
    if (!deviceId) return json({ ok: false, error: "APPAREIL_INVALIDE" }, 400);
    const now = Math.floor(Date.now() / 1000);
    await env.DB.prepare(`INSERT INTO app_installations(device_id,platform,first_seen,last_seen)
      VALUES(?,?,?,?)
      ON CONFLICT(device_id) DO UPDATE SET platform=excluded.platform,last_seen=excluded.last_seen`)
      .bind(deviceId, platform, now, now).run();
    return json({ ok: true });
  }
  return json({ ok: false, error: "METHODE_INVALIDE" }, 405);
}

async function adminInstallations(request, env) {
  if (!(await adminAuthorized(request, env))) return json({ ok: false, error: "SECRET_INCORRECT" }, 401);
  if (!env.DB) return json({ ok: false, error: "DB_INDISPONIBLE", count: 0 }, 503);
  await ensureInstallationsTable(env);
  const now = Math.floor(Date.now() / 1000);
  const twoMonths = 60 * 24 * 60 * 60;
  await env.DB.prepare("DELETE FROM app_installations WHERE last_seen < ?").bind(now - twoMonths).run();
  const row = await env.DB.prepare("SELECT COUNT(*) AS count FROM app_installations WHERE last_seen >= ?").bind(now - twoMonths).first();
  return json({ ok: true, count: Number(row && row.count || 0) });
}

async function downloadAutoradioApk() {
  const source = "https://raw.githubusercontent.com/stevesuzon/Carlplay-apk/main/LATEST-APK.apk";
  try {
    const upstream = await fetch(source, { headers: { "accept": "application/vnd.android.package-archive,application/octet-stream" } });
    if (!upstream.ok) return new Response("APK indisponible", { status: 502 });
    const headers = new Headers();
    headers.set("content-type", "application/vnd.android.package-archive");
    headers.set("content-disposition", 'attachment; filename="CarPlay-V5-Autoradio.apk"');
    headers.set("cache-control", "no-store");
    headers.set("access-control-allow-origin", "*");
    return new Response(upstream.body, { status: 200, headers });
  } catch (e) {
    return new Response("Téléchargement APK indisponible", { status: 502 });
  }
}

async function downloadRne(url) {
  const siren = String(url.searchParams.get("siren") || "").replace(/\D/g, "");
  if (!/^\d{9}$/.test(siren)) return json({ ok: false, error: "SIREN_INVALIDE" }, 400);
  const source = `https://data.inpi.fr/export/companies?format=pdf&ids=${encodeURIComponent(JSON.stringify([siren]))}`;
  try {
    const upstream = await fetch(source, { headers: { "accept": "application/pdf" } });
    const type = upstream.headers.get("content-type") || "";
    if (!upstream.ok || !type.toLowerCase().includes("pdf")) return json({ ok: false, error: "DOCUMENT_INDISPONIBLE" }, 502);
    return new Response(upstream.body, { status: 200, headers: { ...cors, "content-type": "application/pdf", "content-disposition": `attachment; filename="extrait-rne-${siren}.pdf"`, "cache-control": "no-store" } });
  } catch {
    return json({ ok: false, error: "SERVICE_INPI_INDISPONIBLE" }, 502);
  }
}

async function ensureMarketTable(env) {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS imported_markets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fingerprint TEXT NOT NULL UNIQUE,
    country TEXT NOT NULL,
    area TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'marche',
    name TEXT NOT NULL,
    city TEXT NOT NULL DEFAULT '',
    day TEXT NOT NULL,
    hours TEXT NOT NULL DEFAULT '',
    address TEXT NOT NULL DEFAULT '',
    merchants TEXT NOT NULL DEFAULT '',
    draw TEXT NOT NULL DEFAULT '',
    registration TEXT NOT NULL DEFAULT '',
    note TEXT NOT NULL DEFAULT '',
    latitude REAL,
    longitude REAL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`).run();
  try { await env.DB.prepare("ALTER TABLE imported_markets ADD COLUMN latitude REAL").run(); } catch (_) {}
  try { await env.DB.prepare("ALTER TABLE imported_markets ADD COLUMN longitude REAL").run(); } catch (_) {}
  try { await env.DB.prepare("ALTER TABLE imported_markets ADD COLUMN registration TEXT NOT NULL DEFAULT ''").run(); } catch (_) {}
}

function cleanMarket(value, max = 240) {
  return String(value == null ? "" : value).replace(/\s+/g, " ").trim().slice(0, max);
}

function normalizeMarket(input) {
  const country = cleanMarket(input.country || input.pays, 2).toUpperCase() === "BE" ? "BE" : "FR";
  const area = cleanMarket(input.area || input.department || input.departement || input.province, 80).toUpperCase();
  const kind = /brocante/i.test(cleanMarket(input.kind || input.type)) ? "brocante" : "marche";
  const name = cleanMarket(input.name || input.nom);
  const city = cleanMarket(input.city || input.ville || input.commune, 120);
  const day = cleanMarket(input.day || input.jour, 30).toLowerCase();
  const hours = cleanMarket(input.hours || input.horaires, 80);
  const address = cleanMarket(input.address || input.adresse, 240);
  const merchants = cleanMarket(input.merchants || input.commercants || input.nombre_commercants, 40);
  const draw = cleanMarket(input.draw || input.tirage || input.tirage_au_sort, 30);
  const registration = cleanMarket(input.registration || input.inscription, 120);
  const note = cleanMarket(input.note || input.remarques, 500);
  const latitude = Number(input.latitude != null ? input.latitude : input.lat);
  const longitude = Number(input.longitude != null ? input.longitude : (input.lng != null ? input.lng : input.lon));
  if (!area || !name || !day) return null;
  const fingerprint = [country, area, kind, name, city, day].join("|").toLowerCase();
  return { fingerprint, country, area, kind, name, city, day, hours, address, merchants, draw, registration, note,
    latitude: Number.isFinite(latitude) ? latitude : null,
    longitude: Number.isFinite(longitude) ? longitude : null };
}

async function listMarkets(env) {
  await ensureMarketTable(env);
  const result = await env.DB.prepare("SELECT country,area,kind,name,city,day,hours,address,merchants,draw,registration,note,latitude,longitude FROM imported_markets ORDER BY country,area,day,city,name").all();
  return json({ ok: true, markets: result.results || [] });
}

async function importMarkets(request, env) {
  if (!(await adminAuthorized(request, env))) return json({ ok: false, error: "SECRET_INCORRECT" }, 401);
  await ensureMarketTable(env);
  const payload = await body(request);
  const source = Array.isArray(payload) ? payload : payload.markets;
  if (!Array.isArray(source) || !source.length) return json({ ok: false, error: "AUCUN_MARCHE" }, 400);
  let added = 0, updated = 0, duplicates = 0, invalid = 0;
  for (const raw of source.slice(0, 5000)) {
    const m = normalizeMarket(raw);
    if (!m) { invalid++; continue; }
    const existing = await env.DB.prepare("SELECT fingerprint FROM imported_markets WHERE fingerprint=?").bind(m.fingerprint).first();
    await env.DB.prepare(`INSERT INTO imported_markets
      (fingerprint,country,area,kind,name,city,day,hours,address,merchants,draw,registration,note,latitude,longitude)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(fingerprint) DO UPDATE SET country=excluded.country,area=excluded.area,kind=excluded.kind,name=excluded.name,city=excluded.city,day=excluded.day,hours=excluded.hours,address=excluded.address,merchants=excluded.merchants,draw=excluded.draw,registration=excluded.registration,note=excluded.note,latitude=excluded.latitude,longitude=excluded.longitude`).bind(m.fingerprint,m.country,m.area,m.kind,m.name,m.city,m.day,m.hours,m.address,m.merchants,m.draw,m.registration,m.note,m.latitude,m.longitude).run();
    if (existing) updated++; else added++;
  }
  return json({ ok: true, added, updated, duplicates, invalid, total: source.length });
}

const MARKET_CONSENSUS_REQUIRED = 5;
const MARKET_PHOTO_MAX_BYTES = 260000;
const MARKET_PHOTO_MAX_DISTANCE_METERS = 130;
const MARKET_PHOTO_MIN_STALLS = 4;
const MARKET_PHOTO_MIN_QUALITY = 65;

async function ensureMarketVerificationTables(env) {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS market_verification_votes (
    market_key TEXT NOT NULL, field TEXT NOT NULL, value_norm TEXT NOT NULL, value_display TEXT NOT NULL,
    device_id TEXT NOT NULL, ip_hash TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (market_key, field, device_id)
  )`).run();
  await env.DB.prepare("CREATE INDEX IF NOT EXISTS market_votes_value ON market_verification_votes(market_key,field,value_norm)").run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS market_verification_consensus (
    market_key TEXT NOT NULL, field TEXT NOT NULL, value_norm TEXT NOT NULL, value_display TEXT NOT NULL,
    confirmations INTEGER NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (market_key, field)
  )`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS market_photo_metadata (
    market_key TEXT PRIMARY KEY, object_key TEXT NOT NULL, mime_type TEXT NOT NULL DEFAULT 'image/jpeg',
    device_id TEXT NOT NULL, user_latitude REAL NOT NULL, user_longitude REAL NOT NULL,
    market_latitude REAL NOT NULL, market_longitude REAL NOT NULL, distance_meters REAL NOT NULL,
    quality_score INTEGER NOT NULL DEFAULT 0, stall_count INTEGER NOT NULL DEFAULT 0,
    ai_reason TEXT NOT NULL DEFAULT '', captured_at TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`).run();
  for (const sql of [
    "ALTER TABLE market_photo_metadata ADD COLUMN quality_score INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE market_photo_metadata ADD COLUMN stall_count INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE market_photo_metadata ADD COLUMN ai_reason TEXT NOT NULL DEFAULT ''"
  ]) { try { await env.DB.prepare(sql).run(); } catch (_) {} }
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS market_photo_uploads (
    market_key TEXT NOT NULL, device_id TEXT NOT NULL, uploaded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (market_key, device_id)
  )`).run();
}

function cleanMarketKey(value) { return String(value || "").replace(/[\u0000-\u001f]/g, "").trim().slice(0, 500); }

function normalizedVerification(field, raw) {
  const value = String(raw == null ? "" : raw).trim();
  if (!value) return null;
  if (field === "time") {
    const match = value.match(/^([01]\d|2[0-3]):([0-5]\d)$/);
    if (!match) return null;
    return { norm: `${match[1]}:${match[2]}`, display: `${match[1]}h${match[2] === "00" ? "" : match[2]}` };
  }
  if (field === "count") {
    const count = Number(value);
    if (!Number.isInteger(count) || count < 0 || count > 10000) return null;
    return { norm: String(count), display: String(count) };
  }
  if (field === "draw") {
    const norm = value.toLowerCase();
    if (norm !== "oui" && norm !== "non") return null;
    return { norm, display: norm === "oui" ? "Oui" : "Non" };
  }
  return null;
}

async function registeredVerificationDevice(env, deviceId) {
  await ensureInstallationsTable(env);
  return !!(await env.DB.prepare("SELECT device_id FROM app_installations WHERE device_id=?").bind(deviceId).first());
}

async function refreshMarketConsensus(env, marketKey, field) {
  const rows = await env.DB.prepare(`SELECT value_norm,value_display,COUNT(DISTINCT device_id) AS confirmations
    FROM market_verification_votes WHERE market_key=? AND field=?
    GROUP BY value_norm,value_display ORDER BY confirmations DESC,value_norm ASC LIMIT 2`).bind(marketKey, field).all();
  const list = rows.results || [], first = list[0], second = list[1];
  if (first && Number(first.confirmations) >= MARKET_CONSENSUS_REQUIRED && (!second || Number(first.confirmations) > Number(second.confirmations))) {
    await env.DB.prepare(`INSERT INTO market_verification_consensus(market_key,field,value_norm,value_display,confirmations,updated_at)
      VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
      ON CONFLICT(market_key,field) DO UPDATE SET value_norm=excluded.value_norm,value_display=excluded.value_display,confirmations=excluded.confirmations,updated_at=CURRENT_TIMESTAMP`)
      .bind(marketKey, field, first.value_norm, first.value_display, Number(first.confirmations)).run();
  } else await env.DB.prepare("DELETE FROM market_verification_consensus WHERE market_key=? AND field=?").bind(marketKey, field).run();
  const confirmed = await env.DB.prepare("SELECT field,value_display,confirmations,updated_at FROM market_verification_consensus WHERE market_key=? AND field=?")
    .bind(marketKey, field).first();
  return { field, leadingValue: first ? first.value_display : "", confirmations: first ? Number(first.confirmations) : 0, confirmed: confirmed || null };
}

async function marketVerificationState(env, marketKey, includePhoto = true) {
  await ensureMarketVerificationTables(env);
  const consensus = await env.DB.prepare("SELECT field,value_display,confirmations,updated_at FROM market_verification_consensus WHERE market_key=?").bind(marketKey).all();
  const pending = await env.DB.prepare(`SELECT field,value_display,COUNT(DISTINCT device_id) AS confirmations
    FROM market_verification_votes WHERE market_key=? GROUP BY field,value_norm,value_display ORDER BY field,confirmations DESC`).bind(marketKey).all();
  const values = {}, leaders = {};
  for (const row of consensus.results || []) values[row.field] = { value: row.value_display, confirmations: Number(row.confirmations), updatedAt: row.updated_at };
  for (const row of pending.results || []) if (!leaders[row.field]) leaders[row.field] = { value: row.value_display, confirmations: Number(row.confirmations), required: MARKET_CONSENSUS_REQUIRED };
  let photo = null;
  if (includePhoto) {
    const row = await env.DB.prepare("SELECT distance_meters,quality_score,stall_count,captured_at,updated_at FROM market_photo_metadata WHERE market_key=?").bind(marketKey).first();
    if (row) photo = { url: `/api/market-photo?marketKey=${encodeURIComponent(marketKey)}&v=${encodeURIComponent(row.updated_at)}`, distanceMeters: Math.round(Number(row.distance_meters)), qualityScore: Number(row.quality_score || 0), stallCount: Number(row.stall_count || 0), capturedAt: row.captured_at };
  }
  return { marketKey, required: MARKET_CONSENSUS_REQUIRED, values, leaders, photo };
}

function haversineMeters(a, b, c, d) {
  const p = Math.PI / 180, da = (c - a) * p, db = (d - b) * p;
  const x = Math.sin(da / 2) ** 2 + Math.cos(a * p) * Math.cos(c * p) * Math.sin(db / 2) ** 2;
  return 12742000 * Math.asin(Math.sqrt(x));
}

function decodePhoto(dataUrl) {
  const match = String(dataUrl || "").match(/^data:image\/(jpeg|jpg);base64,([A-Za-z0-9+/=]+)$/);
  if (!match) return null;
  const binary = atob(match[2]);
  if (!binary.length || binary.length > MARKET_PHOTO_MAX_BYTES) return null;
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function parseVisionJson(value) {
  const text = String(value && (value.response || value.result || value.choices?.[0]?.message?.content) || value || "")
    .replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  const start = text.indexOf("{"), end = text.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try { return JSON.parse(text.slice(start, end + 1)); } catch (_) { return null; }
}

async function inspectMarketPhoto(env, dataUrl) {
  if (!env.AI) return { ok: false, error: "RECONNAISSANCE_PHOTO_NON_CONFIGUREE" };
  try {
    const response = await env.AI.run("@cf/meta/llama-3.2-11b-vision-instruct", {
      messages: [
        { role: "system", content: "You are a strict image validator. Return only valid JSON, with no markdown." },
        { role: "user", content: "Check whether this is a clear, attractive, wide general photograph of a real open-air market. It must visibly show at least 4 distinct merchant stalls/booths at the same time and enough surroundings to understand the market. Reject walls, poles, roads, cars, empty squares, buildings, signs, screenshots, drawings, one to three stalls only, close-ups, blurred/dark photos, and photos where the stalls are uncertain. Return exactly: {\"accepted\":boolean,\"isMarket\":boolean,\"generalView\":boolean,\"stallCount\":integer,\"qualityScore\":integer,\"reason\":\"short French reason\"}. qualityScore is 0-100." }
      ],
      image: dataUrl,
      max_tokens: 180,
      temperature: 0
    });
    const result = parseVisionJson(response);
    if (!result) return { ok: false, error: "PHOTO_NON_RECONNUE" };
    const stalls = Math.max(0, Math.min(1000, Math.round(Number(result.stallCount) || 0)));
    const quality = Math.max(0, Math.min(100, Math.round(Number(result.qualityScore) || 0)));
    const accepted = result.accepted === true && result.isMarket === true && result.generalView === true && stalls >= MARKET_PHOTO_MIN_STALLS && quality >= MARKET_PHOTO_MIN_QUALITY;
    if (!accepted) return { ok: false, error: "PHOTO_SANS_VUE_GENERALE_DE_PLUSIEURS_STANDS", stallCount: stalls, qualityScore: quality, reason: String(result.reason || "Photo refusée").slice(0, 180) };
    return { ok: true, stallCount: stalls, qualityScore: quality, reason: String(result.reason || "Vue générale du marché").slice(0, 180) };
  } catch (_) { return { ok: false, error: "RECONNAISSANCE_PHOTO_INDISPONIBLE" }; }
}

async function saveMarketPhoto(env, marketKey, deviceId, photo) {
  if (!env.MARKET_PHOTOS) return { ok: false, error: "STOCKAGE_PHOTO_NON_CONFIGURE" };
  if (photo.generalView !== true) return { ok: false, error: "VUE_GENERALE_NON_CONFIRMEE" };
  const marketLat = Number(photo.marketLatitude), marketLon = Number(photo.marketLongitude);
  const userLat = Number(photo.userLatitude), userLon = Number(photo.userLongitude), accuracy = Number(photo.accuracy);
  if (![marketLat, marketLon, userLat, userLon, accuracy].every(Number.isFinite) || accuracy < 0 || accuracy > 150) return { ok: false, error: "GPS_PHOTO_IMPRECIS" };
  const distance = haversineMeters(userLat, userLon, marketLat, marketLon);
  if (distance > MARKET_PHOTO_MAX_DISTANCE_METERS) return { ok: false, error: "PHOTO_TROP_LOIN_DU_MARCHE", distanceMeters: Math.round(distance) };
  const bytes = decodePhoto(photo.dataUrl);
  if (!bytes) return { ok: false, error: "PHOTO_INVALIDE_OU_TROP_LOURDE" };
  const previous = await env.DB.prepare("SELECT uploaded_at FROM market_photo_uploads WHERE market_key=? AND device_id=?").bind(marketKey, deviceId).first();
  if (previous && Date.now() - Date.parse(previous.uploaded_at) < 7 * 86400000) return { ok: false, error: "UNE_PHOTO_PAR_SEMAINE" };
  const inspection = await inspectMarketPhoto(env, photo.dataUrl);
  if (!inspection.ok) return inspection;
  const current = await env.DB.prepare("SELECT quality_score FROM market_photo_metadata WHERE market_key=?").bind(marketKey).first();
  if (current && Number(current.quality_score || 0) >= inspection.qualityScore) return { ok: true, keptExisting: true, message: "LA_MEILLEURE_PHOTO_EXISTANTE_EST_CONSERVEE", qualityScore: inspection.qualityScore, stallCount: inspection.stallCount, distanceMeters: Math.round(distance) };
  const objectKey = `market-photos/${await sha256Text(marketKey)}.jpg`;
  await env.MARKET_PHOTOS.put(objectKey, bytes, { httpMetadata: { contentType: "image/jpeg", cacheControl: "public, max-age=3600" } });
  const capturedAt = new Date().toISOString();
  await env.DB.prepare(`INSERT INTO market_photo_metadata(market_key,object_key,mime_type,device_id,user_latitude,user_longitude,market_latitude,market_longitude,distance_meters,quality_score,stall_count,ai_reason,captured_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(market_key) DO UPDATE SET object_key=excluded.object_key,mime_type=excluded.mime_type,device_id=excluded.device_id,user_latitude=excluded.user_latitude,user_longitude=excluded.user_longitude,market_latitude=excluded.market_latitude,market_longitude=excluded.market_longitude,distance_meters=excluded.distance_meters,quality_score=excluded.quality_score,stall_count=excluded.stall_count,ai_reason=excluded.ai_reason,captured_at=excluded.captured_at,updated_at=CURRENT_TIMESTAMP`)
    .bind(marketKey, objectKey, "image/jpeg", deviceId, userLat, userLon, marketLat, marketLon, distance, inspection.qualityScore, inspection.stallCount, inspection.reason, capturedAt).run();
  await env.DB.prepare(`INSERT INTO market_photo_uploads(market_key,device_id,uploaded_at) VALUES(?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(market_key,device_id) DO UPDATE SET uploaded_at=CURRENT_TIMESTAMP`).bind(marketKey, deviceId).run();
  return { ok: true, distanceMeters: Math.round(distance), stallCount: inspection.stallCount, qualityScore: inspection.qualityScore, capturedAt };
}

async function submitMarketVerification(request, env) {
  if (!env.DB) return json({ ok: false, error: "DB_INDISPONIBLE" }, 503);
  await ensureMarketVerificationTables(env);
  const data = await body(request), marketKey = cleanMarketKey(data.marketKey), deviceId = String(data.deviceId || "").slice(0, 100);
  if (!marketKey || !validDevice(deviceId)) return json({ ok: false, error: "DONNEES_INVALIDES" }, 400);
  if (!(await registeredVerificationDevice(env, deviceId))) return json({ ok: false, error: "APPAREIL_NON_ENREGISTRE" }, 403);
  const ipHash = await sha256Text(`${env.CODE_PEPPER || "market"}:${request.headers.get("CF-Connecting-IP") || ""}`), results = {};
  for (const field of ["time", "count", "draw"]) {
    const value = normalizedVerification(field, data.values && data.values[field]);
    if (!value) continue;
    await env.DB.prepare(`INSERT INTO market_verification_votes(market_key,field,value_norm,value_display,device_id,ip_hash,created_at,updated_at)
      VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
      ON CONFLICT(market_key,field,device_id) DO UPDATE SET value_norm=excluded.value_norm,value_display=excluded.value_display,ip_hash=excluded.ip_hash,updated_at=CURRENT_TIMESTAMP`)
      .bind(marketKey, field, value.norm, value.display, deviceId, ipHash).run();
    results[field] = await refreshMarketConsensus(env, marketKey, field);
  }
  let photo = null;
  if (data.photo && data.photo.dataUrl) photo = await saveMarketPhoto(env, marketKey, deviceId, data.photo);
  return json({ ok: true, required: MARKET_CONSENSUS_REQUIRED, results, photo, state: await marketVerificationState(env, marketKey) });
}

async function getMarketVerification(url, env) {
  if (!env.DB) return json({ ok: false, error: "DB_INDISPONIBLE" }, 503);
  const marketKey = cleanMarketKey(url.searchParams.get("marketKey"));
  if (!marketKey) return json({ ok: false, error: "MARCHE_INVALIDE" }, 400);
  return json({ ok: true, ...(await marketVerificationState(env, marketKey)) });
}

async function batchMarketVerifications(request, env) {
  if (!env.DB) return json({ ok: false, error: "DB_INDISPONIBLE" }, 503);
  await ensureMarketVerificationTables(env);
  const data = await body(request);
  const keys = [...new Set((Array.isArray(data.keys) ? data.keys : []).map(cleanMarketKey).filter(Boolean))].slice(0, 200), states = {};
  for (const key of keys) states[key] = await marketVerificationState(env, key, true);
  return json({ ok: true, required: MARKET_CONSENSUS_REQUIRED, states });
}

async function marketPhoto(url, env) {
  if (!env.DB || !env.MARKET_PHOTOS) return new Response("Photo indisponible", { status: 404, headers: cors });
  await ensureMarketVerificationTables(env);
  const marketKey = cleanMarketKey(url.searchParams.get("marketKey"));
  const row = marketKey && await env.DB.prepare("SELECT object_key,mime_type FROM market_photo_metadata WHERE market_key=?").bind(marketKey).first();
  if (!row) return new Response("Photo indisponible", { status: 404, headers: cors });
  const object = await env.MARKET_PHOTOS.get(row.object_key);
  if (!object) return new Response("Photo indisponible", { status: 404, headers: cors });
  return new Response(object.body, { headers: { ...cors, "content-type": row.mime_type || "image/jpeg", "cache-control": "public, max-age=3600" } });
}

async function vigilanceForPlace(url) {
  const lat = Number(url.searchParams.get("lat")), lon = Number(url.searchParams.get("lon"));
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return json({ ok: false, error: "POSITION_INVALIDE" }, 400);
  try {
    const geo = await fetch(`https://geo.api.gouv.fr/communes?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&fields=codeDepartement,departement&format=json`, { headers: { accept: "application/json", "user-agent": "CarPlay-Weather/1.0" } });
    const communes = geo.ok ? await geo.json() : [];
    const commune = Array.isArray(communes) && communes[0];
    const department = commune && commune.departement && commune.departement.nom || "";
    const code = commune && commune.codeDepartement || "";
    if (!department) return json({ ok: true, department: "", code: "", orangeThunderstorm: false });
    const feed = await fetch("https://feeds.meteoalarm.org/api/v1/warnings/feeds-france", { headers: { accept: "application/json", "user-agent": "CarPlay-Weather/1.0" }, cf: { cacheTtl: 300, cacheEverything: true } });
    if (!feed.ok) throw new Error("feed");
    const warnings = await feed.json();
    const fold = value => String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const dep = fold(department);
    let yellowThunderstorm = false, orangeThunderstorm = false, redThunderstorm = false, floodRisk = false, floodLevel = "";
    for (const warning of warnings.warnings || []) for (const info of warning.alert && warning.alert.info || []) {
      if (!(info.area || []).some(area => fold(area.areaDesc) === dep)) continue;
      if (info.expires && Date.parse(info.expires) <= Date.now()) continue;
      const title = fold([info.event, info.headline, ...(info.parameter || []).map(p => p.value)].join(" "));
      if ((title.includes("orage") || title.includes("thunderstorm")) && title.includes("orange")) orangeThunderstorm = true;
      if ((title.includes("orage") || title.includes("thunderstorm")) && title.includes("red")) redThunderstorm = true;
      if ((title.includes("orage") || title.includes("thunderstorm")) && title.includes("yellow")) yellowThunderstorm = true;
      if (title.includes("inondation") || title.includes("crue") || title.includes("flood")) {
        floodRisk = true;
        if (title.includes("red") || title.includes("rouge")) floodLevel = "rouge";
        else if (!floodLevel || floodLevel === "jaune") floodLevel = title.includes("orange") ? "orange" : "jaune";
      }
    }
    return json({ ok: true, department, code, yellowThunderstorm, orangeThunderstorm: orangeThunderstorm || redThunderstorm, redThunderstorm, floodRisk, floodLevel }, 200);
  } catch (error) {
    return json({ ok: false, error: "VIGILANCE_INDISPONIBLE", detail: String(error && error.message || error).slice(0, 160) }, 502);
  }
}

class InjectAppFiles {
  element(element) {
    element.append('<link rel="manifest" href="/manifest.webmanifest"><link rel="stylesheet" href="/mobile-overrides.css?v=62"><link rel="stylesheet" href="/subscription-locks.css?v=62"><link rel="stylesheet" href="/home-work.css?v=62"><script src="/weather-all-pages.js?v=62" defer></script><script src="/subscription-web.js?v=62" defer></script><script src="/home-work.js?v=62" defer></script>', { html: true });
  }
}

class FixAndroidLinks {
  element(element) {
    const href = element.getAttribute("href") || "";
    const prefix = "file:///android_asset/";
    if (href.startsWith(prefix)) element.setAttribute("href", "/" + href.slice(prefix.length));
  }
}

class InjectMarketLive {
  element(element) {
    const src = element.getAttribute("src") || "";
    if (/market-(?:final|clean)\.js(?:\?|$)/.test(src)) element.before('<script src="/market-live.js?v=1"></script>', { html: true });
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (url.pathname === "/api/activate" && request.method === "POST") return activate(request, env);
    if (url.pathname === "/api/status" && request.method === "POST") return subscriptionStatus(request, env);
    if (url.pathname === "/api/presence" && (request.method === "GET" || request.method === "POST")) return presence(request, env);
    if (url.pathname === "/api/installations" && request.method === "POST") return installations(request, env);
    if (url.pathname === "/api/admin/installations" && request.method === "GET") return adminInstallations(request, env);
    if (url.pathname === "/api/admin/presence" && request.method === "GET") return adminPresenceStatus(env);
    if (url.pathname === "/api/admin/presence" && request.method === "POST") return adminPresenceAction(request, env);
    if (url.pathname === "/api/admin/subscriptions" && request.method === "POST") return createSubscription(request, env);
    if (url.pathname === "/api/admin/subscriptions/action" && request.method === "POST") return subscriptionAction(request, env);
    if (url.pathname === "/api/mail-event" && request.method === "POST") return recordMailEvent(request, env);
    if (url.pathname === "/api/admin/mail-counters" && request.method === "GET") return adminMailCounters(request, env);
    if (url.pathname === "/download-autoradio.apk" && request.method === "GET") return downloadAutoradioApk();
    if (url.pathname === "/api/rne-pdf" && request.method === "GET") return downloadRne(url);
    if (url.pathname === "/api/markets" && request.method === "GET") return listMarkets(env);
    if (url.pathname === "/api/admin/markets/import" && request.method === "POST") return importMarkets(request, env);
    if (url.pathname === "/api/market-verifications" && request.method === "GET") return getMarketVerification(url, env);
    if (url.pathname === "/api/market-verifications" && request.method === "POST") return submitMarketVerification(request, env);
    if (url.pathname === "/api/market-verifications/batch" && request.method === "POST") return batchMarketVerifications(request, env);
    if (url.pathname === "/api/market-photo" && request.method === "GET") return marketPhoto(url, env);
    if (url.pathname === "/api/vigilance" && request.method === "GET") return vigilanceForPlace(url);
    // Laisser Cloudflare Static Assets résoudre "/" vers index.html.
    // Ne pas réécrire "/" en "/index.html" ici : avec html_handling automatique,
    // cela peut créer une boucle / <-> /index.html.
    let response = await env.ASSETS.fetch(request);
    if (url.pathname === "/sw.js" || url.pathname === "/app-version.json") {
      const h = new Headers(response.headers);
      h.set("cache-control", "no-store, no-cache, must-revalidate, max-age=0");
      return new Response(response.body, { status: response.status, statusText: response.statusText, headers: h });
    }
    const type = response.headers.get("content-type") || "";
    if (type.includes("text/html") && url.pathname !== "/admin.html" && url.pathname !== "/admin" && url.pathname !== "/import-marches.html") {
      const transformed = new HTMLRewriter().on("head", new InjectAppFiles()).on("a", new FixAndroidLinks()).on("script", new InjectMarketLive()).transform(response);
      const headers = new Headers(transformed.headers);
      headers.set("cache-control", "no-store, no-cache, must-revalidate");
      return new Response(transformed.body, { status: transformed.status, statusText: transformed.statusText, headers });
    }
    return response;
  }
};
