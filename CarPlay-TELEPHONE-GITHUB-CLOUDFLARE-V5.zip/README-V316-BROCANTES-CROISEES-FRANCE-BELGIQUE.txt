COUTEAU SUISSE — V316
BROCANTE / VIDE-GRENIER / FOIRE — FRANCE + BELGIQUE

Mise à jour du 20/09/2026

- La rubrique « Brocantes » devient « Brocante / Vide-grenier / Foire ».
- Le filtre reconnaît aussi : vide-greniers, foires à tout, foires aux greniers, braderies, réderies, bric-à-brac, troc et puces, rommelmarkt et vlooienmarkt.
- Conservation de la base déjà présente (notamment DATAtourisme/data.gouv côté France et sources belges déjà intégrées).
- Ajout d’un complément web croisé à partir de Brocabrac, vide-greniers.org, Quefaire.be et Brocantes.be.
- 153 compléments France et 65 compléments Belgique retenus après dédoublonnage par rapport à la base existante.
- Les fiches complémentaires gardent leur URL source dans les données pour contrôle ultérieur.
- Une vérification organisateur/mairie reste recommandée avant déplacement : les calendriers d’événements peuvent changer ou être annulés.
- La confirmation avant « Effacer l’emplacement » de la V315 est conservée.

Important : aucun annuaire public ne permet de garantir 100 % de toutes les manifestations de France et de Belgique. Cette version croise plusieurs sources et enrichit la base sans supprimer les données existantes.
