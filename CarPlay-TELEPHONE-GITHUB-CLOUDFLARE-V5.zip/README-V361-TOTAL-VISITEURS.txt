V361 — Compteurs

Accueil : affichage « nombre utilisateurs » conservé. Total historique des appareils/navigateurs présents dans app_installations, y compris visites sans compte et applications installées. Les retours avec le même identifiant ne sont pas recomptés. La page de présentation enregistre aussi ses visiteurs. Le bilan des 15 jours utilise désormais cette même règle.

Administration : compteur des installations reconnues en mode écran d’accueil conservé, y compris sans compte confirmé. Le total juste dessous correspond au total de l’accueil.

Limites : une personne sur plusieurs navigateurs/appareils peut être comptée plusieurs fois. Les visites jamais enregistrées ne peuvent pas être reconstituées. Le nombre historique exact sera lu sur le serveur après déploiement ; aucun nombre n’est fixé artificiellement. Les anciennes installations écran d’accueil sont reconnues à la prochaine ouverture.

Marchés et données existantes inchangés. Invalidation limitée aux modules administration, statistiques et installation.
