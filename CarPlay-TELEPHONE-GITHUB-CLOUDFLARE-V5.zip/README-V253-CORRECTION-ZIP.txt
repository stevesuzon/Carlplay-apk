V253 - Correction du ZIP V252
- Restauration des fichiers serveur src/ nécessaires au déploiement Cloudflare.
- Conservation des fonctions V252 : récupération d'abonnement par e-mail, essai 5 mois et accès Champignons pendant l'essai, vidéo obligatoire avant installation.
- Conservation des anciens README et des données/fichiers de l'application.
