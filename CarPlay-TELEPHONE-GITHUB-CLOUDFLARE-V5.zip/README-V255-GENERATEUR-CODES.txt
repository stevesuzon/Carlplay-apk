COUTEAU SUISSE V255 — GÉNÉRATEUR DE CODES SÉPARÉ

- Le générateur de codes a été retiré du mode Administrateur de l’application principale.
- La gestion administrative des fiches Champignons reste disponible.
- L’API de création des codes reste active afin que l’application séparée « Application Couteau Suisse — Générateur privé de codes » puisse créer les codes.
- Le générateur séparé propose maintenant : code application 365 jours, code application à vie, déblocage et code Champignons 2 ans / 50 €.
- Aucun abonnement, fiche, photo, GPS ou donnée utilisateur n’est supprimé par cette mise à jour.
