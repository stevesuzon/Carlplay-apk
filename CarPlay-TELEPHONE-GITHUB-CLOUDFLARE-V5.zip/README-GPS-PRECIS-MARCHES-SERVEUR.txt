GPS marchés — point officiel partagé

- Le bouton « ALLER AU MARCHÉ » relit le point GPS officiel depuis /api/market-verifications avant chaque navigation.
- Lorsqu’un point GPS est validé pour un marché, il est conservé côté serveur dans market_location_consensus.
- Tous les utilisateurs utilisent ensuite exactement la même latitude/longitude officielle pour ce marché.
- Les anciennes coordonnées locales du fichier sont remplacées en mémoire par le point serveur lorsqu’il existe.
- Google Maps, Waze et Plans utilisent ce point GPS comme destination.
- Le GPS du téléphone de l’utilisateur reste uniquement le point de départ de la navigation ; il ne modifie pas la position du marché.
