V265 — AJOUTER UN BOIS GUIDÉ

- Étape 1 : bouton « LOCALISER LE BOIS ».
- Étape 2 : bouton photo gris tant que le GPS du bois n’est pas enregistré ; bleu ensuite.
- Consigne courte : photographier le champignon non cueilli, encore en terre.
- Un second GPS est pris au moment de la photo et doit rester proche du GPS du bois (maximum 200 m, contrôle client + serveur).
- L’analyse IA est signée avec le GPS réel de la photo.
- Une photo sans champignon réel ou montrant un champignon cueilli est refusée par l’analyse.
- Si l’IA reconnaît suffisamment l’espèce, le champ « Quel champignon ? » est rempli automatiquement.
- Sinon, l’utilisateur tape 1 ou 2 lettres et touche une proposition filtrée.
- Les fonctions V264 restent présentes : concours +50 points après validation, abonnement Champignons 1 an, recherche 15 km de détour, voir les coins.
