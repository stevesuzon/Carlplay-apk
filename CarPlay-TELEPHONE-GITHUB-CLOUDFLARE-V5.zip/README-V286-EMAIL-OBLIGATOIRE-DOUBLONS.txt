COUTEAU SUISSE — V286

- Adresse e-mail valide obligatoire pour utiliser l’application.
- Si l’identité enregistrée est incomplète, l’application reste bloquée sur le formulaire Nom / Prénom / E-mail.
- Les anciennes fiches utilisateurs sans e-mail ne sont plus affichées dans Réglages > Administration > Bannir / Débannir.
- Les doublons exacts visibles avec une fiche sans e-mail et une fiche avec e-mail ne laissent apparaître que la fiche avec e-mail.
- Nettoyage sûr : seules les anciennes lignes d’identité incomplètes sont supprimées ; les abonnements, points, adresses, devis et autres données métier ne sont pas supprimés.
- Cache : mise à jour ciblée du module d’installation / contrôle d’accès.
