COUTEAU SUISSE V290 — RATTRAPAGE DES ANCIENNES FICHES CONCOURS

- Recherche les anciennes fiches marché déjà enregistrées sur le serveur.
- Une fiche est rattrapée uniquement si une preuve photo acceptée est reliée à l’appareil et si le GPS du marché est exploitable.
- Les points de renseignements de la fiche et les kilomètres sont recalculés à partir des données réellement enregistrées.
- Aucun doublon : une fiche déjà créditée ou déjà présente dans les demandes du concours est ignorée.
- Les anciennes fiches retrouvées sont créditées automatiquement et un message de confirmation est ajouté au compte de la personne.
- Les bonus de seuil (5 / 15 / 40 fiches) et le bonus trajet >150 km continuent de fonctionner.
- Les anciens multiplicateurs temporaires ne sont pas inventés rétroactivement : le rattrapage utilise x1 pour les anciennes fiches afin de ne pas attribuer de bonus non prouvable.
- Le contrôle se lance pour l’utilisateur à l’ouverture du concours et globalement à l’ouverture du panneau administrateur.
- Aucune adresse, devis, Papier pro, Mes papiers ou autre donnée personnelle locale n’est supprimée.
