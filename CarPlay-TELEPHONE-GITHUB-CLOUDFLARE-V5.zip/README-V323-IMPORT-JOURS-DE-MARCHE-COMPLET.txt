COUTEAU SUISSE — V323 — IMPORT JOURS-DE-MARCHÉ.FR RENFORCÉ

- Base de départ : V322, donc les brocantes / foires / vide-greniers déjà récupérés restent présents.
- Jours-de-Marché.fr reste une source complémentaire : les données déjà vérifiées ne sont pas supprimées.
- Import France progressif côté Worker, jamais depuis les téléphones.
- Cron : toutes les heures. Deux lots de département sont traités à chaque passage, 12 pages de communes par lot.
- Le site source annonce actuellement 10 386 marchés ajoutés ; l'application ne prétend pas les avoir tous tant que le cycle d'import D1 n'est pas terminé.
- Même marché sur plusieurs jours : une fiche distincte par jour (ex. lundi + dimanche = 2).
- Doublon strict même marché / même ville / même jour : fusion par empreinte.
- CORRECTION V323 IMPORTANTE : une même URL source ne fusionne plus les différents jours d'un marché.
- Marchés de producteurs / drives fermiers restent exclus des marchés classiques selon la règle du projet.
- Marchés périodiques : conservés avec leur mention mensuelle / trimestrielle / 1er-2e-3e-4e jour.
- Marchés de Noël : importés en catégorie Noël lorsqu'ils sont identifiés.
- Brocantes / vide-greniers / foires : récupérés depuis Jours-de-Marché.fr en plus de Brocabrac/Brocantes.be et des compléments V316.
- Téléphone et nombre d'emplacements/exposants sont récupérés quand ils sont publiés.
- Corse ajoutée via la page département 20 puis répartie 2A/2B selon le code postal quand possible.
- Les événements datés déjà terminés ne sont pas réimportés.
- /api/markets/refresh-status permet de consulter l'avancement serveur.

Source vérifiée le 20/09/2026 : https://www.jours-de-marche.fr/
Le site indique lui-même qu'il est participatif et que certaines informations peuvent ne plus être à jour : les corrections communautaires de Couteau Suisse restent donc actives.
