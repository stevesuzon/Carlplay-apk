COUTEAU SUISSE — V254 — ESSAI APRÈS LA PÉRIODE DES 5 MOIS

- La période gratuite globale dure exactement 5 mois.
- Pendant ces 5 mois, les nouveaux utilisateurs finissent tous le même jour que la période globale.
- Après la fin des 5 mois, une personne qui s’inscrit pour la première fois reçoit 7 jours gratuits sur TOUTE l’application.
- Après les 7 jours, l’application se verrouille comme pour les autres utilisateurs et demande un abonnement.
- L’essai de 7 jours n’est accordé qu’une fois par personne/e-mail : une réinstallation ou un changement de téléphone conserve la date de fin existante et ne redonne pas 7 jours.
- Si l’adresse e-mail correspond déjà à un ancien abonnement, aucun nouvel essai n’est créé : l’utilisateur doit récupérer son code dans Réglages > Abonnement > Me faire renvoyer mon code d’abonnement.
- Les jours restants de l’ancien abonnement sont conservés.
- L’accès Champignons suit la période d’essai principale ; quand l’essai principal finit, le code Champignons redevient nécessaire sauf abonnement Champignons actif.
