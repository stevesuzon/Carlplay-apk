COUTEAU SUISSE — V322 — JOURS-DE-MARCHÉ.FR

- Jours-de-Marché.fr devient une source complémentaire automatique pour la France.
- Le Worker travaille progressivement, département par département, sans faire rechercher tous les sites par les téléphones.
- Une exécution traite au maximum 32 pages de communes + la page du département + la page vide-greniers du département.
- Marché présent plusieurs jours : une entrée par jour (ex. lundi + dimanche = 2).
- Doublon strict même marché / ville / jour : fusion D1 par empreinte.
- Marchés de producteurs / drives fermiers : exclus des marchés hebdomadaires classiques selon la règle du projet.
- Les mentions mensuelles / trimestrielles / 1er jeudi, etc. sont conservées afin d’apparaître dans Marchés périodiques.
- Les marchés de Noël repérés sur Jours-de-Marché.fr sont importés en catégorie Noël.
- La rubrique vide-greniers Jours-de-Marché.fr complète les brocantes / foires / vide-greniers.
- Brocabrac, Brocantes.be, DATAtourisme et les données déjà vérifiées restent conservés : rien n’est remplacé.
- Les événements datés déjà terminés ne sont pas réimportés.
- Fréquence : cron existant toutes les 2 heures, un département Jours-de-Marché par passage, avec reprise par lots de communes.
