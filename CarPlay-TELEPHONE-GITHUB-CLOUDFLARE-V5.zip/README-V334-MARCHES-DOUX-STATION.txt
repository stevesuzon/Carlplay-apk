V334 — Recherche douce des marchés + bouton Stations

- Recherche automatique réactivée par défaut, mais volontairement très progressive.
- Une seule page source est traitée par heure via le Cron Cloudflare.
- Rotation : marchés France (Jours-de-Marché), foires/brocantes/braderies France (Brocabrac), puis brocantes/braderies Belgique (Brocantes.be).
- Maximum 18 nouvelles/mises à jour de fiches traitées par passage afin de réduire la charge CPU/D1.
- Les doublons restent évités par l’empreinte (fingerprint) existante.
- La recherche peut être arrêtée manuellement avec MARKET_AUTO_REFRESH=0.
- Le bouton « STATIONS 15 KM » est plus haut, moins large, sur deux lignes et garde un espace avec le bouton Réglages.
- Observabilité Cloudflare conservée.
- Aucune donnée utilisateur, abonnement, photo ou fiche existante n’est supprimée.
