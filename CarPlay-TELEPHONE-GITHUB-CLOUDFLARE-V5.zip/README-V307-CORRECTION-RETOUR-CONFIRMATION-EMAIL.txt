V307 — CORRECTION RETOUR CONFIRMATION E-MAIL

- Un seul formulaire d’inscription est présent : app-access-gate-v240.js.
- Le lien de confirmation redirige maintenant vers / au lieu de /index.html afin d’éviter les réécritures/canonicalisations de Cloudflare Static Assets.
- Après confirmation dans Mail/Safari, l’application recontrôle automatiquement l’état du compte lorsqu’elle reprend le focus, redevient visible ou revient depuis l’arrière-plan.
- Une vérification temporaire toutes les 12 secondes est active uniquement pendant l’attente de confirmation et s’arrête après validation ou au bout de quelques minutes.
- Le jeton de handoff n’est consommé qu’après validation effective du compte.
- L’ancien utilisateur déjà enregistré n’a toujours rien à refaire.
- Les caches installation/service worker passent en V307 pour forcer la prise en compte du correctif.
