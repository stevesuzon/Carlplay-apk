V288 — IDENTITÉ MÉMORISÉE SANS RETOUR DU FORMULAIRE

- Nom, prénom et adresse e-mail valide restent obligatoires pour une nouvelle inscription.
- Une fois l’identité validée et mémorisée, le formulaire Inscription / Récupération ne revient plus à chaque ouverture.
- Une panne temporaire de synchronisation abonnement/concours ne rebloque plus un utilisateur déjà identifié.
- La synchronisation serveur continue en arrière-plan.
- Mise à jour de cache ciblée uniquement sur le module installation/identité ; les caches métiers et données utilisateur restent séparés.
