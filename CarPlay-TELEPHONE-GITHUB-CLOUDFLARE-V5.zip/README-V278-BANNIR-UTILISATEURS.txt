VERSION V278 — BANNIR / DÉBANNIR LES UTILISATEURS

- Une nouvelle section « Bannir / Débannir » apparaît dans Réglages uniquement pour l’administrateur.
- Elle ouvre la liste complète des comptes inscrits avec nom, prénom et e-mail.
- Chaque compte possède un bouton rouge « Bannir » ou vert « Débannir » selon son état.
- Le compte administrateur Steve Suzon reste protégé et ne peut pas être banni.
- Les anciens bannissements sont reconnus par abonnement, e-mail, empreinte d’e-mail ou appareil.
