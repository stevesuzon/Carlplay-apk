COUTEAU SUISSE — V305 — ANCIENS COMPTES CONSERVÉS / CONFIRMATION E-MAIL POUR LES NOUVEAUX

OBJECTIF
- Les personnes déjà enregistrées avant la mise en place de la confirmation e-mail ne doivent rien refaire.
- Elles gardent directement l'accès à Couteau Suisse avec leur nom, prénom et e-mail déjà mémorisés.
- Seuls les nouveaux utilisateurs voient le formulaire Nom + Prénom + Adresse e-mail et doivent confirmer le lien reçu par e-mail.

CORRECTIONS
- Migration automatique unique des identités existantes vers le statut « compte historique reconnu ».
- Aucun nouvel e-mail de confirmation demandé aux utilisateurs déjà enregistrés.
- Les anciens participants au concours sont remis dans le rattrapage V305 au lieu d'être masqués.
- Si le clic de confirmation e-mail réussit côté serveur mais que le retour Safari/PWA perd le handoff, l'application vérifie le serveur avant d'afficher à nouveau le formulaire. Cela supprime la boucle de réinscription observée.
- Cache installation passé en V305 et service worker forcé à se mettre à jour.

NOUVEAUX UTILISATEURS
Installation iPhone/Android -> Aller sur le site -> Nom + Prénom + E-mail -> Confirmer mon adresse e-mail -> clic dans l'e-mail -> accès à Couteau Suisse.

ANCIENS UTILISATEURS
Ouverture de Couteau Suisse -> identité existante reconnue -> accès direct, sans refaire le formulaire et sans confirmer à nouveau l'e-mail.
