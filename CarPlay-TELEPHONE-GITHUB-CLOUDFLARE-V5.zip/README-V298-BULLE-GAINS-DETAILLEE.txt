COUTEAU SUISSE — V298 — BULLE DE GAINS DÉTAILLÉE

NOTIFICATION / BULLE CONCOURS
- Après validation administrateur, la bulle affiche uniquement les éléments réellement concernés.
- Pour une fiche marché, chaque information validée est nommée séparément avec ses points : marché confirmé, horaire, commerçants, tirage, clients, placier, photo, GPS, adresse, fiche complète, etc.
- Le trajet affiche : kilomètres aller, litres utilisés et points de déplacement.
- Le prix du gasoil et le coût en euros ne sont PAS affichés dans la bulle.
- Si un bonus multiplicateur est actif, il est indiqué avant le total.
- Le total gagné reste affiché en bas.
- Les anciennes fiches rattrapées utilisent également ce détail quand elles sont créditées.
- Les autres gains restent explicites : Champignons, bug/problème, idée, parrainage, etc.

CALCUL
- Le calcul gasoil V297 reste inchangé en interne (2,40 €/L, 7 L/100 km, aller seulement, 1 € = 1 point).
- Seul l’affichage de la bulle change : le prix n’est plus montré.

CACHE
- Mise à jour ciblée du module concours uniquement.
- Les caches des adresses, devis, photos, GPS, abonnements et autres modules restent inchangés.
