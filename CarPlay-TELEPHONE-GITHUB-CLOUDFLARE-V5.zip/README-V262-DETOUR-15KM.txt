V262 — COINS CHAMPIGNONS : DÉTOUR 15 KM

- « Sur mon trajet » accepte désormais jusqu’à 15 km de détour au lieu de 10 km.
- Le calcul reste basé sur le trajet entre le marché et « Retourner sur la place ».
- Texte affiché : « Du marché jusqu’au retour sur la place : coins Champignons avec max 15 km de détour. »
- Si aucun coin ne respecte les 15 km de détour, affichage automatique des coins à moins de 100 km.
- Toutes les corrections V261 sont conservées.
