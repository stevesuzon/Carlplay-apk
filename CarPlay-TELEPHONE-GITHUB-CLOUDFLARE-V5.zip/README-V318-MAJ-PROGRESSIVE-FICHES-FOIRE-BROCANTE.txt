COUTEAU SUISSE — V318
MISE À JOUR PROGRESSIVE + FICHES FOIRE/BROCANTE PLUS VISIBLES

1. Le serveur ne recherche plus tout en même temps. Un cron Cloudflare passe toutes les 2 heures et traite une seule zone/catégorie à la fois.
2. Quand la dernière date connue d’une brocante, foire, marché de Noël ou marché voyageur est passée, cette zone devient prioritaire pour le prochain contrôle.
3. Les événements terminés dont la date est connue ne sont plus affichés dans les listes à venir.
4. Brocante / Vide-grenier / Foire : recherche progressive côté serveur sur les agendas publics configurés.
   - France : Brocabrac par département.
   - Belgique : Brocantes.be par province.
   - France : DATAtourisme peut compléter automatiquement si le secret Cloudflare DATATOURISME_API_KEY est renseigné.
5. Les fiches possédant une URL source sont aussi revérifiées progressivement pour récupérer une nouvelle date ou un téléphone publié.
6. Marchés hebdomadaires, voyageurs et Noël utilisent la même file de contrôle progressive ; ils ne déclenchent jamais une recherche nationale simultanée.
7. Les téléphones continuent seulement à télécharger /api/markets : ils ne parcourent jamais eux-mêmes les sites externes.
8. Dans « Brocante / Vide-grenier / Foire », les fiches sont plus grandes et portent un gros badge immédiatement visible : FOIRE, BROCANTE, VIDE-GRENIER ou BRADERIE.
9. Le bouton vert APPELER reste affiché uniquement si un vrai numéro est trouvé. Les boutons ALLER À LA FOIRE / BROCANTE / VIDE-GRENIER restent adaptés au type.
10. Les présences « N personnes y vont aujourd’hui » et la confirmation avant Effacer l’emplacement sont conservées.

À CONFIGURER POUR LE COMPLÉMENT DATATOURISME :
Ajouter dans Cloudflare Worker > Settings > Variables and Secrets un secret nommé DATATOURISME_API_KEY. La clé gratuite est fournie par DATAtourisme. Sans cette clé, Brocabrac/Brocantes.be + les URL sources existantes continuent à être vérifiés.
