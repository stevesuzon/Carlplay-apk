COUTEAU SUISSE — V297 — POINTS CORRIGÉS

AFFICHAGE
- Tous les scores du concours sont affichés avec exactement 2 décimales et une virgule.
- Exemple : 788,80 pts (et jamais 788.8035560000001).
- Le classement, l’en-tête du concours et le détail des points utilisent le même format.

CALCUL / RATTRAPAGE GASOIL
- Prix gasoil : 2,40 € / litre.
- Consommation de référence : 7 L / 100 km.
- Trajet ALLER seulement.
- 1 € de gasoil = 1 point.
- Les anciens trajets Marché déjà validés sont recalculés une seule fois avec cette règle.
- La différence est ajoutée au score de chaque personne puis le total est arrondi à 2 décimales.
- Les autres gains (bugs, parrainages, champignons, bonus, etc.) restent conservés.
- Aucune fiche déjà créditée n’est doublée.

CACHE
- Invalidation ciblée sur le module concours.
- Les adresses, devis, photos, GPS, abonnements et autres données restent intactes.
