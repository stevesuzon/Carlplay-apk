V263 — CHAMPIGNONS

- Bouton « RECONNAÎTRE UN CHAMPIGNON » visible directement.
- Bouton « AJOUTER UN BOIS » visible directement.
- Bouton « VOIR LES COINS » conservé.
- Reconnaissance photo sans obligation d’enregistrer un bois.
- Ajouter un bois conserve GPS + photo + reconnaissance + concours.
- Recherche sur trajet conservée à maximum 15 km de détour.
- Toutes les corrections V262 et antérieures sont conservées.
