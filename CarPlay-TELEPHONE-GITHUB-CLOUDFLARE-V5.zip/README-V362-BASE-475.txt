V362 — Base manuelle 475 utilisateurs

Le total affiché uniquement sur l’accueil démarre sur une base manuelle de 475. Ce nombre est choisi par le propriétaire, pas récupéré depuis les visites historiques.

Au premier accès au compteur ou à l’enregistrement des visites après déploiement, le nombre d’identifiants déjà enregistrés est mémorisé une seule fois dans D1. Les nouveaux identifiants sont ensuite ajoutés à 475. Une revisite avec le même identifiant ne fait pas monter le compteur. La base persiste après redémarrage ou redéploiement. Les anciens identifiants ne sont pas ajoutés une seconde fois.

Dans Administration, seul le compteur des installations écran d’accueil est affiché, sans base artificielle. Le bloc Total utilisateurs a été retiré. Le bilan des 15 jours continue de compter uniquement les nouveaux identifiants réellement enregistrés.

Plusieurs appareils ou navigateurs pour une même personne peuvent compter plusieurs fois. Aucune visite ni donnée existante n’est supprimée. Marchés inchangés.
