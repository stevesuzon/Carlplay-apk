COUTEAU SUISSE — V288

Modification : points du concours en mode administrateur.

- Une fiche marché envoyée en mode administrateur est désormais comptabilisée dans le concours.
- Calcul identique aux autres participants : points de fiche + points de trajet / kilomètres + multiplicateur actif.
- Les paliers de bonus fiches et le bonus long trajet (>150 km) restent appliqués.
- En mode administrateur, la fiche est validée automatiquement : elle ne crée pas une demande à approuver soi-même.
- Les utilisateurs normaux gardent exactement le parcours existant avec validation administrateur.
- Aucune suppression des adresses, devis, données concours ou données utilisateur.
- Cache ciblé : aucun cache fonctionnel n’est vidé ; seule la version générale passe à V288 pour signaler la mise à jour.
