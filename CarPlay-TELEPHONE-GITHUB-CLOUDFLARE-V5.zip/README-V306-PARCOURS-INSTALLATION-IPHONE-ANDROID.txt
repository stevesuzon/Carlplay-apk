COUTEAU SUISSE — V306 — PARCOURS D’INSTALLATION SIMPLIFIÉ

Le guide de départ explique maintenant le parcours complet en bref.

iPhone / iPad :
1. Aller sur le site.
2. Renseigner Nom + Prénom + Adresse e-mail.
3. Confirmer l’adresse depuis l’e-mail reçu.
4. Retour automatique sur Couteau Suisse.
5. Safari > Partager > Sur l’écran d’accueil > Ajouter.

Android :
1. Aller sur le site.
2. Renseigner Nom + Prénom + Adresse e-mail.
3. Confirmer l’adresse depuis l’e-mail reçu.
4. Retour automatique sur Couteau Suisse.
5. Chrome > menu ⋮ > Installer l’application ou Ajouter à l’écran d’accueil > Installer/Ajouter.

La vidéo reste supprimée. Les anciens comptes conservent le comportement V305 : ils ne refont pas l’inscription.
