COUTEAU SUISSE V293 — AFFICHAGE POINTS

- Classement : maximum 2 décimales.
- Séparateur décimal français : virgule.
- Exemples : 703.120798 -> 703,12 pts ; 174.00504999999998 -> 174,01 pts ; 192 -> 192 pts.
- Même format appliqué aux panneaux de points du concours.
- Aucune modification du calcul réel des points : uniquement l’affichage.
- Cache ciblé : seul le module concours change de version.
