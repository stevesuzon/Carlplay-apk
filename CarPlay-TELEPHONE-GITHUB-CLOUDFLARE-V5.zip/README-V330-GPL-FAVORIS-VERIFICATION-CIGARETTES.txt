V330 — STATIONS GPL : FAVORI + VERIFICATION

- L’étoile est uniquement le bouton Favori : ☆ / ★.
- Le petit rond en haut à droite est orange si le GPL reste à vérifier et vert après vérification.
- Une station GPL officiellement accessible 24/24 sans boutique reste mise en évidence en vert.
- Les autres stations GPL affichent « GPL À VÉRIFIER ».
- Vérification simplifiée : paiement GPL = Espèces / Carte / Les deux.
- Ajout Cigarettes = Oui / Non dans la vérification.
- Après confirmation, le rond orange passe au vert.
- Les favoris sont mémorisés localement sur le téléphone.
- Les vérifications sont enregistrées en D1 et partagées entre utilisateurs.
