V272 — Correction faux auto-parrainage

- Corrige le cas où l'e-mail du filleul avait été copié par erreur sur la fiche du parrain lors d'une ancienne tentative.
- L'auto-parrainage est maintenant vérifié avec l'identité concours stable du parrain, pas seulement avec le champ e-mail mutable de l'abonnement.
- Si le téléphone du filleul a hérité de l'identifiant du parrain, un nouvel identifiant est créé automatiquement.
- Si une ancienne donnée rattache encore le filleul au compte du parrain, une fiche filleul séparée est créée.
- Les récompenses restent : filleul +96 points, parrain +320 points après validation de l'e-mail.
- Le parrainage ne bloque pas l'ouverture de Couteau Suisse.
- Cache/service worker V272 pour éviter de garder le JavaScript V271.
