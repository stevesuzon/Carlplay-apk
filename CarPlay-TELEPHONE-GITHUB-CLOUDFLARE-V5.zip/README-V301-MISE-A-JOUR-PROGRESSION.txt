COUTEAU SUISSE — V301

MISE À JOUR DANS RÉGLAGES
- Un appui sur « MISE À JOUR » ouvre une bulle plein écran.
- Barre de progression visible de 0 à 100 %.
- Le texte indique en direct ce qui est contrôlé :
  * dernière version disponible ;
  * application / page d’accueil / réglages ;
  * concours / points / bonus / trajets ;
  * marchés France, Belgique, brocantes, Noël et voyageurs ;
  * Champignons ;
  * notifications ;
  * compte / abonnement.
- À 100 %, la bulle indique « MISE À JOUR TERMINÉE » puis permet de recharger l’application.
- En cas de coupure Internet, un message clair s’affiche.

CACHE
- Pas de suppression globale de tous les caches depuis le bouton Mise à jour.
- Le cache de base est versionné V301 car l’interface des Réglages a changé.
- Les autres modules gardent leurs caches séparés et ne sont remplacés que lorsque nécessaire.
- localStorage / données utilisateur / adresses / devis / photos / GPS / abonnement ne sont pas effacés.
