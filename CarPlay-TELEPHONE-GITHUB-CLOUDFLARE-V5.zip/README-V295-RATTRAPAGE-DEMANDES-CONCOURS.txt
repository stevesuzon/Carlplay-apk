COUTEAU SUISSE — V295 — RATTRAPAGE DEMANDES CONCOURS

Correction importante :
- Les demandes concours ne sont plus supprimées/expirées automatiquement après 24 heures.
- Les anciennes demandes marquées "expired" par les versions précédentes sont automatiquement remises en attente lors de l’ouverture de l’administration.
- Cela concerne : fiches marché, fiches Champignons, bugs/problèmes, demandes de changement de commune et alertes déplacement.
- Aucune demande récupérée n’est validée automatiquement : Steve garde le contrôle.
- Quand Steve appuie sur VALIDER, les points prévus pour cette fiche sont attribués par la logique existante et le classement est mis à jour.
- Les demandes déjà approuvées/refusées ne sont pas rouvertes.
- Le parrainage reste automatique comme prévu.
- Mise à jour de cache ciblée : seule la version du service worker est incrémentée ; les caches de données/adresses/devis ne sont pas vidés.
