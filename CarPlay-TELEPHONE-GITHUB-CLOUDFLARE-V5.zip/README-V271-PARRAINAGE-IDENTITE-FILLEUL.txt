V271 — PARRAINAGE : IDENTITÉ DU FILLEUL CORRIGÉE

- Si le filleul saisit une adresse e-mail différente de celle du parrain, il n’est plus bloqué à tort par « On ne peut pas se parrainer soi-même ».
- Si son navigateur/PWA a hérité de l’identifiant appareil du parrain, Couteau Suisse recrée automatiquement un identifiant propre au filleul puis relance l’envoi de l’e-mail.
- L’adresse e-mail identique à celle du parrain reste bloquée pour empêcher un vrai auto-parrainage.
- Les récompenses ne changent pas : +96 points pour le filleul et +320 points pour le parrain après validation par e-mail.
- Le parrainage reste non bloquant.
- Cache Service Worker passé en V271.
