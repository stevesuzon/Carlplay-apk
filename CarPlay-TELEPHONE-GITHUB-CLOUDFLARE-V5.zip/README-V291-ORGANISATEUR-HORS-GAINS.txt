COUTEAU SUISSE V291 — ORGANISATEUR HORS GAINS

- Steve Suzon reste dans le classement et continue de cumuler ses points.
- Une mention « ORGANISATEUR — HORS GAINS » est affichée à côté de son nom.
- Steve Suzon est automatiquement exclu du calcul final des gagnants.
- Si l’organisateur est devant les autres participants, les lots remontent vers les participants éligibles suivants.
- Les 5 récompenses restent donc attribuées à 5 participants éligibles.
- La règle est également ajoutée dans les règles du concours.
- Mise à jour ciblée du module Concours uniquement ; les autres caches et données restent inchangés.
