V256 — ADMINISTRATION CONCOURS / DEMANDES À VALIDER

- La section CONCOURS affiche uniquement le nombre total de participants.
- Elle est placée juste au-dessus de DEMANDES À VALIDER.
- Suppression de la liste des participants récents / messages dans la section Concours.
- Les demandes du concours, signalements, changements de commune, alertes et messages sont regroupés dans DEMANDES À VALIDER.
- Une demande concours/message reste au maximum 24 heures si elle n'est pas traitée.
- Dès validation/refus/fermeture, elle disparaît de la liste.
- Cliquer sur le nom / VOIR LA FICHE ouvre le détail rempli par la personne.
- Validation d'une fiche concours attribue les points prévus automatiquement via le système existant.
- Les demandes courtes de modification de marché conservent leur fonctionnement et leur délai propre.
