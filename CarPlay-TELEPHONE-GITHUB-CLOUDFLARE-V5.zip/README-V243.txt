COUTEAU SUISSE V243

- Administration : affiche seulement le nombre de personnes installées sur l’écran d’accueil.
- Récupération du compteur depuis les historiques D1 disponibles (installations, identités, abonnements, concours).
- Suppression de la section « Mises à jour des marchés » dans l’administration.
- Messages reçus : bouton de bannissement conservé directement sur la carte du message.
- Champignons : modèle vision Google Gemma 4 26B A4B via Workers AI.
- La liaison Cloudflare doit être Workers AI avec le nom AI sur la version effectivement déployée.
