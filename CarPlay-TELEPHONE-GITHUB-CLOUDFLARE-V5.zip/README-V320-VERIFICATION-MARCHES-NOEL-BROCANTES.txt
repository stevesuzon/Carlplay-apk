COUTEAU SUISSE — V320

Vérification communautaire étendue aux fiches spéciales.

- Marché de Noël : champ dédié « Nombre de chalets ».
- Brocante / vide-grenier / foire : champ « Nombre d’emplacements / exposants ».
- Marché voyageur : champ « Nombre d’emplacements / exposants ».
- Réutilise le même serveur de vérification que les marchés : horaire, capacité, GPS et photo.
- Les fiches spéciales envoient maintenant leur type à l’écran de vérification pour afficher les bons libellés.
- Les champs spécifiques aux marchés classiques (tirage, humeur du placier, responsable, modèle de clients) sont masqués pour Noël et brocante/foire afin d’éviter les renseignements sans rapport.
- Les corrections validées sont reflétées sur la fiche avec le bon libellé de capacité.
- Cache principal passé en V320 pour forcer la prise en compte de l’interface mise à jour.
