V360 — Compteurs administrateur

Écran d’accueil : comptes confirmés détectés lors d’une ouverture en mode installé. Les anciennes installations seront reconnues à leur prochaine ouverture après mise à jour.
Total utilisateurs : tous les comptes enregistrés avec e-mail confirmé, y compris depuis le navigateur. Décompte par e-mail unique ; ce n’est pas le nombre de personnes connectées en ce moment.
Les nouveaux compteurs sont réservés à l’administration.
Les données et les pages des marchés restent inchangées.
