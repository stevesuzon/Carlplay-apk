VERSION V275 — ADMINISTRATEUR : TOUT MODIFIER

- Seule la session administrateur confirmée de Steve Suzon
  (appli.suzon@gmail.com) possède ces droits.
- Toutes les informations déjà validées d'une fiche marché restent visibles
  et modifiables directement par l'administrateur.
- L'administrateur peut corriger sans demande d'autorisation : existence,
  horaire, nombre de commerçants, tirage, modèle de clients, humeur du placier,
  responsable, GPS et photo.
- La limite de deux remplacements de photo, la comparaison avec l'ancienne
  photo et la distance de 130 m ne bloquent plus l'administrateur.
- Les utilisateurs ordinaires conservent toutes les règles et validations.
- L'identification sécurisée par code reçu sur l'adresse e-mail administrateur
  reste obligatoire. Les données, abonnements et points existants sont conservés.
