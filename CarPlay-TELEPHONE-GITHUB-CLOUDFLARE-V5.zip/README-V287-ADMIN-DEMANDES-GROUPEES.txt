COUTEAU SUISSE — V287

- Les anciennes fiches d’identité sans adresse e-mail valide sont supprimées lors du chargement administrateur.
- Aucun abonnement, point, adresse, devis ou donnée métier n’est supprimé.
- La section séparée « Personnes bannies » est retirée : Bannir / Débannir reste centralisé dans « Voir tous les utilisateurs ».
- « Demandes à valider » affiche le nombre total de demandes en attente.
- Un appui sur ce nombre ouvre la liste des personnes, avec le nombre de messages/demandes pour chacune.
- Un appui sur une personne ouvre ses demandes ; un appui sur une demande ouvre la fiche complète avant validation/refus.
- Les demandes de points (fiche marché, coin/fichier Champignons, bug/problème) affichent les points à confirmer.
- Après validation, les points sont attribués immédiatement au classement et la demande disparaît du compteur.
- La personne reçoit un message/notification « Bravo » confirmant la validation et les points gagnés.
- Cache ciblé : seul le module Administration est versionné V287 ; les autres caches restent inchangés.
