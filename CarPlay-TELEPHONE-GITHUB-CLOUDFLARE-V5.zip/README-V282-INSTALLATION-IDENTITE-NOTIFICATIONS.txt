V282 — INSTALLATION + IDENTITÉ + NOTIFICATIONS COMPLÈTES
Date : 16/09/2026

1) Parcours d’installation
- La page d’installation affiche d’abord le bouton TÉLÉCHARGER L’APPLICATION en gris et bloqué.
- Le bouton REGARDER LA VIDÉO AVANT INSTALLATION lance le tutoriel.
- Le téléchargement ne se débloque qu’une fois la vidéo terminée.
- Après la vidéo, le bouton TÉLÉCHARGER L’APPLICATION devient bleu.

2) Identification obligatoire avant ouverture du site
- Le bouton bleu ouvre la page Nom + Prénom + Adresse e-mail.
- Les 3 champs sont obligatoires.
- L’adresse e-mail doit avoir un format complet valide (ex. nom@domaine.fr, nom@domaine.com, etc.).
- Le bouton ACTIVER L’ABONNEMENT reste gris tant que les 3 champs ne sont pas valides, puis devient vert.
- Après activation, l’utilisateur arrive sur le site pour l’ajouter à l’écran d’accueil.
- Nom, prénom et e-mail sont mémorisés pour Réglages.

3) Abonnement
- Si l’adresse e-mail correspond à un abonnement actif existant et que l’identité correspond, le même abonnement est rattaché au téléphone avec sa date de fin existante.
- Pour un nouvel utilisateur pendant la période gratuite globale, l’accès suit la date de fin globale existante.
- Après la période globale, un nouvel utilisateur reçoit une seule période d’essai de 7 jours conformément à la logique serveur existante.

4) Notifications
- En touchant une notification système, Couteau Suisse ouvre maintenant une fiche dans l’application avec le titre et le texte complet de la notification.
- La fiche contient un bouton OUVRIR LA PAGE CONCERNÉE pour continuer vers la page liée à la notification.

5) Cache / mises à jour
- Service worker passé en V282.
- Nouveau cache couteau-suisse-v282-onboarding-notification-detail.
- Le nettoyage de cache a été mis à jour afin de ne pas supprimer le nouveau cache V282.
