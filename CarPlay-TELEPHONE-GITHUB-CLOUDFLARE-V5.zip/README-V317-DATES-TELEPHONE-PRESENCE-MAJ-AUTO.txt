COUTEAU SUISSE — V317
DATES + TÉLÉPHONE + PRÉSENCE + MISE À JOUR AUTOMATIQUE

- Brocante / Vide-grenier / Foire : la date reste affichée sur chaque fiche.
- Si un numéro de téléphone est disponible dans la donnée, un bouton vert « APPELER » apparaît automatiquement. Aucun faux numéro n’est inventé.
- Le bouton de navigation s’adapte : ALLER À LA BROCANTE, ALLER À LA FOIRE, ALLER AU VIDE-GRENIER, ALLER AU MARCHÉ DE NOËL ou ALLER AU MARCHÉ.
- Marchés de voyageurs : bouton « ALLER AU MARCHÉ VOYAGEUR » et bouton vert « APPELER » si téléphone publié.
- Quand une personne confirme qu’elle y va, sa présence est enregistrée pour la journée seulement. Les fiches affichent ensuite 1 personne / N personnes de l’appli qui indiquent y aller aujourd’hui.
- Le comptage est indépendant du métier ; le compteur métier existant reste conservé.
- Les données serveur des marchés sont recherchées automatiquement au chargement, au retour dans l’app, lors du retour en ligne et toutes les 5 minutes. Les listes se rechargent si une nouvelle version serveur est disponible.
- Le serveur accepte maintenant les champs phone/téléphone, dateLabel/date, start/end, sourceUrl et les types marché, brocante, Noël et voyageur.
- Les marchés de voyageurs et les catégories spéciales peuvent donc recevoir de nouvelles fiches serveur sans nouvelle version de l’application.
- La confirmation avant « Effacer l’emplacement » des versions précédentes est conservée.

IMPORTANT : la mise à jour automatique récupère les nouvelles informations présentes sur le serveur Couteau Suisse. Un numéro n’est affiché que lorsqu’une source ou une fiche l’a réellement fourni.
