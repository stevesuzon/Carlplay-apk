V270 — PARRAINAGE NON BLOQUANT

- Base : V269 complète.
- L’écran « Valider le parrainage » ne peut plus bloquer Couteau Suisse.
- Ajout du bouton « PLUS TARD — OUVRIR COUTEAU SUISSE ».
- Après l’envoi de l’e-mail, l’application reste utilisable immédiatement et l’écran se ferme automatiquement.
- La validation dans l’e-mail conserve les récompenses : filleul +96 points, parrain +320 points.
- Les points sont toujours attribués côté serveur lors de la validation du parrainage ; si l’un des deux n’est pas encore inscrit au concours, sa récompense reste en attente et est appliquée dès son inscription.
- Cache Service Worker et version du script de parrainage passés en V270.
