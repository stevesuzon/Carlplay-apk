V311 — DEMANDES ADMINISTRATEUR DANS LES RÉGLAGES

- Le bloc « VOUS AVEZ N DEMANDE(S) À CONTRÔLER » reste visible comme sur l’écran Réglages.
- Un appui ouvre maintenant directement de petits carrés par personne avec : nom, adresse e-mail et nombre de demandes.
- Un appui sur une demande ouvre son détail AVANT les boutons de confirmation.
- Les fiches Marché affichent la photo à contrôler quand elle existe.
- Les fiches Champignons affichent leur photo quand elle existe.
- Les bugs / idées affichent le texte complet avant validation.
- Les boutons OUI / NON ne sont visibles qu’après ouverture du détail.
- Après validation d’une fiche avec points, l’utilisateur reçoit un message « FICHE CONFIRMÉE » avec le nombre de points confirmé / ajouté.
- Sous les demandes, une section « DERNIÈRES FICHES CONFIRMÉES » affiche les derniers utilisateurs et leurs points (ex. « Toni Mordan a gagné 17 pt »).
- Le tableau Administration complet affiche aussi l’adresse e-mail sous le nom.
- Cache ciblé Administration / Abonnement passé en V311.
