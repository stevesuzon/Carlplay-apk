COUTEAU SUISSE V244

- Section Champignons réservée : 50 € / 2 ans.
- Code Champignons généré uniquement par Steve depuis Administration > Générateur de codes.
- Un code non généré est refusé ; un code utilisé ne peut pas être réutilisé.
- Les codes Champignons sont cumulables : chaque code ajoute 730 jours.
- Abonnement Champignons lié au même subscription_id que le compte principal : récupération sur nouveau téléphone avec le compte principal.
- Une fois actif, le champ de code disparaît et affiche « Abonnement confirmé » + jours restants.
- Avertissement affiché à 30 jours ou moins de l’expiration.
- Voir les coins : « Sur mon trajet » (maximum 10 km de détour, calcul routier OSRM avec repli géographique) ou « À moins de 100 km » du point Retourner sur la place.
- Aucun nom d’adresse n’est affiché ; uniquement « Aller à ce bois » via coordonnées GPS.
- Les photos des coins ne sont plus publiquement accessibles : URL signée temporaire.
- Chaque champignon affiche catégorie, saison indicative et type d’habitat à rechercher.
- Reconnaissance IA conservée via Workers AI binding AI.
