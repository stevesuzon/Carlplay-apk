COUTEAU SUISSE V285 — COMPTEUR UTILISATEURS

- Toute visite de la page d’accueil est enregistrée avec un identifiant appareil local, sans compte obligatoire.
- Une même personne sur le même téléphone/navigateur reste comptée une seule fois.
- Le total cumulé regroupe visites/app installée et sources déjà connues (identité, abonnement, concours), sans ajouter plusieurs fois le même device_id.
- À côté du compteur « connecté(s) » : total cumulé toujours visible.
- Tous les 15 jours : « +X utilisateur(s) en plus depuis 15 jours ».
- Cette ligne reste visible 2 jours puis disparaît automatiquement.
- Le total cumulé, lui, ne disparaît jamais.
- Cache ciblé : nouveau module user-stats-v285 uniquement ; données utilisateurs persistantes non modifiées.
