V247 — CORRECTION ENVOI PHOTO IPHONE

- Suppression de la construction d'adresse qui pouvait provoquer « The string did not match the expected pattern ».
- En-têtes d'envoi reconstruits avec l'API Headers et secret administrateur nettoyé.
- Envoi sur les mêmes routes Cloudflare, sans changement de la base D1 ni des bindings.
- La photo, le GPS et le nom du marché sont transmis ensemble.
- Après validation, la fiche peut alimenter les points du concours comme dans la V246.
- Les photos validées apparaissent seules en petite taille sur les fiches et s'ouvrent en grand au toucher.
- Ce comportement couvre les marchés, brocantes, voyageurs et champignons sans retirer les informations, « Modifier » ni « Aller ».
- Le classement ouvert se réactualise automatiquement toutes les 5 secondes : nouveaux joueurs et points validés apparaissent directement.
- Liaison Workers AI conservée sous le nom AI.
