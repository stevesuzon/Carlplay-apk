COUTEAU SUISSE V292 — MARCHÉS AUTOUR / COMPTEURS / ADMIN

- Conserve toutes les modifications V291 du concours (Steve Suzon organisateur hors gains).
- Accueil : deux boutons de même taille :
  * Marchés à moins de 80 km
  * Marchés autour de moi
- Sous le bouton Marchés autour de moi : « Pas de place sur le marché ? Regardez autour de moi ».
- Marchés autour de moi : utilise le GPS ACTUEL du téléphone, affiche uniquement les marchés d’AUJOURD’HUI à 15 km maximum, triés du plus proche au plus éloigné.
- En-tête : « Si vous n’avez pas eu d’emplacement, ces marchés s’affichent autour du GPS où vous êtes actuellement. »
- Les fiches 15 km réutilisent les données existantes (photo, horaires, places, tirage, GPS, vérifications, navigation).
- Compteur de concurrence ajouté aux fiches de la recherche 80 km et 15 km.
- Le choix « Aller au marché » enregistre aussi la présence pour l’administration.
- Mode administrateur : troisième bouton « Marchands inscrits » uniquement s’il existe au moins une personne identifiée avec un métier sur ce marché.
- Ce bouton affiche nom + prénom + métier. S’il n’y a personne avec métier, il n’apparaît pas.
- Aucun effacement des adresses, devis, Mes papiers, Démarches pro, GPS, photos ou données concours.
- Cache ciblé : module interface marchés uniquement ; module concours V291 conservé.
