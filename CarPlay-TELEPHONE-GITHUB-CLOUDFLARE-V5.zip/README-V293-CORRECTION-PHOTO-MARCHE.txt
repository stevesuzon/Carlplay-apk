COUTEAU SUISSE V293 — CORRECTION ENVOI PHOTO MARCHÉ

- Correction de l’erreur « REPONSE_SERVEUR_INVALIDE ».
- L’application vérifie désormais que la réponse de l’API est bien du JSON et utilise le Worker officiel en secours si la page installée est servie depuis une autre origine.
- La photo est compressée plus prudemment avant envoi.
- En cas d’erreur HTTP serveur ou de taille, un second essai automatique est fait avec une photo plus légère.
- La photo choisie reste en mémoire après un échec : l’utilisateur peut réappuyer sur ENREGISTRER sans reprendre la photo.
- Le Worker renvoie toujours une réponse JSON sur /api/market-verifications, même si une erreur interne survient.
- Si le stockage R2 échoue temporairement, un secours D1 est tenté avant de refuser l’envoi.
- Aucune adresse, devis, fiche ou autre donnée utilisateur n’est effacée.
- Mise à jour ciblée : seuls la vérification de marché, le traitement serveur photo, le numéro de version et le service worker sont modifiés.
