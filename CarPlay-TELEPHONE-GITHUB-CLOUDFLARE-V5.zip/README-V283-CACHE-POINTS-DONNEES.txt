COUTEAU SUISSE V283

- Cache ciblé par module : une mise à jour ne vide plus tout le cache de l'application.
- Icônes/manifest versionnés V283 pour forcer au maximum l'actualisation du logo.
- Adresses et devis protégés hors cache + sauvegarde IndexedDB et restauration si une clé locale manque.
- Concours : dernier classement affiché immédiatement depuis le téléphone, puis synchronisation serveur.
- Quand le concours est ouvert : synchronisation légère du score toutes les 3 secondes.
- Administration : demandes rafraîchies toutes les 3 secondes.
- Les points ne sont JAMAIS attribués avant validation de l'administrateur.
- Après VALIDER, le serveur inscrit automatiquement les points et le classement utilisateur se met à jour.
