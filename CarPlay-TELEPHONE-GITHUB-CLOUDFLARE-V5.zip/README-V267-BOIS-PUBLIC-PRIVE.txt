V267 — Catégorie du bois

- Dans « Ajouter un bois », la personne doit choisir exactement une catégorie :
  • Bois public
  • Bois privé
- Aucun troisième choix.
- Les deux choix sont exclusifs.
- Impossible d’enregistrer la fiche sans choisir Public ou Privé.
- La fiche affiche ensuite clairement PUBLIC ou PRIVÉ.
- La modification d’une fiche propose les mêmes deux choix.
- Toutes les fonctions V266 sont conservées : GPS, photo sur place, reconnaissance champignon, plusieurs variétés, distance Retourner sur la place, détour 15 km, concours.
