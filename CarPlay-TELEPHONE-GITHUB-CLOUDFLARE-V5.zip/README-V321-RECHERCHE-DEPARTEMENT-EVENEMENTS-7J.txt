COUTEAU SUISSE — V321

RECHERCHE DÉPARTEMENT + ÉVÉNEMENTS À 7 JOURS

- La section des marchés classiques n'a pas été modifiée.
- Dans Marchés de Noël, Brocante / Vide-grenier / Foire, Marchés saisonniers et Marchés périodiques, la recherche France accepte directement un numéro de département. Exemple : saisir 91 affiche les fiches du département 91 dans la catégorie ouverte.
- La recherche texte par commune ou nom reste disponible.
- En Belgique, la recherche reste par commune, nom ou province.
- Dans « Marchés à moins de 80 km », les marchés hebdomadaires gardent le fonctionnement aujourd'hui / demain existant.
- Les foires, brocantes, vide-greniers, braderies et marchés de Noël datés apparaissent dès que leur début est à 7 jours ou moins.
- Un événement en cours reste affiché jusqu'à sa date de fin. Dès que la date de fin est passée, il disparaît de la vue ≤80 km.
- Les libellés de navigation s'adaptent : ALLER À LA FOIRE, ALLER À LA BROCANTE, ALLER AU VIDE-GRENIER ou ALLER AU MARCHÉ DE NOËL.
- Les compléments brocante V316 et les fiches serveur déjà synchronisées sont pris en compte dans la vue spéciale ≤80 km quand un GPS exploitable est disponible.
- Cache principal passé en V321.
