COUTEAU SUISSE — V252

Récupération d’un abonnement existant :
- L’utilisateur renseigne nom, prénom et adresse e-mail lors de l’ouverture de l’application.
- L’application ne remplace pas automatiquement un ancien abonnement par une nouvelle période.
- Dans Réglages > Abonnement, le bouton « ME FAIRE RENVOYER MON CODE D’ABONNEMENT » renvoie le code associé à la même identité/e-mail.
- Après saisie du code reçu, le même abonnement est restauré avec les jours qu’il lui restait.
- Exemple : s’il restait 2 mois et demi, il retrouve ces 2 mois et demi.
- Pour un nouvel utilisateur sans abonnement existant, la période d’essai reste disponible selon les règles déjà prévues.
- L’accès Champignons gratuit pendant l’essai conserve exactement la même date de fin que l’essai principal.
