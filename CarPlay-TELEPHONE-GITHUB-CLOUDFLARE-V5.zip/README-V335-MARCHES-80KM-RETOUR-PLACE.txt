V335 — Marchés à moins de 80 km / Retourner sur la place

- Le calcul des 80 km utilise uniquement les coordonnées enregistrées par « Retourner sur la place » (return_lat / return_lon).
- Aucun basculement automatique sur la position GPS actuelle : si aucune place n’est enregistrée, la page demande d’abord d’enregistrer « Retourner sur la place ».
- La page ne charge plus toute la base France + Belgique au démarrage.
- Les données sont découpées en petits fichiers par département/province et seules les zones proches de la place enregistrée sont chargées.
- Les foires, brocantes, braderies, marchés de Noël et marchés réguliers restent pris en compte lorsqu’ils disposent d’un point GPS exploitable.
- Les marchés découverts automatiquement déjà présents dans le cache serveur du téléphone restent intégrés quand ils sont dans la zone.
- Objectif : supprimer le blocage du téléphone lors de l’ouverture « Marchés à moins de 80 km » et réduire fortement le travail inutile.
