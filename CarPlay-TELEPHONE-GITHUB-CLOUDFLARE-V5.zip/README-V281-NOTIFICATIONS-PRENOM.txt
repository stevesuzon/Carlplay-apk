V281 — NOTIFICATIONS AVEC PRÉNOM

- Toute nouvelle version de l’application affiche la grande notification de mise à jour, quel que soit le module concerné.
- Une modification de marché acceptée crée une annonce commune visible à la réouverture de l’application.
- Le prénom réel fourni dans la demande apparaît en haut de la grande bulle : « Tony a mis à jour ».
- Le message précise le nom du marché et l’élément modifié : horaires, GPS, photo, nombre de commerçants, tirage au sort, accueil, responsable ou présence.
- Le même fonctionnement couvre les marchés hebdomadaires, voyageurs, brocantes et les autres catégories utilisant la fiche marché commune.
- Les annonces respectent le réglage général Notifications ON/OFF.
- Les comptes, abonnements, points, fiches, photos, GPS, horaires, devis, signatures et lots restent inchangés.
