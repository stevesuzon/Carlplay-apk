V327 — STATIONS ≤ 15 KM / GPL FACILE

- Les prix sont relus à l’ouverture, au changement de carburant et avec le bouton ACTUALISER.
- Réactualisation automatique toutes les 5 minutes lorsque la page est visible.
- Au retour sur la page, nouvelle lecture si la dernière date de plus de 2 minutes.
- Le Worker garde au maximum 120 secondes de cache sur le flux officiel français.
- Badge « GPL FACILE » si la station déclare du GPL disponible, un automate 24/24 et aucune boutique dans les services publiés.
- Le tri reste du prix le moins cher au plus cher, puis par distance.
