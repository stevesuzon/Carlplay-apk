COUTEAU SUISSE V308 — CORRECTION PAGE D’INSTALLATION QUI SE RECHARGE

Problème trouvé :
- Cloudflare injectait les scripts complets de l’application dans installer.html.
- subscription-web.js enregistrait /sw.js avec une URL de version différente de celle enregistrée par installer.html.
- Les deux enregistrements pouvaient se remplacer et déclencher controllerchange + location.reload(), donnant une page qui se recharge en boucle chez un nouveau destinataire.

Corrections :
1. installer.html est exclue de l’injection HTML globale du Worker.
2. installer.html n’enregistre plus de service worker : cette page d’accueil partagée reste légère et stable.
3. Toutes les autres pages utilisent la même URL de service worker V308.
4. Le rechargement automatique après changement de service worker est limité à une seule fois par session.
5. Le script de nettoyage de cache conserve désormais le cache d’installation V308 au lieu de le supprimer.
6. Le parcours Nom + Prénom + e-mail + confirmation et la compatibilité anciens comptes sont conservés.

Aucune donnée utilisateur n’est supprimée.
