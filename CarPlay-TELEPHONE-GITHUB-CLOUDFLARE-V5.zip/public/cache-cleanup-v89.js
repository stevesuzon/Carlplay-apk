(function automaticCacheCleanup(){
  'use strict';
  var VERSION='20260902-v89-photo-130m-reconnaissance';
  var CURRENT_CACHE='carplay-v5-20260902-v89-photo-130m-reconnaissance';
  var KEY='carplay_cache_cleanup_version';
  var BACKUP_KEY='carplay_update_local_backup';
  try{
    var oldBackup=sessionStorage.getItem(BACKUP_KEY);
    if(oldBackup){
      var oldValues=JSON.parse(oldBackup),oldNames=Object.keys(oldValues);
      for(var r=0;r<oldNames.length;r++)if(localStorage.getItem(oldNames[r])===null)localStorage.setItem(oldNames[r],oldValues[oldNames[r]]);
      sessionStorage.removeItem(BACKUP_KEY);
    }
    if(localStorage.getItem(KEY)===VERSION)return;
    var backup={},i,name;
    for(i=0;i<localStorage.length;i++){
      name=localStorage.key(i);
      if(name&&name!=='carplay_admin_secret'&&name!=='carplay_admin_here')backup[name]=localStorage.getItem(name);
    }
    sessionStorage.setItem(BACKUP_KEY,JSON.stringify(backup));
    var cleanup=('caches' in window?caches.keys().then(function(keys){
      return Promise.all(keys.filter(function(key){return key!==CURRENT_CACHE}).map(function(key){return caches.delete(key)}));
    }):Promise.resolve());
    cleanup.then(function(){
      if('serviceWorker' in navigator)return navigator.serviceWorker.getRegistrations().then(function(registrations){
        return Promise.all(registrations.map(function(registration){return registration.update().catch(function(){})}));
      });
    }).then(function(){localStorage.setItem(KEY,VERSION)}).catch(function(){});
  }catch(e){}
})();
