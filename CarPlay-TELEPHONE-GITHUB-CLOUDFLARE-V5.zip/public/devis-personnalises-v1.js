
(function(){
  'use strict';

  var TEMPLATES_KEY='custom_quote_templates_v1';
  var HOUSE_QUOTES_KEY='house_custom_quotes_v1';
  var DOCS_KEY='generic_client_documents';

  function qs(s,r){return (r||document).querySelector(s)}
  function qsa(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))}
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function money(v){var n=Number(v||0);return n.toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})+' €'}
  function uid(p){return (p||'id')+'-'+Date.now()+'-'+Math.random().toString(36).slice(2,8)}
  function load(k,d){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?d:v}catch(e){return d}}
  function save(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){alert("Mémoire pleine : impossible d'enregistrer.");return false}}
  function templates(){var a=load(TEMPLATES_KEY,[]);return Array.isArray(a)?a:[]}
  function docs(){var a=load(DOCS_KEY,[]);return Array.isArray(a)?a:[]}
  function addrKeys(){return ['saved_market_addresses','saved_market_addresses_be']}
  function getAddressById(id){
    for(var i=0;i<2;i++){
      var key=addrKeys()[i], arr=load(key,[]);
      if(!Array.isArray(arr)) continue;
      var idx=arr.findIndex(function(x){return x&&x.id===id});
      if(idx>=0)return {key:key,arr:arr,idx:idx,item:arr[idx]};
    }
    return null;
  }
  function clientName(x){return String((x&&x.personName)||[((x&&x.firstName)||''),((x&&x.lastName)||'')].join(' ')).trim()}
  function fmtDate(v){try{return new Date(v).toLocaleDateString('fr-FR')}catch(e){return ''}}

  function ensureStyles(){
    if(qs('#customQuoteStyles'))return;
    var s=document.createElement('style'); s.id='customQuoteStyles';
    s.textContent=`
    .cqBtn{border:0;border-radius:12px;padding:12px 13px;font-weight:950;cursor:pointer}
    .cqPrimary{background:#f39b19;color:#151515}.cqDanger{background:#b72727;color:#fff}.cqSoft{background:#24364c;color:#fff;border:1px solid #56708e}
    #cqOverlay,#cqEditor{display:none;position:fixed;inset:0;z-index:2147483647;background:#000d;padding:14px;overflow:auto}
    #cqOverlay.open,#cqEditor.open{display:block}
    .cqPanel{width:min(620px,96vw);margin:4vh auto;background:#101b29;color:#fff;border:3px solid #f39b19;border-radius:20px;padding:18px;box-shadow:0 18px 50px #000c}
    .cqPanel h2{text-align:center;margin:2px 0 16px}
    .cqField{margin:10px 0}.cqField label{display:block;font-size:13px;font-weight:950;color:#ffd179;margin-bottom:5px}
    .cqField input,.cqField select,.cqField textarea{width:100%;padding:12px;border-radius:11px;border:2px solid #425b75;background:#08121d;color:#fff;font-size:16px}
    .cqGrid{display:grid;grid-template-columns:1fr 1fr;gap:9px}.cqActions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.cqActions>*{flex:1 1 135px}
    .cqTemplate{padding:12px;border:1px solid #49627e;border-radius:14px;background:#0b1420;margin:9px 0}
    .cqTemplateHead{display:flex;align-items:center;gap:10px}.cqTemplateLogo{width:68px;height:48px;object-fit:contain;background:#fff;border-radius:8px}
    .cqQuoteList{margin:10px 0 0;padding:10px;border:1px solid #45617b;border-radius:12px;background:#09121c}
    .cqQuoteRow{padding:8px 0;border-bottom:1px solid #30445a}.cqQuoteRow:last-child{border-bottom:0}
    .savedAddressQuote{background:#8144d6!important;color:#fff!important;border:0!important;border-radius:12px!important;padding:12px!important;font-weight:950!important;text-decoration:none!important}
    .cqHouseBox{margin:12px 0;padding:12px;border:2px solid #8151ce;border-radius:14px;background:#160d23}
    #cqSignature{width:100%;height:150px;background:#fff;border-radius:10px;touch-action:none;display:block}
    .cqTotal{font-size:24px;font-weight:950;color:#ffd36d;text-align:right;margin:10px 0}
    @media(max-width:600px){.cqGrid{grid-template-columns:1fr}.cqPanel{margin:1vh auto}.cqTemplateHead{align-items:flex-start}}@media print{@page{size:A4 portrait;margin:12mm}body *{visibility:hidden!important}#cqEditor,#cqEditor *{visibility:visible!important}#cqEditor{display:block!important;position:static!important;background:#fff!important;padding:0!important;color:#000!important;overflow:visible!important}#cqEditor .cqPanel{width:186mm!important;max-width:186mm!important;min-height:273mm!important;margin:0 auto!important;background:#fff!important;color:#000!important;border:0!important;border-radius:0!important;box-shadow:none!important;padding:8mm!important}#cqEditor .cqActions,#cqEditor #cqClearSign{display:none!important}#cqEditor input,#cqEditor select{border:1px solid #999!important;background:#fff!important;color:#000!important}#cqEditor .cqField label{color:#000!important}#cqEditor .cqTotal{color:#000!important}#cqClientInfo{background:#fff!important;color:#000!important;border:1px solid #bbb!important}#cqSignature{border:1px solid #999!important}}
    `;
    document.head.appendChild(s);
  }

  function installSettingsButton(){
    var settings=qs('#settings'); if(!settings||qs('#customQuoteSettingsRow'))return;
    var row=document.createElement('div'); row.className='settingRow'; row.id='customQuoteSettingsRow';
    row.innerHTML='<button class="settingHead" type="button"><span>🧾 CRÉER SES DEVIS</span><span>›</span></button><div class="settingNote" style="padding:9px 12px">Créez vos propres modèles, choisissez leur nom, votre logo et où ils doivent apparaître.</div>';
    var close=qs('.closeSettings',settings);
    if(close)settings.insertBefore(row,close);else settings.appendChild(row);
    qs('.settingHead',row).onclick=function(){openManager()};
  }

  function ensureManager(){
    if(qs('#cqOverlay'))return;
    var o=document.createElement('div');o.id='cqOverlay';
    o.innerHTML=`<div class="cqPanel">
      <h2>🧾 CRÉER SES DEVIS</h2>
      <div id="cqTemplateList"></div>
      <hr style="border-color:#34495f;margin:16px 0">
      <input type="hidden" id="cqTemplateId">
      <div class="cqField"><label>NOM DU DEVIS</label><input id="cqTemplateName" placeholder="Ex. Nettoyage toiture, Maçonnerie, Brocante..."></div>
      <div class="cqField"><label>LOGO</label><input id="cqTemplateLogoInput" type="file" accept="image/*"><div id="cqLogoPreview" style="margin-top:7px"></div></div>
      <div class="cqField"><label>OÙ CE DEVIS DOIT APPARAÎTRE PAR DÉFAUT ?</label>
        <select id="cqTemplateDestination"><option value="address">Carnet d'adresses</option><option value="house">Mesurer ma maison</option></select>
      </div>
      <div class="cqActions">
        <button class="cqBtn cqPrimary" id="cqSaveTemplate">💾 ENREGISTRER LE MODÈLE</button>
        <button class="cqBtn cqSoft" id="cqNewTemplate">＋ NOUVEAU</button>
        <button class="cqBtn cqDanger" id="cqCloseManager">FERMER</button>
      </div>
    </div>`;
    document.body.appendChild(o);
    var logoData='';
    qs('#cqTemplateLogoInput').onchange=function(){
      var f=this.files&&this.files[0]; if(!f)return;
      var r=new FileReader();r.onload=function(){resizeLogo(String(r.result||''),function(v){logoData=v;showLogo(v)})};r.readAsDataURL(f);
    };
    function showLogo(v){qs('#cqLogoPreview').innerHTML=v?'<img src="'+v+'" style="max-width:160px;max-height:80px;background:#fff;border-radius:8px;padding:4px">':''}
    function reset(){qs('#cqTemplateId').value='';qs('#cqTemplateName').value='';qs('#cqTemplateDestination').value='address';qs('#cqTemplateLogoInput').value='';logoData='';showLogo('')}
    qs('#cqNewTemplate').onclick=reset;
    qs('#cqCloseManager').onclick=function(){o.classList.remove('open')};
    qs('#cqSaveTemplate').onclick=function(){
      var name=qs('#cqTemplateName').value.trim();if(!name){alert('Choisissez le nom du devis.');return}
      var all=templates(),id=qs('#cqTemplateId').value||uid('tpl'),idx=all.findIndex(function(x){return x.id===id});
      var old=idx>=0?all[idx]:null;
      var item={id:id,name:name,logo:logoData||(old&&old.logo)||'',destination:qs('#cqTemplateDestination').value,updatedAt:new Date().toISOString()};
      if(idx>=0)all[idx]=item;else all.unshift(item);
      save(TEMPLATES_KEY,all.slice(0,20));renderTemplateList();reset();
    };
    window.__cqEditTemplate=function(id){
      var x=templates().find(function(t){return t.id===id});if(!x)return;
      qs('#cqTemplateId').value=x.id;qs('#cqTemplateName').value=x.name||'';qs('#cqTemplateDestination').value=x.destination||'address';logoData=x.logo||'';showLogo(logoData);
    };
    window.__cqDeleteTemplate=function(id){
      if(!confirm('Effacer ce modèle de devis ?'))return;
      save(TEMPLATES_KEY,templates().filter(function(t){return t.id!==id}));renderTemplateList();reset();
    };
  }

  function resizeLogo(data,done){
    var im=new Image();im.onload=function(){
      var maxW=700,maxH=280,sc=Math.min(1,maxW/im.width,maxH/im.height),c=document.createElement('canvas');
      c.width=Math.max(1,Math.round(im.width*sc));c.height=Math.max(1,Math.round(im.height*sc));
      c.getContext('2d').drawImage(im,0,0,c.width,c.height);
      done(c.toDataURL('image/jpeg',.82));
    };im.onerror=function(){done(data)};im.src=data;
  }
  function renderTemplateList(){
    var box=qs('#cqTemplateList');if(!box)return;var all=templates();
    box.innerHTML=all.length?all.map(function(x){return '<div class="cqTemplate"><div class="cqTemplateHead">'+(x.logo?'<img class="cqTemplateLogo" src="'+x.logo+'">':'')+'<div style="flex:1"><b>'+esc(x.name)+'</b><div style="font-size:12px;color:#bfc9d5;margin-top:3px">Emplacement : '+(x.destination==='house'?'Mesurer ma maison':"Carnet d'adresses")+'</div></div></div><div class="cqActions"><button class="cqBtn cqSoft" onclick="__cqEditTemplate(\''+x.id+'\')">✏️ MODIFIER</button><button class="cqBtn cqDanger" onclick="__cqDeleteTemplate(\''+x.id+'\')">🗑️ EFFACER</button></div></div>'}).join(''):'<div style="text-align:center;color:#c7d1dc;padding:10px">Aucun modèle. Créez le premier ci-dessous.</div>';
  }
  function openManager(){ensureStyles();ensureManager();renderTemplateList();qs('#cqOverlay').classList.add('open')}

  function ensureEditor(){
    if(qs('#cqEditor'))return;
    var o=document.createElement('div');o.id='cqEditor';
    o.innerHTML=`<div class="cqPanel">
      <h2 id="cqEditorTitle">🧾 DEVIS</h2>
      <div id="cqClientInfo" style="padding:10px;border-radius:12px;background:#0b1420;margin-bottom:10px"></div>
      <div class="cqField"><label>MODÈLE / NOM DU DEVIS</label><select id="cqEditorTemplate"></select></div>
      <div class="cqField"><label>OBJET</label><input id="cqObject" placeholder="Ex. Nettoyage toiture"></div>
      <div class="cqGrid">
        <div class="cqField"><label>QUANTITÉ</label><input id="cqQty" type="number" min="0" step="0.01" value="1"></div>
        <div class="cqField"><label>PRIX UNITAIRE TTC</label><input id="cqUnit" type="number" min="0" step="0.01" value="0"></div>
      </div>
      <div class="cqField"><label>DÉPLACEMENT</label><select id="cqTravel"><option value="0">Gratuit</option><option>10</option><option>20</option><option>30</option><option>40</option><option>50</option><option>60</option><option>70</option><option>80</option><option>90</option><option>100</option></select></div>
      <div class="cqField"><label>OÙ ENREGISTRER CE DEVIS ?</label><select id="cqDestination"><option value="address">Carnet d'adresses</option><option value="house">Mesurer ma maison</option></select></div>
      <div class="cqTotal">TOTAL TTC : <span id="cqTotal">0,00 €</span></div>
      <div class="cqField"><label>SIGNATURE DU CLIENT</label><canvas id="cqSignature" width="560" height="150"></canvas><button type="button" class="cqBtn cqSoft" id="cqClearSign" style="margin-top:6px">EFFACER LA SIGNATURE</button></div>
      <div class="cqActions"><button class="cqBtn cqPrimary" id="cqSaveQuote">💾 ENREGISTRER LE DEVIS</button><button class="cqBtn cqSoft" id="cqPrintQuote">🖨️ IMPRIMER A4</button><button class="cqBtn cqDanger" id="cqCloseEditor">FERMER</button></div>
    </div>`;
    document.body.appendChild(o);
    ['cqQty','cqUnit','cqTravel'].forEach(function(id){qs('#'+id).oninput=calc});
    qs('#cqCloseEditor').onclick=function(){o.classList.remove('open')};qs('#cqPrintQuote').onclick=function(){window.print()};
    qs('#cqEditorTemplate').onchange=function(){var x=templates().find(function(t){return t.id===this.value}.bind(this));if(x){qs('#cqEditorTitle').textContent='🧾 '+x.name;qs('#cqDestination').value=x.destination||'address'}};
    setupSignature();
    qs('#cqSaveQuote').onclick=saveCurrentQuote;
  }
  var editorAddressId='',editingQuoteId='';
  function calc(){var t=Number(qs('#cqQty').value||0)*Number(qs('#cqUnit').value||0)+Number(qs('#cqTravel').value||0);qs('#cqTotal').textContent=money(t);return t}
  function setupSignature(){
    var c=qs('#cqSignature'),ctx=c.getContext('2d'),down=false;
    ctx.lineWidth=2;ctx.lineCap='round';
    function pos(e){var r=c.getBoundingClientRect(),p=e.touches?e.touches[0]:e;return {x:(p.clientX-r.left)*c.width/r.width,y:(p.clientY-r.top)*c.height/r.height}}
    function start(e){down=true;var p=pos(e);ctx.beginPath();ctx.moveTo(p.x,p.y);e.preventDefault()}
    function move(e){if(!down)return;var p=pos(e);ctx.lineTo(p.x,p.y);ctx.stroke();e.preventDefault()}
    function end(){down=false}
    c.addEventListener('mousedown',start);c.addEventListener('mousemove',move);addEventListener('mouseup',end);
    c.addEventListener('touchstart',start,{passive:false});c.addEventListener('touchmove',move,{passive:false});c.addEventListener('touchend',end);
    qs('#cqClearSign').onclick=function(){ctx.clearRect(0,0,c.width,c.height)};
  }
  function openQuoteEditor(addressId,quoteId,forceDest){
    ensureStyles();ensureEditor();editorAddressId=addressId||'';editingQuoteId=quoteId||'';
    var ts=templates();
    if(!ts.length){openManager();alert("Créez d'abord votre modèle de devis dans « CRÉER SES DEVIS ».");return}
    qs('#cqEditorTemplate').innerHTML=ts.map(function(t){return '<option value="'+t.id+'">'+esc(t.name)+'</option>'}).join('');
    var addr=addressId?getAddressById(addressId):null;
    qs('#cqClientInfo').innerHTML=addr?'<b>'+esc(clientName(addr.item)||'Client')+'</b><br>'+esc(addr.item.address||addr.item.fullDictation||'')+(addr.item.phone?'<br>📞 '+esc(addr.item.phone):''):'Devis sans adresse client sélectionnée.';
    var q=null;
    if(quoteId){
      if(addr&&Array.isArray(addr.item.customQuotes))q=addr.item.customQuotes.find(function(x){return x.id===quoteId});
      if(!q)q=(load(HOUSE_QUOTES_KEY,[])||[]).find(function(x){return x.id===quoteId});
    }
    var tpl=q?ts.find(function(t){return t.id===q.templateId}):ts[0];tpl=tpl||ts[0];
    qs('#cqEditorTemplate').value=tpl.id;qs('#cqEditorTitle').textContent='🧾 '+tpl.name;
    qs('#cqObject').value=q&&q.object||'';qs('#cqQty').value=q&&q.qty!=null?q.qty:1;qs('#cqUnit').value=q&&q.unit!=null?q.unit:0;qs('#cqTravel').value=String(q&&q.travel!=null?q.travel:0);
    qs('#cqDestination').value=forceDest||(q&&q.destination)||tpl.destination||'address';
    qs('#cqClearSign').click();
    if(q&&q.signature){var im=new Image();im.onload=function(){qs('#cqSignature').getContext('2d').drawImage(im,0,0,qs('#cqSignature').width,qs('#cqSignature').height)};im.src=q.signature}
    calc();qs('#cqEditor').classList.add('open');
  }
  function saveCurrentQuote(){
    var ts=templates(),tpl=ts.find(function(t){return t.id===qs('#cqEditorTemplate').value});if(!tpl)return;
    var total=calc(),dest=qs('#cqDestination').value;
    var q={id:editingQuoteId||uid('dev'),number:'DEV-'+new Date().getFullYear()+'-'+String(Date.now()).slice(-6),templateId:tpl.id,name:tpl.name,logo:tpl.logo||'',object:qs('#cqObject').value.trim(),qty:Number(qs('#cqQty').value||0),unit:Number(qs('#cqUnit').value||0),travel:Number(qs('#cqTravel').value||0),total:total,destination:dest,signature:qs('#cqSignature').toDataURL('image/png'),createdAt:new Date().toISOString(),addressId:editorAddressId||''};
    var addr=editorAddressId?getAddressById(editorAddressId):null;
    if(dest==='address'){
      if(!addr){alert("Choisissez une adresse client pour enregistrer ce devis dans le carnet d'adresses.");return}
      var list=Array.isArray(addr.item.customQuotes)?addr.item.customQuotes:[];
      var i=list.findIndex(function(x){return x.id===q.id});if(i>=0)list[i]=q;else list.unshift(q);addr.item.customQuotes=list;save(addr.key,addr.arr);
    }else{
      var hs=load(HOUSE_QUOTES_KEY,[]);if(!Array.isArray(hs))hs=[];
      var hi=hs.findIndex(function(x){return x.id===q.id});if(hi>=0)hs[hi]=q;else hs.unshift(q);save(HOUSE_QUOTES_KEY,hs.slice(0,100));
    }
    var d=docs(),di=d.findIndex(function(x){return x&&x.id===q.id});if(di>=0)d[di]=q;else d.unshift(q);save(DOCS_KEY,d.slice(0,200));
    qs('#cqEditor').classList.remove('open');enhanceAddressCards();renderHouseQuotes();alert('Devis enregistré.');
  }

  window.__cqOpenAddressQuote=function(id){openQuoteEditor(id,'','address')};
  window.__cqEditQuote=function(addrId,qid){openQuoteEditor(addrId,qid)};
  window.__cqDeleteQuote=function(addrId,qid){
    if(!confirm('Effacer ce devis ?'))return;var a=getAddressById(addrId);if(!a)return;
    a.item.customQuotes=(a.item.customQuotes||[]).filter(function(x){return x.id!==qid});save(a.key,a.arr);
    save(DOCS_KEY,docs().filter(function(x){return x.id!==qid}));enhanceAddressCards();
  };

  function enhanceAddressCards(){
    qsa('.savedFolder').forEach(function(card){
      var go=qs('[data-go]',card);if(!go)return;var id=go.getAttribute('data-go'),a=getAddressById(id);if(!a)return;
      var phone=String(a.item.phone||'').trim(),ph=qs('.savedAddressPhone',card);
      if(ph)ph.style.display=phone?'none':'';
      var actions=qs('.savedAddressActions',card);if(!actions)return;
      if(!qs('.savedAddressQuote',actions)){
        var b=document.createElement('button');b.type='button';b.className='savedAddressQuote';b.textContent='🧾 DEVIS';b.onclick=function(){openQuoteEditor(id,'','address')};
        var del=qs('.savedAddressDelete',actions);if(del)actions.insertBefore(b,del);else actions.appendChild(b);
      }
      var old=qs('.cqQuoteList',card);if(old)old.remove();
      var list=Array.isArray(a.item.customQuotes)?a.item.customQuotes:[];
      if(list.length){
        var box=document.createElement('div');box.className='cqQuoteList';
        box.innerHTML='<b>🧾 DEVIS ENREGISTRÉS</b>'+list.map(function(q){return '<div class="cqQuoteRow"><b>'+esc(q.name||'Devis')+'</b><br><span style="font-size:13px">'+esc(q.number||'')+' • '+fmtDate(q.createdAt)+' • '+money(q.total)+'</span><div class="cqActions"><button class="cqBtn cqSoft" onclick="__cqEditQuote(\''+id+'\',\''+q.id+'\')">✏️ VOIR / MODIFIER</button><button class="cqBtn cqDanger" onclick="__cqDeleteQuote(\''+id+'\',\''+q.id+'\')">🗑️</button></div></div>'}).join('');
        card.appendChild(box);
      }
    });
  }

  window.__cqEditHouseQuote=function(id){openQuoteEditor('',id,'house')};
  window.__cqDeleteHouseQuote=function(id){if(!confirm('Effacer ce devis ?'))return;save(HOUSE_QUOTES_KEY,(load(HOUSE_QUOTES_KEY,[])||[]).filter(function(x){return x.id!==id}));save(DOCS_KEY,docs().filter(function(x){return x.id!==id}));renderHouseQuotes()};
  function renderHouseQuotes(){
    qsa('.housePhotoPanel').forEach(function(panel){
      var old=qs('.cqHouseBox',panel);if(old)old.remove();
      var hs=load(HOUSE_QUOTES_KEY,[]);if(!Array.isArray(hs))hs=[];
      var box=document.createElement('div');box.className='cqHouseBox';
      box.innerHTML='<button type="button" class="cqBtn cqPrimary" style="width:100%" onclick="__cqOpenHouseQuote()">🧾 CRÉER UN DEVIS</button>'+
        (hs.length?'<div style="margin-top:10px"><b>Mes devis :</b>'+hs.slice(0,10).map(function(q){return '<div class="cqQuoteRow"><b>'+esc(q.name||'Devis')+'</b> — '+money(q.total)+'<div class="cqActions"><button class="cqBtn cqSoft" onclick="__cqEditHouseQuote(\''+q.id+'\')">✏️ MODIFIER</button><button class="cqBtn cqDanger" onclick="__cqDeleteHouseQuote(\''+q.id+'\')">🗑️</button></div></div>'}).join('')+'</div>':'');
      panel.appendChild(box);
    });
  }
  window.__cqOpenHouseQuote=function(){openQuoteEditor('','','house')};

  function boot(){
    ensureStyles();installSettingsButton();ensureManager();ensureEditor();enhanceAddressCards();renderHouseQuotes();
    var mo=new MutationObserver(function(){installSettingsButton();enhanceAddressCards();renderHouseQuotes()});
    mo.observe(document.documentElement,{childList:true,subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
