(function () {
  "use strict";
  if (!window.CARPLAY_MARKET_LAZY) {
    document.write('<script src="markets-44-complete.js?v=20260902-complet"><\/script>');
    document.write('<script src="markets-france-national.js?v=20260902-national"><\/script>');
    document.write('<script src="markets-missing-v97.js?v=20260902"><\/script>');
    document.write('<script src="markets-missing-v100.js?v=20260902"><\/script>');
    document.write('<script src="markets-missing-v101.js?v=20260902"><\/script>');
    document.write('<script src="markets-missing-v102.js?v=20260902"><\/script>');
    document.write('<script src="markets-missing-v103.js?v=20260902"><\/script>');
    document.write('<script src="markets-missing-v104.js?v=20260902"><\/script>');
    document.write('<script src="market-weekly-filter.js?v=20260902-france-belgique"><\/script>');
  }
  var selected = null,
    server = "https://carplay-metiers.appli-suzon.workers.dev",
    searchQuery = "";
  var days = [
    "lundi",
    "mardi",
    "mercredi",
    "jeudi",
    "vendredi",
    "samedi",
    "dimanche",
  ];
  var jsDay = new Date().getDay();
  var currentDay =
    ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"][
      jsDay
    ] || "lundi";
  var labels = {
    lundi: "LUN",
    mardi: "MAR",
    mercredi: "MER",
    jeudi: "JEU",
    vendredi: "VEN",
    samedi: "SAM",
    dimanche: "DIM",
  };
  function el(id) {
    return document.getElementById(id);
  }
  function esc(v) {
    return String(v == null ? "" : v)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }
  function cleanCardText(v) {
    return String(v == null ? "" : v)
      .replace(/\s+officiellement\b/gi, "")
      .replace(/\s*[,;:-]?\s*GPS\s+[àa]\s+confirmer\s+sur\s+place\b/gi, "")
      .replace(/\s{2,}/g, " ")
      .trim();
  }
  function verificationDot(r, s) {
    var note = String((r && r[6]) || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
    var complete = s && s.time && s.count && s.draw;
    var official = note.indexOf("verifie sur le site officiel") >= 0 || note.indexOf("verifie officiellement") >= 0;
    var ok = !!complete || official;
    return '<span class="marketVerificationDot ' + (ok ? "green" : "orange") + '" title="' + (ok ? "Fiche vérifiée" : "Fiche à vérifier") + '" aria-label="' + (ok ? "Fiche vérifiée" : "Fiche à vérifier") + '"></span>';
  }
  function favoriteKey(r) {
    return "marketFavoriteDeviceOnlyV1:" + country + ":" + identity(r);
  }
  function isFavorite(r) {
    try {
      return localStorage.getItem(favoriteKey(r)) === "1";
    } catch (e) {
      return false;
    }
  }
  function toggleFavorite(index, btn) {
    var r = marketRows()[index],
      k,
      on;
    if (!r) return;
    k = favoriteKey(r);
    try {
      on = localStorage.getItem(k) === "1";
      if (on) localStorage.removeItem(k);
      else localStorage.setItem(k, "1");
      on = !on;
    } catch (e) {
      on = isFavorite(r);
    }
    if (btn) {
      btn.classList.toggle("active", on);
      btn.textContent = on ? "★" : "☆";
      btn.setAttribute(
        "aria-label",
        on ? "Retirer des favoris" : "Ajouter aux favoris",
      );
      btn.setAttribute(
        "title",
        on ? "Retirer des favoris" : "Ajouter aux favoris",
      );
    }
    return false;
  }
  window.toggleMarketFavorite = toggleFavorite;
  (function migrateLocalFavorites() {
    try {
      var i, k, v, nk;
      for (i = localStorage.length - 1; i >= 0; i--) {
        k = localStorage.key(i);
        if (k && k.indexOf("marketFavoriteV1:") === 0) {
          v = localStorage.getItem(k);
          nk = k.replace("marketFavoriteV1:", "marketFavoriteDeviceOnlyV1:");
          if (v === "1" && localStorage.getItem(nk) !== "1")
            localStorage.setItem(nk, "1");
          localStorage.removeItem(k);
        }
      }
    } catch (e) {}
  })();
  function areaLabel(a) {
    return country === "fr" ? a[0] + " — " + a[1] : a[1];
  }
  function areaKey() {
    return selected ? String(selected[0]) : "";
  }
  var marketChunkCache = {}, marketChunkToken = 0, nearbyIndexCacheV514 = null;
  function marketChunkUrl() {
    return "/market-chunks/" + encodeURIComponent(country) + "/" +
      encodeURIComponent(areaKey()) + "/" + encodeURIComponent(currentDay) + ".json?v=514-sync";
  }
  function marketMergeKeyV514(row) {
    return [
      String((row && row[0]) || "").toLowerCase(),
      normSearch((row && row[2]) || ""),
      normSearch((row && row[3]) || ""),
      String((row && row[4]) || "").toLowerCase(),
      normSearch((row && row[8]) || "")
    ].join("|");
  }
  function mergeMarketRowsV514(target, rows) {
    var out = target || [], seen = {}, i, row, key;
    for (i = 0; i < out.length; i++) seen[marketMergeKeyV514(out[i])] = 1;
    for (i = 0; i < (rows || []).length; i++) {
      row = rows[i];
      if (!row || String(row[0]) !== String(areaKey()) || String(row[4] || "").toLowerCase() !== currentDay) continue;
      key = marketMergeKeyV514(row);
      if (!seen[key]) { seen[key] = 1; out.push(row); }
    }
    return out;
  }
  function nearbyShardRowsV514() {
    function findAndLoad(index) {
      var areas = index && Array.isArray(index.areas) ? index.areas : [], hit = null, i;
      for (i = 0; i < areas.length; i++) {
        if (String(areas[i].country || "").toLowerCase() === String(country).toLowerCase() &&
            String(areas[i].area || "").toLowerCase() === String(areaKey()).toLowerCase()) {
          hit = areas[i]; break;
        }
      }
      if (!hit || !hit.file) return Promise.resolve([]);
      return fetch("/nearby-shards/" + encodeURIComponent(hit.file) + "?v=514-sync", { cache: "no-store" })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) { return j && Array.isArray(j.weekly) ? j.weekly : []; })
        .catch(function () { return []; });
    }
    if (nearbyIndexCacheV514) return findAndLoad(nearbyIndexCacheV514);
    return fetch("/nearby-shards/index.json?v=514-sync", { cache: "no-store" })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) { nearbyIndexCacheV514 = j || { areas: [] }; return findAndLoad(nearbyIndexCacheV514); })
      .catch(function () { return []; });
  }
  function serverMarketRowsV514() {
    var payload = { country: String(country || "fr").toUpperCase(), area: areaKey(), day: currentDay };
    return fetch("/api/markets/query?sync_v514=" + Date.now(), {
      method: "POST",
      headers: { "content-type": "application/json" },
      cache: "no-store",
      body: JSON.stringify(payload)
    }).then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) {
        var markets = j && Array.isArray(j.markets) ? j.markets : [], rows = [], i, m, kind;
        for (i = 0; i < markets.length; i++) {
          m = markets[i] || {};
          kind = String(m.kind || "marche").toLowerCase();
          if (kind !== "marche") continue;
          rows.push([
            m.area || areaKey(), m.kind || "marche", m.name || "Marché", m.city || "",
            m.day || m.date_label || currentDay, m.hours || "", m.note || m.kind || "",
            m.merchants || "", m.address || m.city || "", m.source_url ? [m.source_url] : [],
            m.latitude == null ? null : Number(m.latitude), m.longitude == null ? null : Number(m.longitude),
            m.draw || "", m.registration || "", "", m.phone || "", m.date_label || m.day || ""
          ]);
        }
        return rows;
      }).catch(function () { return []; });
  }
  function loadSelectedMarketChunk(done) {
    if (!window.CARPLAY_MARKET_LAZY) { done(); return; }
    var key = country + "|" + areaKey() + "|" + currentDay, token = ++marketChunkToken;
    if (marketChunkCache[key]) { window.data = marketChunkCache[key]; done(); return; }
    if (el("cards")) el("cards").innerHTML = '<article class="card empty">Chargement des marchés…</article>';
    Promise.all([
      fetch(marketChunkUrl(), { cache: "no-store" })
        .then(function (r) { return r.ok ? r.json() : []; }).catch(function () { return []; }),
      nearbyShardRowsV514(),
      serverMarketRowsV514()
    ]).then(function (packs) {
      if (token !== marketChunkToken) return;
      var rows = Array.isArray(packs[0]) ? packs[0].slice() : [];
      rows = mergeMarketRowsV514(rows, packs[1]);
      rows = mergeMarketRowsV514(rows, packs[2]);
      marketChunkCache[key] = rows;
      window.data = rows;
      done();
    }).catch(function () {
      if (token !== marketChunkToken) return;
      window.data = [];
      if (el("cards")) el("cards").innerHTML = '<article class="card empty">Impossible de charger les marchés. Vérifiez Internet puis réessayez.</article>';
    });
  }
  function renderSelectedMarkets() {
    loadSelectedMarketChunk(function () { renderMarkets(); });
  }
  function normSearch(v) {
    return String(v || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  }
  function marketRows() {
    var k = areaKey(),
      out = [],
      i,
      r,
      q = normSearch(searchQuery),
      aq = q,
      a = window.BE_CITY_ALIASES || {},
      x;
    if (country === "be" && q) {
      for (x in a) {
        if (normSearch(x) === q) {
          aq = normSearch(a[x]);
          break;
        }
      }
    }
    for (i = 0; i < data.length; i++) {
      r = data[i];
      if (
        String(r[0]) === k &&
        String(r[4]).toLowerCase() === currentDay &&
        (!q ||
          normSearch(
            (r[2] || "") + " " + (r[3] || "") + " " + (r[8] || ""),
          ).indexOf(q) >= 0 ||
          normSearch(
            (r[2] || "") + " " + (r[3] || "") + " " + (r[8] || ""),
          ).indexOf(aq) >= 0)
      )
        out.push(r);
    }
    window.MarketDedupV511.restoredRows(country,k,currentDay).forEach(function(row){if(!out.some(function(r){return identity(r)===identity(row)}))out.push(row)});
    return window.MarketDedupV511.rows(out,country);
  }
  function verificationKey(r) {
    return (
      "marketVerifyV9:" +
      country +
      ":" +
      [r[0], r[1], r[2], r[3], r[4], r[5], r[8] || ""].join("|")
    );
  }
  function saved(r) {
    try {
      var v = localStorage.getItem(verificationKey(r));
      return v ? JSON.parse(v) : null;
    } catch (e) {
      return null;
    }
  }
  function correctedNow() {
    var epoch = Number(localStorage.getItem("net_time_epoch") || 0),
      savedAt = Number(localStorage.getItem("net_time_saved_at") || 0);
    return epoch && savedAt
      ? new Date(epoch + (Date.now() - savedAt))
      : new Date();
  }
  function dayNumber(day) {
    return {
      dimanche: 0,
      lundi: 1,
      mardi: 2,
      mercredi: 3,
      jeudi: 4,
      vendredi: 5,
      samedi: 6,
    }[day];
  }
  function nextDate(day) {
    var d = correctedNow(),
      target = dayNumber(day),
      add = (target - d.getDay() + 7) % 7;
    d.setDate(d.getDate() + add);
    return (
      d.getFullYear() +
      "-" +
      String(d.getMonth() + 1).padStart(2, "0") +
      "-" +
      String(d.getDate()).padStart(2, "0")
    );
  }
  function countDate(day) {
    return nextDate(day) + "-compteurs-reels-v6-20260824-zero-general";
  }
  function deviceId() {
    var id = localStorage.getItem("shared_trade_device");
    if (!id) {
      id = "a" + Date.now().toString(36) + Math.random().toString(36).slice(2);
      localStorage.setItem("shared_trade_device", id);
    }
    return id;
  }
  function currentTrade() {
    return String(localStorage.getItem("market_trade") || "").trim();
  }
  var tradeChoices = [
    "Brocante",
    "Matelas",
    "Vêtements",
    "Alimentaire",
    "Outillage",
    "Bijoux",
    "Chaussures",
    "Couvreur",
    "Rempailleur / Restauration",
    "Bonbons des Vosges",
    "Horloger",
    "Meubles",
    "Tapis",
    "Espace vert",
  ];
  function knownTrade(v) {
    return tradeChoices.indexOf(v) >= 0;
  }
  function identity(r) {
    return [country, r[0], r[2], r[3], r[4], r[8] || ""].join("|");
  }
  function closeBubble() {
    var old = el("newMarketBubble");
    if (old && old.parentNode) old.parentNode.removeChild(old);
  }
  function bubble(html) {
    closeBubble();
    var box = document.createElement("div");
    box.id = "newMarketBubble";
    box.style.cssText =
      "position:fixed;z-index:300000;inset:0;background:rgba(0,0,0,.88);display:flex;align-items:center;justify-content:center;padding:22px";
    box.innerHTML = '<div class="bubbleBox">' + html + "</div>";
    document.body.appendChild(box);
  }
  function bindTap(node, action) {
    if (!node) return;
    function run(e) {
      var now = Date.now();
      if(window.__carplayVoiceSuppressUntil&&now<window.__carplayVoiceSuppressUntil){
        if(e){if(e.preventDefault)e.preventDefault();if(e.stopPropagation)e.stopPropagation()}
        return false;
      }
      if (now - (node.__lastDirectTap || 0) < 650) return false;
      node.__lastDirectTap = now;
      if (e) {
        if (e.preventDefault) e.preventDefault();
        if (e.stopPropagation) e.stopPropagation();
      }
      action();
      return false;
    }
    node.ontouchend = run;
    node.onclick = run;
  }
  function marketTap(node, action) {
    if (!node) return;
    var sx = 0,
      sy = 0,
      moved = false;
    node.ontouchstart = function (e) {
      var t = e.touches && e.touches[0];
      if (t) {
        sx = t.clientX;
        sy = t.clientY;
        moved = false;
      }
    };
    node.ontouchmove = function (e) {
      var t = e.touches && e.touches[0];
      if (t && (Math.abs(t.clientX - sx) > 14 || Math.abs(t.clientY - sy) > 14))
        moved = true;
    };
    function run(e) {
      var now = Date.now();
      if(window.__carplayVoiceSuppressUntil&&now<window.__carplayVoiceSuppressUntil){
        if(e){if(e.preventDefault)e.preventDefault();if(e.stopPropagation)e.stopPropagation()}
        return false;
      }
      if (moved || now - (node.__marketTapAt || 0) < 650) return false;
      node.__marketTapAt = now;
      if (e) {
        if (e.preventDefault) e.preventDefault();
        if (e.stopPropagation) e.stopPropagation();
      }
      action();
      return false;
    }
    node.ontouchend = run;
    node.onclick = run;
  }
  function gps(r) {
    var point=verifiedMarketPoint(r), lat=point?point.lat:NaN,lon=point?point.lon:NaN,
      hasCoords=!!point,destination,q,pref=localStorage.getItem("gps_pref")||"Google Maps";
    if (hasCoords) {
      destination = lat + "," + lon;
    } else {
      destination = [r[3] || "", r[2] || "", r[8] || ""]
        .filter(Boolean)
        .join(", ");
    }
    q = encodeURIComponent(destination);
    window.location.href =
      pref === "Waze"
        ? "https://www.waze.com/ul?ll=" +
          (hasCoords ? encodeURIComponent(lat + "," + lon) : "") +
          "&q=" +
          q +
          "&navigate=yes"
        : pref === "Plans Apple"
          ? "https://maps.apple.com/?daddr=" + q + "&dirflg=d"
          : "https://www.google.com/maps/dir/?api=1&destination=" +
          q +
          "&travelmode=driving&dir_action=navigate";
  }
  function askTrade() {
    bubble(
      '<h2>VOTRE MÉTIER</h2><p>Choisissez obligatoirement un métier dans la liste pour ne pas fausser les compteurs.</p><select id="newTradeSelect" style="width:94%;height:68px;border:3px solid #62d8ff;border-radius:15px;background:#081727;color:#fff;font-size:24px;padding:10px"><option value="">CHOISIR SON MÉTIER</option><option>Brocante</option><option>Matelas</option><option>Vêtements</option><option>Alimentaire</option><option>Outillage</option><option>Bijoux</option><option>Chaussures</option><option>Couvreur</option><option>Rempailleur / Restauration</option><option>Bonbons des Vosges</option><option>Horloger</option><option>Meubles</option><option>Tapis</option><option>Espace vert</option></select><div class="bubbleBtns"><button id="newCancel" class="red">ANNULER</button><button id="newTradeSave" class="blue">ENREGISTRER</button></div>',
    );
    bindTap(el("newCancel"), closeBubble);
    bindTap(el("newTradeSave"), function () {
      var s = el("newTradeSelect"),
        v = s.value;
      if (!knownTrade(v)) {
        s.focus();
        return;
      }
      localStorage.setItem("market_trade", v);
      el("tradeInput").value = v;
      el("tradeStatus").textContent = "Métier enregistré : " + v;
      closeBubble();
      renderMarkets();
    });
  }
  function unavailable(r) {
    bubble(
      '<h2>SERVEUR INDISPONIBLE</h2><p>La concurrence ne peut pas être vérifiée. Vous pouvez quand même ouvrir le GPS.</p><div class="bubbleBtns"><button id="newOther" class="red">AUTRE MARCHÉ</button><button id="newGps" class="blue">CONTINUER AVEC LE GPS</button></div>',
    );
    bindTap(el("newOther"), closeBubble);
    bindTap(el("newGps"), function () {
      closeBubble();
      gps(r);
    });
  }
  function showCount(count, trade, r, date) {
    var text =
      count === 0
        ? "Aucun marchand de <b>" +
          esc(trade) +
          "</b> n’est en route pour ce marché."
        : '<b class="bigCount">' +
          count +
          "</b> marchand" +
          (count > 1 ? "s" : "") +
          " de <b>" +
          esc(trade) +
          "</b> " +
          (count > 1 ? "sont" : "est") +
          " en route pour ce marché.";
    bubble(
      "<h2>CONCURRENCE SUR CE MARCHÉ</h2><p>" +
        text +
        '</p><div class="bubbleBtns"><button id="newOther" class="red">CHERCHER UN AUTRE MARCHÉ</button><button id="newGps" class="blue">CONTINUER AVEC LE GPS</button></div><small>Le nombre concerne uniquement les utilisateurs de l’application.</small>',
    );
    bindTap(el("newOther"), closeBubble);
    bindTap(el("newGps"), function () {
      closeBubble();
      try {
        fetch(server + "/api/choose", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            device: deviceId(),
            market: identity(r),
            date: date,
            trade: trade,
          }),
        }).catch(function () {});
      } catch (e) {}
      gps(r);
    });
  }
  function goDirect(index) {
    if(window.__carplayVoiceSuppressUntil&&Date.now()<window.__carplayVoiceSuppressUntil)return false;
    var r = marketRows()[index],
      trade = currentTrade(),
      date;
    if (!r) return;
    if (!trade) {
      askTrade();
      return;
    }
    date = countDate(currentDay);
    function goNow() {
      try {
        fetch(server + "/api/choose", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            device: deviceId(),
            market: identity(r),
            date: date,
            trade: trade,
          }),
          keepalive: true,
        }).catch(function () {});
      } catch (e) {}
      closeBubble();
      gps(r);
    }
    function ask(count) {
      if(window.__carplayVoiceSuppressUntil&&Date.now()<window.__carplayVoiceSuppressUntil)return;
      var city = String(r[3] || r[2] || "ce marché"),
        warning = Number(count) > 0
          ? '<p style="color:#ffd36d;font-weight:950">⚠️ Il y a déjà <b>' + Number(count) + '</b> marchand' + (Number(count)>1?'s':'') + ' de <b>' + esc(trade) + '</b> inscrit' + (Number(count)>1?'s':'') + ' pour ce marché.</p>'
          : '';
      bubble(
        '<h2>CONFIRMATION</h2><p>Êtes-vous sûr de vouloir aller au marché de <b>' + esc(city) + '</b> ?</p>' + warning +
        '<div class="bubbleBtns"><button id="newOther" class="red">NON</button><button id="newGps" class="blue">OUI</button></div>'
      );
      bindTap(el("newOther"), closeBubble);
      bindTap(el("newGps"), goNow);
    }
    var finished = false,
      timer = setTimeout(function(){ if(!finished){finished=true;ask(null)} },1800),
      url = server + "/api/count?market=" + encodeURIComponent(identity(r)) + "&date=" + encodeURIComponent(date) + "&trade=" + encodeURIComponent(trade.toLowerCase());
    try {
      fetch(url,{cache:"no-store"}).then(function(res){if(!res.ok)throw 0;return res.json()}).then(function(j){if(finished)return;finished=true;clearTimeout(timer);ask(Number(j.count||0))}).catch(function(){if(finished)return;finished=true;clearTimeout(timer);ask(null)});
    } catch(e) { if(!finished){finished=true;clearTimeout(timer);ask(null)} }
  }
  window.goMarket = goDirect;
  function countNote() {
    return '<div style="margin-top:7px;padding-top:7px;border-top:1px solid #f39b19;color:#ddd;font-size:13px;line-height:1.25">Indicatif : seuls les utilisateurs de l’appli sont comptés. D’autres marchands peuvent être présents.</div>';
  }
  function loadCounts(rs) {
    var trade = currentTrade(),
      i;
    if (!trade) {
      for (i = 0; i < rs.length; i++)
        el("competition_" + i).innerHTML =
          "⚠️ Enregistrez votre métier pour voir la concurrence" + countNote();
      return;
    }
    for (i = 0; i < rs.length; i++) loadOneCount(rs[i], i, trade);
  }
  function loadOneCount(r, index, trade) {
    var box = el("competition_" + index),
      date = countDate(currentDay),
      url =
        server +
        "/api/count?market=" +
        encodeURIComponent(identity(r)) +
        "&date=" +
        encodeURIComponent(date) +
        "&trade=" +
        encodeURIComponent(trade.toLowerCase()),
      finished = false,
      timer = setTimeout(function () {
        if (!finished) {
          finished = true;
          box.innerHTML = "⚠️ Concurrence indisponible" + countNote();
        }
      }, 4500);
    fetch(url, { cache: "no-store" })
      .then(function (res) {
        if (!res.ok) throw 0;
        return res.json();
      })
      .then(function (json) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var n = Number(json.count || 0),
          line =
            n === 0
              ? 'Aucun marchand de <b style="color:#ffd36d">' +
                esc(trade) +
                "</b> n’est en route pour ce marché"
              : '<b style="color:#ffd36d;font-size:27px">' +
                n +
                "</b> marchand" +
                (n > 1 ? "s" : "") +
                ' de <b style="color:#ffd36d">' +
                esc(trade) +
                "</b> " +
                (n > 1 ? "sont" : "est") +
                " en route pour ce marché";
        box.innerHTML = line + countNote();
      })
      .catch(function () {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        box.innerHTML = "⚠️ Concurrence indisponible" + countNote();
      });
  }
  function renderDays() {
    var html = "",
      i;
    for (i = 0; i < days.length; i++)
      html +=
        '<button type="button" class="day ' +
        (days[i] === currentDay ? "active" : "") +
        '" data-day="' +
        days[i] +
        '">' +
        labels[days[i]] +
        "</button>";
    el("days").innerHTML = html;
    var buttons = el("days").getElementsByTagName("button");
    for (i = 0; i < buttons.length; i++)
      buttons[i].onclick = function () {
        currentDay = this.getAttribute("data-day");
        renderDays();
        renderSelectedMarkets();
      };
    setTimeout(function () {
      var active = el("days").querySelector(".day.active");
      if (active && active.scrollIntoView)
        active.scrollIntoView({
          behavior: "smooth",
          block: "nearest",
          inline: "center",
        });
    }, 20);
  }
  function listText(v) {
    return v && v.length ? v.join(", ") : "À vérifier";
  }
  function builtInDraw(r) {
    var city = String((r && r[3]) || "").toLowerCase();
    if (city.indexOf("nantes") >= 0) return "Oui";
    if (city.indexOf("rennes") >= 0) return "Oui";
    return "À vérifier";
  }
  var liveMarketPosition = null;
  function verifiedMarketPoint(r) {
    try {
      var saved = JSON.parse(localStorage.getItem("marketLocalLocationV1:" + identity(r)) || "null");
      var lat = Number(saved && saved.latitude), lon = Number(saved && saved.longitude);
      if (saved && isFinite(lat) && isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && !(lat === 0 && lon === 0)) return {lat:lat,lon:lon};
    } catch (e) {}
    var lat = Number(r && r[10]), lon = Number(r && r[11]);
    return r && r[10] != null && r[11] != null && String(r[10]).trim() !== "" && String(r[11]).trim() !== "" && isFinite(lat) && isFinite(lon) && !(lat === 0 && lon === 0) ? {lat:lat,lon:lon} : null;
  }
  function distanceReference() {
    if (liveMarketPosition && Date.now()-liveMarketPosition.updatedAt < 120000) return liveMarketPosition;
    try {
      var recent=JSON.parse(localStorage.getItem("marketDistanceReferenceV1")||"null");
      if (recent && Date.now()-Number(recent.updatedAt) < 300000 && Number(recent.accuracy) <= 150 && isFinite(Number(recent.latitude)) && isFinite(Number(recent.longitude))) return {lat:Number(recent.latitude),lon:Number(recent.longitude),source:"current"};
    } catch (e) {}
    var lat=parseFloat(localStorage.getItem("return_lat")),lon=parseFloat(localStorage.getItem("return_lon"));
    return isFinite(lat)&&isFinite(lon)?{lat:lat,lon:lon,source:"saved"}:null;
  }
  function marketDistanceText(r) {
    var ref=distanceReference(),point=verifiedMarketPoint(r);
    if (!ref || !point) return "";
    var p=Math.PI/180,da=(point.lat-ref.lat)*p,db=(point.lon-ref.lon)*p,
      x=Math.sin(da/2)**2+Math.cos(ref.lat*p)*Math.cos(point.lat*p)*Math.sin(db/2)**2,
      km=2*6371*Math.asin(Math.sqrt(x));
    if (km<0.1) return "à moins de 100 m";
    if (km<1) return Math.round(km*1000)+" m";
    return (km<10?km.toFixed(1):Math.round(km))+" km";
  }
  function refreshVisibleMarketDistances() {
    var cards=el("cards")&&el("cards").querySelectorAll("article.card"),rows=marketRows();
    if (!cards) return;
    for (var i=0;i<rows.length && i<cards.length;i++) {
      var value=marketDistanceText(rows[i]),line=cards[i].querySelector('[data-feature="market-distance"]');
      if (!line && value) {line=document.createElement("div");line.className="meta";line.dataset.feature="market-distance";line.style.cssText="color:#6fe0ff;font-size:18px;font-weight:950";var metas=cards[i].querySelectorAll(".meta");if(metas[1])cards[i].insertBefore(line,metas[1]);else cards[i].appendChild(line)}
      if (line) {line.textContent=value;line.style.display=value?"":"none";line.title=distanceReference()&&distanceReference().source==="saved"?"Depuis votre place enregistrée":"Depuis votre position actuelle"}
      cards[i].dataset.voiceDistance=value;
    }
  }
  function refreshCurrentMarketPosition() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(function(pos){
      if (Number(pos.coords.accuracy)>150) return;
      liveMarketPosition={lat:pos.coords.latitude,lon:pos.coords.longitude,updatedAt:Date.now(),source:"current"};
      refreshVisibleMarketDistances();
    },function(){},{enableHighAccuracy:true,maximumAge:15000,timeout:8000});
  }
  window.addEventListener("carplay-market-gps-updated",refreshVisibleMarketDistances);
  function voiceDayLabel(day){
    var names=['dimanche','lundi','mardi','mercredi','jeudi','vendredi','samedi'],today=names[new Date().getDay()];
    return normSearch(day)===normSearch(today)?"Aujourd’hui":String(day||'');
  }
  function renderMarkets() {
    var rs = marketRows(),
      html = "",
      i,
      r,
      s,
      name,
      place,
      time,
      count,
      url,
      fav;
    el("heading").textContent =
      areaLabel(selected) +
      " — " +
      currentDay.toUpperCase() +
      (searchQuery ? " — RECHERCHE : " + searchQuery.toUpperCase() : "");
    for (i = 0; i < rs.length; i++) {
      r = rs[i];
      s = saved(r) || {};
      name = cleanCardText(r[2] || "Marché");
      place = cleanCardText(r[3] || "À préciser");
      time = cleanCardText(s.time || r[5] || "Horaire à vérifier");
      count = cleanCardText(s.count || r[7] || "À vérifier");
      fav = isFavorite(r);
      url =
        "verification-v9.html?k=" +
        encodeURIComponent(verificationKey(r)) +
        "&n=" +
        encodeURIComponent(name) +
        "&t=" +
        encodeURIComponent(r[5] || "") +
        "&c=" +
        encodeURIComponent(r[7] || "") +
        "&mk=" +
        encodeURIComponent(identity(r)) +
        "&country=" +
        encodeURIComponent(country) +
        "&lat=" +
        encodeURIComponent(r[10] == null ? "" : r[10]) +
        "&lon=" +
        encodeURIComponent(r[11] == null ? "" : r[11]) +
        "&back=" +
        encodeURIComponent(
          (country === "be"
            ? "belgique-marches-final.html"
            : "marches-final.html") +
            "?area=" +
            encodeURIComponent(areaKey()) +
            "&day=" +
            encodeURIComponent(currentDay),
        );
      html +=
        '<article class="card" data-voice-card="market" data-voice-department="'+esc(r[0]||'')+'" data-voice-city="'+esc(place)+'" data-voice-name="'+esc(name)+'" data-voice-day="'+esc(voiceDayLabel(currentDay))+'" data-voice-distance="'+esc(marketDistanceText(r)||'')+'" data-voice-count="'+esc(count)+'" data-voice-count-label="commerçants">' + verificationDot(r, s) + '<button type="button" class="marketFavoriteStar ' +
        (fav ? "active" : "") +
        '" aria-label="' +
        (fav ? "Retirer des favoris" : "Ajouter aux favoris") +
        '" title="' +
        (fav ? "Retirer des favoris" : "Ajouter aux favoris") +
        '" onclick="return window.toggleMarketFavorite(' +
        i +
        ',this)">' +
        (fav ? "★" : "☆") +
        '</button><div class="name">' +
        esc(place) +
        "</div>" +
        '<div class="meta" style="font-weight:900;font-size:20px;margin-bottom:8px">' +
        esc(name) +
        "</div>" +
        (marketDistanceText(r)
          ? '<div class="meta" data-feature="market-distance" style="color:#6fe0ff;font-size:18px;font-weight:950">' +
            esc(marketDistanceText(r)) +
            "</div>"
          : "") +
        '<div class="meta">🕒 ' +
        esc(time) +
        '</div><div class="meta">👥 Commerçants : ' +
        esc(count) +
        '</div><div class="meta">Tirage au sort : ' +
        esc(cleanCardText(s.draw || r[12] || builtInDraw(r))) +
        '</div><div class="meta">Humeur du placier : ' +
        esc(cleanCardText(s.welcome || "À vérifier")) +
        '</div><div class="meta">Responsable : ' +
        esc(cleanCardText(listText(s.placer))) +
        '</div><div class="meta">Modèle de clients : ' +
        esc(cleanCardText(s.clientModel || "À vérifier")) +
        '</div><div id="competition_' +
        i +
        '" style="margin-top:10px;padding:12px;border:3px solid #f39b19;border-radius:14px;background:#05090f;color:#fff;font-size:18px;font-weight:950">Concurrence : chargement…</div><div class="actions"><button type="button" class="go" data-market="' +
        i +
        '" onclick="window.goMarket(' +
        i +
        ');return false">ALLER AU MARCHÉ</button><a class="verify" href="' +
        url +
        '">' +
        (saved(r) ? "VOIR LA FICHE" : "VÉRIFIER") +
        "</a></div></article>";
    }
    el("cards").innerHTML =
      html ||
      '<article class="card empty">Aucun marché enregistré pour ce jour.</article>';
    loadCounts(rs);
    refreshVisibleMarketDistances();
    refreshCurrentMarketPosition();
  }
  function loadWeather(rs) {
    var date = nextDate(currentDay),
      i;
    for (i = 0; i < rs.length; i++) loadOneWeather(rs[i], i, date);
  }
  function loadOneWeather(r, index, date) {
    var box = el("weather_" + index),
      place = r[3] || r[2] || "";
    if (!box) return;
    fetch(
      "https://geocoding-api.open-meteo.com/v1/search?name=" +
        encodeURIComponent(place) +
        "&count=1&language=fr&format=json",
    )
      .then(function (x) {
        if (!x.ok) throw 0;
        return x.json();
      })
      .then(function (g) {
        if (!g.results || !g.results[0]) throw 0;
        var p = g.results[0];
        return fetch(
          "https://api.open-meteo.com/v1/forecast?latitude=" +
            p.latitude +
            "&longitude=" +
            p.longitude +
            "&hourly=precipitation_probability&timezone=auto&forecast_days=8",
        );
      })
      .then(function (x) {
        if (!x.ok) throw 0;
        return x.json();
      })
      .then(function (j) {
        var max = 0,
          h,
          k;
        for (h = 7; h <= 13; h++) {
          k = (j.hourly.time || []).indexOf(
            date + "T" + String(h).padStart(2, "0") + ":00",
          );
          if (k >= 0)
            max = Math.max(
              max,
              Number(j.hourly.precipitation_probability[k] || 0),
            );
        }
        box.innerHTML = "🌤️ Météo 07h00–13h30 <b>💧 " + max + " %</b>";
      })
      .catch(function () {
        box.textContent = "🌤️ Météo 07h00–13h30 : indisponible";
      });
  }
  function pickerTop(on) {
    document.body.classList.toggle("departmentPicker", !!on);
  }
  function showMarkets() {
    pickerTop(false);
    el("picker").style.display = "none";
    el("results").style.display = "block";
    renderDays();
    renderSelectedMarkets();
    window.scrollTo(0, 0);
  }
  var lastResumeRefresh = 0;
  function refreshCountsOnReturn() {
    var now = Date.now(),
      results = el("results");
    if (
      !selected ||
      !results ||
      results.style.display !== "block" ||
      now - lastResumeRefresh < 500
    )
      return;
    lastResumeRefresh = now;
    loadCounts(marketRows());
    setTimeout(function () {
      if (selected && el("results") && el("results").style.display === "block")
        loadCounts(marketRows());
    }, 1500);
  }
  function init() {
    var picker = el("picker"),
      listHtml = "",
      i,
      code,
      boxLabel,
      params,
      restoreArea,
      restoreDay;
    pickerTop(true);
    if (country === "be") document.body.classList.add("belgiumPicker");
    boxLabel = country === "fr" ? "DÉPARTEMENT" : "PROVINCE";
    picker.innerHTML =
      '<a class="departmentBack" href="choix-marches-final.html">← RETOUR</a><div class="departmentInstruction">CHOISIR ' +
      (country === "fr" ? "UN DÉPARTEMENT" : "UNE PROVINCE") +
      '</div><div id="areaDirectList" class="areaDirectList"></div>';
    if (country === "fr") {
      listHtml =
        '<select id="frDepartmentSelect" class="frDepartmentSelect" aria-label="Choisir un département"><option value="">CHOISIR UN DÉPARTEMENT</option>';
      for (i = 0; i < areas.length; i++) {
        code = String(areas[i][0]);
        listHtml +=
          '<option value="' +
          i +
          '">' +
          esc(code + " — " + areas[i][1]) +
          "</option>";
      }
      listHtml +=
        '</select><button type="button" id="frDepartmentOpen" class="frDepartmentOpen">OUVRIR</button>';
      el("areaDirectList").innerHTML = listHtml;
      marketTap(el("frDepartmentOpen"), function () {
        var v = el("frDepartmentSelect").value;
        if (v === "") return;
        selected = areas[Number(v)];
        showMarkets();
      });
    } else {
      for (i = 0; i < areas.length; i++) {
        listHtml +=
          '<button type="button" class="areaChoice" data-area="' +
          i +
          '"><span class="areaBoxLabel">' +
          boxLabel +
          '</span><span class="areaBoxCode">' +
          esc(areas[i][1]) +
          "</span></button>";
      }
      el("areaDirectList").innerHTML = listHtml;
      var choices = el("areaDirectList").getElementsByTagName("button");
      for (i = 0; i < choices.length; i++)
        marketTap(
          choices[i],
          function () {
            selected = areas[Number(this.getAttribute("data-area"))];
            showMarkets();
          }.bind(choices[i]),
        );
    }
    marketTap(el("changeArea"), function () {
      // Retour direct à la page principale de recherche France / Belgique.
      // On ne réaffiche plus l’écran intermédiaire département / province.
      location.href = "choix-marches-final.html";
    });
    el("tradeSave").onclick = function () {
      var v = el("tradeInput").value;
      if (!knownTrade(v)) {
        el("tradeInput").focus();
        return;
      }
      localStorage.setItem("market_trade", v);
      el("tradeStatus").textContent = "Métier enregistré : " + v;
      el("tradeSave").textContent = "MODIFIER LE MÉTIER";
      if (el("results").style.display === "block") renderMarkets();
    };
    var trade = currentTrade();
    if (!knownTrade(trade)) {
      trade = "";
      localStorage.removeItem("market_trade");
    }
    el("tradeInput").value = trade;
    el("tradeStatus").textContent = trade
      ? "Métier enregistré : " + trade
      : "Aucun métier enregistré.";
    el("tradeSave").textContent = trade
      ? "MODIFIER LE MÉTIER"
      : "ENREGISTRER LE MÉTIER";
    try {
      params = new URLSearchParams(location.search);
      restoreArea = params.get("area");
      restoreDay = params.get("day");
      searchQuery = params.get("q") || "";
    } catch (e) {
      restoreArea = "";
      restoreDay = "";
    }
    if (restoreDay && days.indexOf(String(restoreDay).toLowerCase()) >= 0)
      currentDay = String(restoreDay).toLowerCase();
    if (restoreArea) {
      for (i = 0; i < areas.length; i++) {
        if (String(areas[i][0]) === String(restoreArea)) {
          selected = areas[i];
          showMarkets();
          break;
        }
      }
    }
    if (!selected) {
      // Le choix département/province se fait uniquement sur la page principale Marchés.
      location.replace("choix-marches-final.html");
      return;
    }
  }
  function addRegistrationLines() {}
  window.MarketDedupV511.ready.then(init);
  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) refreshCountsOnReturn();
  });
  window.addEventListener("focus", refreshCountsOnReturn);
  window.addEventListener("pageshow", refreshCountsOnReturn);
})();
