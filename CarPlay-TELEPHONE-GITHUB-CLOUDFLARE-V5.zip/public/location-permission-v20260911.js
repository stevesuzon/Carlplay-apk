(function(){
  'use strict';
  var KEY='carplay_location_enabled';
  var lastPermission='unknown';
  function button(){return document.getElementById('locationPermissionBtn')}
  function note(){return document.getElementById('locationPermissionNote')}
  function setEnabled(ok,detail){
    var b=button(),n=note();
    if(b){
      b.classList.toggle('location-enabled',!!ok);
      b.classList.toggle('location-disabled',!ok);
      b.textContent=ok?'✅ LOCALISATION ACTIVÉE':'📍 ACTIVER LA LOCALISATION';
      b.setAttribute('aria-pressed',ok?'true':'false');
    }
    if(n){
      n.textContent=ok?'La localisation fonctionne sur cet appareil.':(detail||'Appuyez sur « Activer la localisation » pour autoriser la position.');
    }
    try{localStorage.setItem(KEY,ok?'1':'0')}catch(e){}
    document.documentElement.dataset.locationEnabled=ok?'1':'0';
    try{window.dispatchEvent(new CustomEvent('carplay-location-state',{detail:{enabled:!!ok}}))}catch(e){}
  }
  function friendly(error){
    var code=error&&error.code;
    if(code===1 || String(error&&error.message||'').indexOf('GPS_REFUSE')>=0){
      return 'Localisation bloquée. Autorisez la position pour CarPlay dans les réglages du téléphone ou du navigateur, puis appuyez sur « Activer la localisation ».';
    }
    if(code===2) return 'Localisation indisponible. Activez la localisation du téléphone puis appuyez sur « Activer la localisation ».';
    if(code===3) return 'La position met trop de temps à arriver. Vérifiez que la localisation du téléphone est activée.';
    return 'Activez la localisation du téléphone et autorisez CarPlay à utiliser votre position.';
  }
  function showHelp(error){
    var msg=friendly(error);
    setEnabled(false,msg);
    return msg;
  }
  function success(pos){
    setEnabled(true,'La localisation fonctionne sur cet appareil.');
    return pos;
  }
  function activate(){
    return new Promise(function(resolve,reject){
      if(!navigator.geolocation){
        var e=new Error('GPS_INDISPONIBLE');
        showHelp(e); reject(e); return;
      }
      var b=button(),n=note();
      if(b){b.disabled=true;b.textContent='📍 ACTIVATION…'}
      if(n)n.textContent='Demande d’autorisation de localisation…';
      navigator.geolocation.getCurrentPosition(function(pos){
        if(b)b.disabled=false;
        success(pos); resolve(pos);
      },function(err){
        if(b)b.disabled=false;
        showHelp(err); reject(err);
      },{enableHighAccuracy:true,timeout:15000,maximumAge:0});
    });
  }
  function refresh(){
    if(!navigator.geolocation){setEnabled(false,'Localisation indisponible sur cet appareil.');return}
    if(navigator.permissions&&navigator.permissions.query){
      navigator.permissions.query({name:'geolocation'}).then(function(p){
        lastPermission=p.state;
        if(p.state==='granted') setEnabled(true);
        else setEnabled(false,p.state==='denied'?'Localisation bloquée. Autorisez la position pour CarPlay dans les réglages du téléphone ou du navigateur.':'Appuyez sur « Activer la localisation » pour autoriser la position.');
        p.onchange=function(){lastPermission=p.state;if(p.state==='granted')setEnabled(true);else setEnabled(false,p.state==='denied'?'Localisation bloquée dans les réglages.':'Appuyez sur « Activer la localisation ».')};
      }).catch(function(){
        var ok=false;try{ok=localStorage.getItem(KEY)==='1'}catch(e){}setEnabled(ok);
      });
    }else{
      var ok=false;try{ok=localStorage.getItem(KEY)==='1'}catch(e){}setEnabled(ok);
    }
  }
  window.CarPlayLocation={activate:activate,refresh:refresh,success:success,showHelp:showHelp,friendly:friendly,isEnabled:function(){return document.documentElement.dataset.locationEnabled==='1'}};
  document.addEventListener('DOMContentLoaded',function(){
    var b=button();if(b)b.addEventListener('click',function(){activate().catch(function(){})});
    refresh();
  });
  document.addEventListener('visibilitychange',function(){if(!document.hidden)refresh()});
  window.addEventListener('focus',refresh);
})();
