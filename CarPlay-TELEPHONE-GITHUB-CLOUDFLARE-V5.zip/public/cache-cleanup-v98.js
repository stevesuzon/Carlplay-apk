(function automaticCacheCleanup(){
  'use strict';
  var VERSION='20260902-v98-points-verification',CURRENT_CACHE='carplay-v5-20260902-v98-points-verification',KEY='carplay_cache_cleanup_version',BACKUP_KEY='carplay_update_local_backup';
  try{
    var old=sessionStorage.getItem(BACKUP_KEY),values,names,i,name,backup={};
    if(old){values=JSON.parse(old);names=Object.keys(values);for(i=0;i<names.length;i++)if(localStorage.getItem(names[i])===null)localStorage.setItem(names[i],values[names[i]]);sessionStorage.removeItem(BACKUP_KEY)}
    if(localStorage.getItem(KEY)===VERSION)return;
    for(i=0;i<localStorage.length;i++){name=localStorage.key(i);if(name&&name!=='carplay_admin_secret'&&name!=='carplay_admin_here')backup[name]=localStorage.getItem(name)}
    sessionStorage.setItem(BACKUP_KEY,JSON.stringify(backup));
    var cleanup=('caches' in window?caches.keys().then(function(keys){return Promise.all(keys.filter(function(key){return key!==CURRENT_CACHE}).map(function(key){return caches.delete(key)}))}):Promise.resolve());
    cleanup.then(function(){if('serviceWorker' in navigator)return navigator.serviceWorker.getRegistrations().then(function(registrations){return Promise.all(registrations.map(function(registration){return registration.update().catch(function(){})}))})}).then(function(){localStorage.setItem(KEY,VERSION)}).catch(function(){});
  }catch(e){}
})();
