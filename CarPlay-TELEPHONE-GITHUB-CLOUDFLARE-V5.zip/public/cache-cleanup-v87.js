(function automaticCacheCleanup(){
  'use strict';
  var VERSION='20260902-v87-wellen-photos';
  var CURRENT_CACHE='carplay-v5-20260902-v87-wellen-photos';
  var KEY='carplay_cache_cleanup_version';
  try{
    if(localStorage.getItem(KEY)===VERSION)return;
    var cleanup=('caches' in window?caches.keys().then(function(keys){
      return Promise.all(keys.filter(function(key){return key!==CURRENT_CACHE}).map(function(key){return caches.delete(key)}));
    }):Promise.resolve());
    cleanup.then(function(){
      if('serviceWorker' in navigator)return navigator.serviceWorker.getRegistrations().then(function(registrations){
        return Promise.all(registrations.map(function(registration){return registration.update().catch(function(){})}));
      });
    }).then(function(){localStorage.setItem(KEY,VERSION)}).catch(function(){});
  }catch(e){}
})();
