(function(){
  'use strict';
  var days=['lundi','mardi','mercredi','jeudi','vendredi','samedi','dimanche'];
  var excluded=/producteur|producent|paysan|fermier|boerenmarkt|marche bio|biologique|ferme|hoeve|vente directe|artisanal|ambacht|metiers d art|marche (?:des |aux )?arts?|fleurs|bloemenmarkt|createur|makers market|salon|brocante|puces|antiquit|livres?/;
  function norm(v){return String(v||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[’']/g,"'").replace(/\s+/g,' ').trim()}
  function singleDate(note){var m=String(note||'').match(/Période publiée : (\d{4}-\d{2}-\d{2})<->(\d{4}-\d{2}-\d{2})/);return !!(m&&m[1]===m[2])}
  function keep(r){
    if(!Array.isArray(r)||String(r[1])!=='marche')return false;
    if(days.indexOf(norm(r[4]))<0)return false;
    if(excluded.test(norm([r[2],r[6],r[8]].join(' '))))return false;
    if(singleDate(r[6]))return false;
    return true;
  }
  function clean(target){if(!Array.isArray(target))return;for(var i=target.length-1;i>=0;i--)if(!keep(target[i]))target.splice(i,1)}
  clean(window.data);clean(window.NEAR_FR);clean(window.NEAR_BE);
})();
