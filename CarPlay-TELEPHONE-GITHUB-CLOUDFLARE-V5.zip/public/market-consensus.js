(function sharedMarketConsensus(){
  'use strict';
  var cardsRoot=document.getElementById('cards')||document.getElementById('list'),timer=0,lastSignature='';
  if(!cardsRoot)return;
  var style=document.createElement('style');
  style.textContent='.card{position:relative}.marketVerificationDot{position:absolute;right:10px;top:10px;width:27px;height:27px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 9px #000,0 0 7px currentColor;z-index:2;cursor:pointer;touch-action:manipulation}.marketVerificationDot.green{background:#24c96b;color:#24c96b}.marketVerificationDot.orange{background:#f39b19;color:#f39b19}.verificationSent{display:inline-flex;align-items:center;color:#f39b19;font-size:14px;font-weight:900}.sharedMarketPhoto{display:block;width:min(150px,100%);aspect-ratio:1/1;height:auto;margin:10px auto;border:3px solid #f39b19;border-radius:14px;object-fit:contain;background:#000;cursor:pointer}.addMarketPhoto{display:flex;width:100%;max-width:360px;min-height:105px;margin:10px 0;align-items:center;justify-content:center;border:3px dashed #62d8ff;border-radius:14px;background:#081727;color:#62d8ff;text-align:center;text-decoration:none;font-size:18px;font-weight:950}.sharedPhotoModal{position:fixed;inset:0;z-index:400000;display:none;align-items:center;justify-content:center;padding:18px;background:#000e}.sharedPhotoModal.open{display:flex}.sharedPhotoModal img{display:block;max-width:94vw;max-height:86vh;border:3px solid #f39b19;border-radius:16px;background:#000}.sharedPhotoClose{position:fixed;right:20px;top:20px;width:48px;height:48px;border:0;border-radius:50%;background:#f39b19;color:#111;font-size:28px;font-weight:950}';
  document.head.appendChild(style);
  var modal=document.createElement('div');modal.className='sharedPhotoModal';modal.innerHTML='<button type="button" class="sharedPhotoClose" aria-label="Fermer">×</button><img alt="Vue générale du marché">';document.body.appendChild(modal);
  function close(){modal.classList.remove('open');modal.querySelector('img').removeAttribute('src')}
  modal.querySelector('button').onclick=close;modal.onclick=function(e){if(e.target===modal)close()};
  function setLine(card,prefix,value,count){var lines=card.querySelectorAll('.meta'),i,line;for(i=0;i<lines.length;i++){line=lines[i];if(line.textContent.trim().indexOf(prefix)===0){line.textContent=prefix+' '+value;return}}}
  function marketType(card){if(card.dataset.marketType)return card.dataset.marketType;try{var u=card.dataset.verifyUrl?new URL(card.dataset.verifyUrl,location.href):null,t=u&&u.searchParams.get('type');if(t){card.dataset.marketType=t;return t}}catch(e){}return ''}
  function setCapacityLine(card,value){var t=marketType(card),lines=card.querySelectorAll('.meta'),prefixes=['👥 Commerçants :','👥 Nombre de places / commerçants :','👥 Places / commerçants :','👥 Nombre d’emplacements / commerçants :','👥 Emplacements / commerçants :','👥 Nombre d’emplacements / exposants :','👥 Emplacements / exposants :','🎄 Nombre de chalets :','🎄 Emplacements / exposants :'];var wanted=t==='noel'?'🎄 Nombre de chalets :':(t==='brocante'||t==='voyageur'?'👥 Nombre d’emplacements / exposants :':'👥 Nombre de places / commerçants :');for(var i=0;i<lines.length;i++){var txt=lines[i].textContent.trim();for(var j=0;j<prefixes.length;j++)if(txt.indexOf(prefixes[j])===0){lines[i].textContent=wanted+' '+value;return}}}
  function cleanTechnicalType(card){var lines=card.querySelectorAll('.meta'),i,text;for(i=0;i<lines.length;i++){text=lines[i].textContent.trim();if(text.indexOf('🛍️ Type :')===0){lines[i].remove();return}}}
  function wireVerificationDot(card,dot){
    if(!card||!dot)return;
    var url=card.dataset.verifyUrl||'';
    if(!url){dot.removeAttribute('role');dot.removeAttribute('tabindex');return}
    dot.setAttribute('role','button');
    dot.setAttribute('tabindex','0');
    dot.style.pointerEvents='auto';
    if(dot.dataset.verifyWired==='1')return;
    dot.dataset.verifyWired='1';
    function openVerify(e){
      try{if(e){e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation()}}catch(_){}
      var target=card.dataset.verifyUrl||'';
      if(target)location.href=target;
    }
    dot.addEventListener('click',openVerify,true);
    dot.addEventListener('touchend',openVerify,{capture:true,passive:false});
    dot.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){openVerify(e)}},true);
  }
  function updatePhotoSlot(card,state){
    var add=card.querySelector('.addMarketPhoto'),img=card.querySelector('.sharedMarketPhoto'),firstMeta=card.querySelector('.meta');
    if(state&&state.photo){
      if(add)add.remove();
      if(!img){
        img=document.createElement('img');
        img.className='sharedMarketPhoto';
        img.loading='lazy';
        img.alt='Vue générale reconnue et liée au point GPS du marché';
        img.onclick=function(){modal.querySelector('img').src=img.src;modal.classList.add('open')};
        if(firstMeta)card.insertBefore(img,firstMeta);else card.appendChild(img);
      }
      if(img.src!==state.photo.url)img.src=state.photo.url;
    }else{
      if(img)img.remove();
      if(!add&&card.dataset.verifyUrl){
        add=document.createElement('a');
        add.className='addMarketPhoto';
        add.href=card.dataset.verifyUrl+(card.dataset.verifyUrl.indexOf('?')>=0?'&':'?')+'photo=1';
        add.innerHTML='📷 AJOUTER UNE PHOTO<br>GPS sur place + photo obligatoire';
        firstMeta=card.querySelector('.meta');
        if(firstMeta)card.insertBefore(add,firstMeta);else card.appendChild(add);
      }
    }
  }
  function applyCard(card,state){var v=state&&state.values||{},presence=v.exists?String(v.exists.value||'').toLowerCase():'';if(card.dataset.marketKey&&presence){try{localStorage.setItem('marketPresenceV174:'+card.dataset.marketKey,presence)}catch(e){}}if(presence==='non'){card.dataset.marketDisabled='1';card.style.display='none';return}if(presence==='oui'&&card.dataset.marketKey){try{localStorage.removeItem('marketPresenceV174:'+card.dataset.marketKey)}catch(e){}}if(card.dataset.marketDisabled==='1'){delete card.dataset.marketDisabled;card.style.removeProperty('display')}var mt=marketType(card),done=((mt==='brocante'||mt==='noel')?!!(v.time&&v.count):!!(v.time&&v.count&&v.draw&&v.clientModel))||card.dataset.localVerified==='1',dot=card.querySelector('.marketVerificationDot');if(state&&state.location){card.dataset.verifiedLat=state.location.latitude;card.dataset.verifiedLon=state.location.longitude;card.dataset.verifiedAddress=state.location.address||'';try{localStorage.setItem('marketLocalLocationV1:'+(card.dataset.marketKey||''),JSON.stringify({latitude:Number(state.location.latitude),longitude:Number(state.location.longitude),address:state.location.address||'',pending:false,updatedAt:Date.now()}))}catch(e){}try{window.dispatchEvent(new CustomEvent('carplay-market-gps-updated',{detail:{marketKey:card.dataset.marketKey}}))}catch(e){}try{var rows=typeof marketRows==='function'?marketRows():[];for(var ri=0;ri<rows.length;ri++){if(typeof identity==='function'&&identity(rows[ri])===(card.dataset.marketKey||'')){rows[ri][10]=Number(state.location.latitude);rows[ri][11]=Number(state.location.longitude);if(state.location.address)rows[ri][8]=state.location.address;break}}}catch(e){}var metas=card.querySelectorAll('.meta');for(var mi=0;mi<metas.length;mi++){if(metas[mi].textContent.trim().indexOf('📍')===0&&state.location.address){metas[mi].textContent='📍 '+state.location.address;break}}}if(!dot){dot=document.createElement('span');card.appendChild(dot)}dot.className='marketVerificationDot '+(done?'green':'orange');dot.title=done?'Fiche vérifiée':'Fiche à vérifier';dot.setAttribute('aria-label',dot.title);if(v.time)setLine(card,'🕒',v.time.value,v.time.confirmations);if(v.count)setCapacityLine(card,v.count.value);if(v.draw)setLine(card,'Tirage au sort :',v.draw.value,v.draw.confirmations);if(v.welcome)setLine(card,'Humeur du placier :',v.welcome.value,v.welcome.confirmations);if(v.placer)setLine(card,'Responsable :',v.placer.value,v.placer.confirmations);if(v.clientModel)setLine(card,'Modèle de clients :',v.clientModel.value,v.clientModel.confirmations);updatePhotoSlot(card,state);wireVerificationDot(card,dot)}
  function refresh(force){var cards=[].slice.call(cardsRoot.querySelectorAll('.card')),items=[],keys=[];cards.forEach(function(card){var key=card.dataset.marketKey||'',link=card.querySelector('a.verify'),url,localKey='',dot;cleanTechnicalType(card);dot=card.querySelector('.marketVerificationDot');if(!dot){dot=document.createElement('span');card.appendChild(dot)}dot.className='marketVerificationDot orange';dot.title='Fiche à vérifier';dot.setAttribute('aria-label',dot.title);if(link){try{url=new URL(link.href,location.href);card.dataset.verifyUrl=url.href;key=key||url.searchParams.get('mk')||'';localKey=url.searchParams.get('k')||'';var mt=url.searchParams.get('type')||'';if(mt)card.dataset.marketType=mt}catch(e){}if(localKey&&localStorage.getItem(localKey)){card.dataset.localVerified='1';dot.className='marketVerificationDot green';dot.title='Fiche vérifiée';dot.setAttribute('aria-label',dot.title)}wireVerificationDot(card,dot)}if(key){card.dataset.marketKey=key;try{if(localStorage.getItem('marketPresenceV174:'+key)==='non'){card.dataset.marketDisabled='1';card.style.display='none'}}catch(e){}try{var localLoc=JSON.parse(localStorage.getItem('marketLocalLocationV1:'+key)||'null');if(localLoc&&Number.isFinite(Number(localLoc.latitude))&&Number.isFinite(Number(localLoc.longitude))){card.dataset.verifiedLat=Number(localLoc.latitude);card.dataset.verifiedLon=Number(localLoc.longitude);card.dataset.verifiedAddress=localLoc.address||'';var rows=typeof marketRows==='function'?marketRows():[];for(var li=0;li<rows.length;li++){if(typeof identity==='function'&&identity(rows[li])===key){rows[li][10]=Number(localLoc.latitude);rows[li][11]=Number(localLoc.longitude);if(localLoc.address)rows[li][8]=localLoc.address;break}}var lm=card.querySelectorAll('.meta');for(var lmi=0;lmi<lm.length;lmi++){if(lm[lmi].textContent.trim().indexOf('📍')===0&&localLoc.address){lm[lmi].textContent='📍 '+localLoc.address;break}}}}catch(e){}items.push({card:card,key:key});keys.push(key)}});var signature=keys.join('\n');if(!keys.length||(!force&&signature===lastSignature))return;lastSignature=signature;fetch('/api/market-verifications/batch',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({keys:keys}),cache:'no-store'}).then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(j){items.forEach(function(item){applyCard(item.card,j.states&&j.states[item.key]||null)})}).catch(function(){items.forEach(function(item){updatePhotoSlot(item.card,null)});lastSignature=''})}
  function forceRefresh(){refresh(true)}
  new MutationObserver(function(){clearTimeout(timer);timer=setTimeout(function(){refresh(false)},120)}).observe(cardsRoot,{childList:true});
  window.addEventListener('pageshow',forceRefresh);
  window.addEventListener('focus',forceRefresh);
  document.addEventListener('visibilitychange',function(){if(!document.hidden)forceRefresh()});
  setInterval(function(){if(!document.hidden)forceRefresh()},30000);
  refresh(true);
})();
