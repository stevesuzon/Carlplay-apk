(function sharedMarketConsensus(){
  'use strict';
  var cardsRoot=document.getElementById('cards'),timer=0,lastSignature='';
  if(!cardsRoot)return;
  var style=document.createElement('style');
  style.textContent='.card{position:relative}.marketVerificationDot{position:absolute;right:13px;top:13px;width:19px;height:19px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 9px #000,0 0 7px currentColor;z-index:2}.marketVerificationDot.green{background:#24c96b;color:#24c96b}.marketVerificationDot.orange{background:#f39b19;color:#f39b19}.sharedConfirmed{display:inline-block;margin-left:7px;padding:2px 7px;border-radius:8px;background:#0b6d38;color:#fff;font-size:12px;font-weight:950}.verificationSent{display:inline-flex;align-items:center;color:#f39b19;font-size:14px;font-weight:900}.sharedMarketPhoto{display:block;width:min(150px,100%);aspect-ratio:1/1;height:auto;margin:10px auto;border:3px solid #f39b19;border-radius:14px;object-fit:contain;background:#000;cursor:pointer}.addMarketPhoto{display:flex;width:100%;max-width:360px;min-height:105px;margin:10px 0;align-items:center;justify-content:center;border:3px dashed #62d8ff;border-radius:14px;background:#081727;color:#62d8ff;text-align:center;text-decoration:none;font-size:18px;font-weight:950}.sharedPhotoModal{position:fixed;inset:0;z-index:400000;display:none;align-items:center;justify-content:center;padding:18px;background:#000e}.sharedPhotoModal.open{display:flex}.sharedPhotoModal img{display:block;max-width:94vw;max-height:86vh;border:3px solid #f39b19;border-radius:16px;background:#000}.sharedPhotoClose{position:fixed;right:20px;top:20px;width:48px;height:48px;border:0;border-radius:50%;background:#f39b19;color:#111;font-size:28px;font-weight:950}';
  document.head.appendChild(style);
  var modal=document.createElement('div');modal.className='sharedPhotoModal';modal.innerHTML='<button type="button" class="sharedPhotoClose" aria-label="Fermer">×</button><img alt="Vue générale du marché">';document.body.appendChild(modal);
  function close(){modal.classList.remove('open');modal.querySelector('img').removeAttribute('src')}
  modal.querySelector('button').onclick=close;modal.onclick=function(e){if(e.target===modal)close()};
  function confirmedLabel(n){var span=document.createElement('span');span.className='sharedConfirmed';span.textContent='✓ serveur — '+n+' confirmations';return span}
  function setLine(card,prefix,value,count){var lines=card.querySelectorAll('.meta'),i,line;for(i=0;i<lines.length;i++){line=lines[i];if(line.textContent.trim().indexOf(prefix)===0){line.textContent=prefix+' '+value;line.appendChild(confirmedLabel(count));return}}}
  function cleanTechnicalType(card){var lines=card.querySelectorAll('.meta'),i,text;for(i=0;i<lines.length;i++){text=lines[i].textContent.trim();if(text.indexOf('🛍️ Type :')===0){lines[i].remove();return}}}
  function updatePhotoSlot(card,state){
    var add=card.querySelector('.addMarketPhoto'),img=card.querySelector('.sharedMarketPhoto'),firstMeta=card.querySelector('.meta');
    if(state&&state.photo){
      if(add)add.remove();
      if(!img){
        img=document.createElement('img');
        img.className='sharedMarketPhoto';
        img.loading='lazy';
        img.alt='Vue générale reconnue et liée au point GPS du marché';
        img.onclick=function(){modal.querySelector('img').src=img.src;modal.classList.add('open')};
        if(firstMeta)card.insertBefore(img,firstMeta);else card.appendChild(img);
      }
      if(img.src!==state.photo.url)img.src=state.photo.url;
    }else{
      if(img)img.remove();
      if(!add&&card.dataset.verifyUrl){
        add=document.createElement('a');
        add.className='addMarketPhoto';
        add.href=card.dataset.verifyUrl+(card.dataset.verifyUrl.indexOf('?')>=0?'&':'?')+'photo=1';
        add.innerHTML='📷 AJOUTER UNE PHOTO<br>GPS sur place + photo obligatoire';
        firstMeta=card.querySelector('.meta');
        if(firstMeta)card.insertBefore(add,firstMeta);else card.appendChild(add);
      }
    }
  }
  function applyCard(card,state){var v=state&&state.values||{},done=!!(v.time&&v.count&&v.draw&&v.clientModel)||card.dataset.localVerified==='1',dot=card.querySelector('.marketVerificationDot');if(state&&state.location){card.dataset.verifiedLat=state.location.latitude;card.dataset.verifiedLon=state.location.longitude;card.dataset.verifiedAddress=state.location.address||'';try{localStorage.setItem('marketLocalLocationV1:'+(card.dataset.marketKey||''),JSON.stringify({latitude:Number(state.location.latitude),longitude:Number(state.location.longitude),address:state.location.address||'',pending:false,updatedAt:Date.now()}))}catch(e){}try{var rows=typeof marketRows==='function'?marketRows():[];for(var ri=0;ri<rows.length;ri++){if(typeof identity==='function'&&identity(rows[ri])===(card.dataset.marketKey||'')){rows[ri][10]=Number(state.location.latitude);rows[ri][11]=Number(state.location.longitude);if(state.location.address)rows[ri][8]=state.location.address;break}}}catch(e){}var metas=card.querySelectorAll('.meta');for(var mi=0;mi<metas.length;mi++){if(metas[mi].textContent.trim().indexOf('📍')===0&&state.location.address){metas[mi].textContent='📍 '+state.location.address;break}}}if(!dot){dot=document.createElement('span');card.appendChild(dot)}dot.className='marketVerificationDot '+(done?'green':'orange');dot.title=done?'Fiche vérifiée':'Fiche à vérifier';dot.setAttribute('aria-label',dot.title);if(v.time)setLine(card,'🕒',v.time.value,v.time.confirmations);if(v.count)setLine(card,'👥 Commerçants :',v.count.value+' places',v.count.confirmations);if(v.draw)setLine(card,'Tirage au sort :',v.draw.value,v.draw.confirmations);if(v.clientModel)setLine(card,'Modèle de clients :',v.clientModel.value,v.clientModel.confirmations);updatePhotoSlot(card,state)}
  function refresh(force){var cards=[].slice.call(cardsRoot.querySelectorAll('.card')),items=[],keys=[];cards.forEach(function(card){var key=card.dataset.marketKey||'',link=card.querySelector('a.verify'),url,localKey='',dot;cleanTechnicalType(card);dot=card.querySelector('.marketVerificationDot');if(!dot){dot=document.createElement('span');card.appendChild(dot)}dot.className='marketVerificationDot orange';dot.title='Fiche à vérifier';dot.setAttribute('aria-label',dot.title);if(link){try{url=new URL(link.href,location.href);card.dataset.verifyUrl=url.href;key=key||url.searchParams.get('mk')||'';localKey=url.searchParams.get('k')||''}catch(e){}if(localKey&&localStorage.getItem(localKey)){card.dataset.localVerified='1';dot.className='marketVerificationDot green';dot.title='Fiche vérifiée';dot.setAttribute('aria-label',dot.title)}}if(key){card.dataset.marketKey=key;try{var localLoc=JSON.parse(localStorage.getItem('marketLocalLocationV1:'+key)||'null');if(localLoc&&Number.isFinite(Number(localLoc.latitude))&&Number.isFinite(Number(localLoc.longitude))){card.dataset.verifiedLat=Number(localLoc.latitude);card.dataset.verifiedLon=Number(localLoc.longitude);card.dataset.verifiedAddress=localLoc.address||'';var rows=typeof marketRows==='function'?marketRows():[];for(var li=0;li<rows.length;li++){if(typeof identity==='function'&&identity(rows[li])===key){rows[li][10]=Number(localLoc.latitude);rows[li][11]=Number(localLoc.longitude);if(localLoc.address)rows[li][8]=localLoc.address;break}}var lm=card.querySelectorAll('.meta');for(var lmi=0;lmi<lm.length;lmi++){if(lm[lmi].textContent.trim().indexOf('📍')===0&&localLoc.address){lm[lmi].textContent='📍 '+localLoc.address;break}}}}catch(e){}items.push({card:card,key:key});keys.push(key)}});var signature=keys.join('\n');if(!keys.length||(!force&&signature===lastSignature))return;lastSignature=signature;fetch('/api/market-verifications/batch',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({keys:keys}),cache:'no-store'}).then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(j){items.forEach(function(item){applyCard(item.card,j.states&&j.states[item.key]||null)})}).catch(function(){items.forEach(function(item){updatePhotoSlot(item.card,null)});lastSignature=''})}
  function forceRefresh(){refresh(true)}
  new MutationObserver(function(){clearTimeout(timer);timer=setTimeout(function(){refresh(false)},120)}).observe(cardsRoot,{childList:true});
  window.addEventListener('pageshow',forceRefresh);
  window.addEventListener('focus',forceRefresh);
  document.addEventListener('visibilitychange',function(){if(!document.hidden)forceRefresh()});
  setInterval(function(){if(!document.hidden)forceRefresh()},15000);
  refresh(true);
})();
