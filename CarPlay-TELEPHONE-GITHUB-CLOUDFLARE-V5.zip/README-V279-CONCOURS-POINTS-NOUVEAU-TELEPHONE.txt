VERSION V279 — CONCOURS ET POINTS APRÈS CHANGEMENT DE TÉLÉPHONE

- À chaque ouverture, la participation au concours est synchronisée avec le téléphone actuellement lié au compte.
- Les anciens points et la position dans le classement restent attachés au même abonnement.
- Une sécurité supplémentaire retrouve le participant par son abonnement lors de l’envoi d’une fiche marché.
- Les points des marchés peuvent ainsi être attribués correctement après une réinstallation ou un changement de téléphone.
- La section administrateur Bannir / Débannir ajoutée dans la V278 est conservée.
