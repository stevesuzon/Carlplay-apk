COUTEAU SUISSE V284 — PARCOURS INSTALLATION / FORMULAIRE

1. Premier écran
- Un seul bouton : REGARDER LA VIDÉO.
- Aucun bouton d’installation gris affiché avant la vidéo.
- Aucun formulaire ne se déclenche automatiquement à la fin de la vidéo.

2. Fin de vidéo
- Le même bouton devient INSTALLER L’APPLICATION.
- L’utilisateur doit appuyer lui-même dessus.

3. Formulaire
- Après appui : Nom + Prénom + Adresse e-mail obligatoires.
- Validation : création/récupération du compte serveur puis ouverture du site.
- Les coordonnées restent mémorisées dans Réglages.

4. Abonnement
- Si le serveur retrouve un abonnement actif correspondant, le même abonnement est rattaché au téléphone.
- La date de fin existante est conservée : aucun nouveau délai ne remplace les jours restants.
- Un nouvel utilisateur suit la logique d’essai déjà existante.

5. Cache ciblé
- Seul le module installation passe au cache V284.
- Les caches icônes, concours et données restent en V283.
- Aucune suppression des adresses, devis ou autres données utilisateur.
