V309 — ACCÈS DIRECT APRÈS CONFIRMATION E-MAIL

- Le formulaire Nom / Prénom / E-mail ne sert qu’une seule fois pour un nouveau compte.
- Le clic sur le lien reçu par e-mail valide immédiatement le compte côté serveur.
- Après confirmation, l’utilisateur est inscrit directement et arrive sur Couteau Suisse sans revoir le formulaire.
- Les anciens utilisateurs déjà reconnus continuent d’entrer directement sans refaire l’inscription.
- Au démarrage, la vérification d’un compte déjà confirmé passe avant l’écran d’installation et avant le formulaire.
- Les protections V307/V308 contre les boucles de retour et de rechargement sont conservées.
