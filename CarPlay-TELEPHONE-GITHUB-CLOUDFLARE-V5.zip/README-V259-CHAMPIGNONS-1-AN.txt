V259 — ABONNEMENT CHAMPIGNONS 1 AN

- Abonnement Champignons : 50 € pour 1 an.
- Les nouveaux codes Champignons ajoutent 365 jours.
- Les codes Champignons déjà créés gardent la durée qui était enregistrée lors de leur création.
- L’accès Champignons reste gratuit pendant la période d’essai principale de Couteau Suisse.
- Toutes les corrections V256, V257 et V258 sont conservées.
