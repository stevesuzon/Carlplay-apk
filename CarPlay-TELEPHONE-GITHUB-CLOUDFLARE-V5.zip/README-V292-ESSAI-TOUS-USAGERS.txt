COUTEAU SUISSE V292 — PÉRIODE D’ESSAI NOUVEAUX ET ANCIENS UTILISATEURS

- Le bandeau bleu « MOIS D’ESSAI COUTEAU SUISSE » apparaît en haut à gauche de l’écran d’accueil pendant toute la période d’essai.
- Il affiche le nombre de jours restants.
- Les nouveaux comptes et les comptes déjà enregistrés utilisent la même échéance d’essai lorsqu’elle est enregistrée côté serveur.
- Au chargement de l’accueil, l’application resynchronise l’échéance depuis /api/contest/status.
- Dès qu’un abonnement annuel ou à vie est actif, le bandeau bleu d’essai disparaît automatiquement.
- Les données d’identité et d’abonnement existantes ne sont pas supprimées.
