COUTEAU SUISSE — V296 — RATTRAPAGE POINTS + GASOIL

- Administration > Demandes à valider contient un bouton « RATTRAPER LES FICHES DÉJÀ REMPLIES ».
- Ce bouton valide en lot uniquement les fiches Marché et Champignons envoyées avant le 19/09/2026 à 07:43 (heure France), c’est-à-dire les fiches déjà présentes au moment de la demande de rattrapage.
- Les fiches envoyées après cette heure restent à valider individuellement par l’administrateur.
- La protection anti-doublon reste active : une fiche déjà créditée ne reçoit jamais une deuxième fois les mêmes points.
- Les fiches déjà marquées approuvées mais dont le crédit avait échoué sont auditées et réparées automatiquement lors de l’ouverture de l’administration.
- Le résultat du rattrapage affiche le nom de chaque personne, le nombre de fiches rattrapées et les points réellement crédités. Ryan Vercruise apparaîtra donc dans le résultat s’il possède des fiches éligibles dans la base D1.

GASOIL
- Prix utilisé : 2,40 € / litre.
- Consommation de référence : 7 L / 100 km.
- L’application calcule le trajet ALLER seulement.
- Elle affiche : kilomètres, litres calculés, prix du litre, coût total en euros et points de déplacement.
- Règle : 1 € de gasoil = 1 point de déplacement.
- Exemple 100 km : 7,00 L × 2,40 € = 16,80 € = +16,80 points.
- Les nouveaux calculs et les demandes encore en attente sont arrondis à 2 décimales.

Aucune adresse, devis, abonnement, photo, GPS ou autre donnée métier n’est supprimé.
Mise à jour de cache ciblée : concours/admin uniquement.
