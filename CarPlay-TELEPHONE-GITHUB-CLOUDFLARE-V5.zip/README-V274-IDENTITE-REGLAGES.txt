VERSION V274 — IDENTITÉ AUTOMATIQUE DANS RÉGLAGES

- Le nom, le prénom et l'adresse e-mail renseignés lors de la première ouverture
  sont maintenant repris automatiquement dans Réglages > Abonnement.
- Le remplissage fonctionne aussi pendant les 7 jours d'essai gratuit.
- Les champs sont mis à jour immédiatement après la première identification,
  sans devoir fermer puis rouvrir l'application.
- La récupération d'un ancien abonnement conserve exactement les jours restants.
