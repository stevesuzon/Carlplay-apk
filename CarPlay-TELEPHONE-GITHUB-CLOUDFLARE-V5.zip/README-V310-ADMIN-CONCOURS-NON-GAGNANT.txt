V310 — ADMINISTRATEUR DANS LE CONCOURS

- Steve Suzon peut désormais ouvrir le concours comme les autres utilisateurs.
- Son compte gagne les points normalement (marchés, brocantes, Noël, voyageurs, parrainage, etc.).
- Steve apparaît dans le classement avec la mention « non gagnant ».
- Steve n'est jamais sélectionné parmi les 5 gagnants finaux.
- Si Steve est dans les 5 premières places, le lot passe automatiquement au participant éligible suivant.
- Les anciens blocages contest_excluded du compte administrateur sont réactivés automatiquement au déploiement.
- Cache concours ciblé passé en V310.
