COUTEAU SUISSE V240 — COIN DÉTENTE & CHAMPIGNONS

La reconnaissance photo utilise Cloudflare Workers AI avec le binding nommé exactement : AI
Modèle utilisé : @cf/meta/llama-3.2-11b-vision-instruct
Aucune clé d’API externe n’est intégrée au code.

Bindings déjà utilisés par l’application :
- DB : base D1
- MARKET_PHOTOS : bucket R2 pour les photos
- AI : Workers AI pour la reconnaissance des champignons

Dans Cloudflare, si le binding AI n’existe pas encore, ajoutez un binding Workers AI nommé AI puis redéployez.
La reconnaissance sert uniquement au classement. Elle ne donne jamais de conseil de comestibilité.
