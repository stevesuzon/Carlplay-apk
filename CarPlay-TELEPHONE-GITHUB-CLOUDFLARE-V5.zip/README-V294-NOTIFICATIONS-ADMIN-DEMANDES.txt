COUTEAU SUISSE V294 — NOTIFICATIONS ADMINISTRATEUR / DEMANDES À VALIDER

Correction ciblée à partir de V293.

Nouveau comportement :
- Une nouvelle fiche marché envoyée pour le concours déclenche un push administrateur.
- Une nouvelle fiche Champignons envoyée pour le concours déclenche un push administrateur.
- Un bug, problème ou une idée envoyée déclenche un push administrateur.
- Une demande de changement de commune déclenche un push administrateur.
- Un message envoyé depuis l'application déclenche un push administrateur.
- Une réponse à une alerte de déplacement déclenche un nouveau push administrateur.
- Les demandes de modification d'une fiche marché (GPS/photo/horaire/etc.) gardaient déjà leur push et continuent de fonctionner.

Le push ouvre l'administration et indique : « Nouvelle demande à valider ».
Les points des fiches marché, Champignons et signalements restent attribués seulement après validation par l'administrateur.
Le parrainage conserve son attribution automatique prévue (+320 / +96) après validation de l'e-mail.

Mise à jour ciblée : aucune donnée utilisateur, adresse, devis ou fiche existante n'est effacée.
