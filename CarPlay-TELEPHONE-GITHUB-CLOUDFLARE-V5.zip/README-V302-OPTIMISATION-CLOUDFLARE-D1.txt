COUTEAU SUISSE — V302 — OPTIMISATION CLOUDFLARE D1
Date : 19/09/2026

BUT
Réduire fortement les lectures D1 (rows_read) qui déclenchaient l'alerte Cloudflare à 75 % de la limite quotidienne.

CAUSES PRINCIPALES TROUVÉES
1. Le concours rechargeait le classement complet toutes les 10 secondes sur l'accueil.
2. Quand la fenêtre Concours était ouverte, le classement complet était relu toutes les 3 secondes.
3. La préparation des tables du concours relançait régulièrement un rattrapage global de tous les utilisateurs/abonnements.
4. La page administrateur rechargeait très souvent les demandes et le concours, avec des lectures inutiles de tous les participants.
5. Plusieurs contrôles globaux (sanctions, présence marchés, statistiques, messages admin) interrogeaient D1 trop souvent.

CORRECTIONS V302
- Accueil concours : contrôle toutes les 60 s au lieu de 10 s et SANS relire le classement complet.
- Fenêtre Concours : classement actualisé toutes les 15 s au lieu de 3 s.
- Le classement complet n'est demandé que lorsque la fenêtre Concours est ouverte.
- Les contrôles s'arrêtent quand l'application/page est en arrière-plan.
- Rattrapage global des participants limité à une fois toutes les 6 heures au maximum.
- Initialisation des schémas D1 mise en cache dans le Worker pour éviter les mêmes opérations à chaque requête.
- Ajout d'index D1 sur les abonnements, classements, demandes concours, messages, sanctions, présence et marchés.
- Administration : les demandes sont contrôlées moins souvent et le compteur utilise désormais un résumé léger au lieu de charger toutes les données du concours.
- Audit/récupération administrateur limité à une fois toutes les 10 minutes.
- Compteur d'utilisateurs admin : toutes les 5 minutes.
- Sanctions : toutes les 60 s ; message direct admin : toutes les 30 s.
- Présence/vérification marchés : toutes les 30 s.
- Statistiques utilisateurs : toutes les 5 minutes.
- Présence accueil : toutes les 2 minutes.
- Service Worker et app-version passés en V302 avec invalidation ciblée des modules modifiés.

IMPORTANT
Aucune fiche, aucun point concours, aucun abonnement, aucune photo, aucune adresse, aucun devis et aucune donnée utilisateur existante ne sont supprimés par cette mise à jour.

IMPACT ATTENDU
L'ancienne logique pouvait à elle seule relire le classement des milliers de fois par jour. Avec 100 participants, une seule session laissée ouverte pouvait générer des centaines de milliers à plusieurs millions de lignes lues. La V302 supprime les lectures de classement en arrière-plan et réduit fortement la fréquence des autres contrôles.

TESTS EFFECTUÉS
- Vérification de syntaxe de tous les fichiers JavaScript : OK.
- Vérification SQL locale des nouvelles requêtes de résumé administrateur et du verrou de maintenance : OK.
- Comparaison avec le ZIP d'origine : aucun fichier supprimé.
