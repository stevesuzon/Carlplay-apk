COUTEAU SUISSE — V299 — BULLE : COÛT TOTAL DU GASOIL

Modification ciblée du module Concours.

Quand une validation contient un déplacement, la bulle affiche :
- le trajet aller en kilomètres ;
- les litres utilisés ;
- le coût TOTAL du gasoil en euros ;
- les points de déplacement gagnés.

Le prix du litre (ex. 2,40 €/L) n’est PAS affiché dans la bulle.
Il reste utilisé en interne pour calculer correctement le coût et les points.

Les autres éléments de la fiche restent détaillés uniquement s’ils ont réellement rapporté des points.
Le total gagné reste affiché avec deux décimales maximum et une virgule.

Cache : invalidation ciblée du module Concours uniquement.
Les adresses, devis, photos, GPS et abonnements ne sont pas vidés.
