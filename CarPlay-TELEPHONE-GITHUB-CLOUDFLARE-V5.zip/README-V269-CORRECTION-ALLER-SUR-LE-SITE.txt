V269 — CORRECTION « ALLER SUR LE SITE »

- Base : V268 complète, aucune fonction supprimée.
- Corrige la boucle visible après la vidéo d’installation.
- Après « ALLER SUR LE SITE », la vraie page Couteau Suisse s’affiche maintenant dans le navigateur.
- Le passage est gardé uniquement dans l’onglet courant afin de laisser le temps d’utiliser Partager / Ajouter à l’écran d’accueil.
- À l’ouverture depuis l’icône installée, le contrôle PWA et l’identification continuent normalement.
- Cache Service Worker et version du script de contrôle passés en V269 pour éviter qu’une ancienne version reste affichée.
