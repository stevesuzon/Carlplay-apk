V266 — FICHES BOIS / VARIÉTÉS

- Chaque fiche affiche la catégorie du bois : PRIVÉ ou NON PRIVÉ.
- Chaque fiche affiche la/les variété(s) de champignons signalées.
- Plusieurs variétés peuvent être enregistrées sur le même bois.
- Les fiches à plusieurs variétés sont rangées dans « Plusieurs champignons ».
- Chaque fiche affiche la distance en km depuis le point GPS « Retourner sur la place ».
- En mode « Sur mon trajet », la fiche affiche aussi le détour depuis le marché (maximum 15 km).
- Le parcours GPS + photo + contrôle champignon + concours de la V265 est conservé.
