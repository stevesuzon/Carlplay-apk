V289 — Concours : demandes de points et confirmations

- Une photo/GPS validée par un utilisateur compte désormais pour SA demande de points, même si la photo principale existante du marché est conservée car elle est meilleure.
- Le GPS propre à chaque contributeur est enregistré pour le calcul de ses points et kilomètres.
- Après validation/refus par l’administrateur, une grande bulle de confirmation s’affiche dans l’application, même si les notifications système ne sont pas activées.
- Le classement continue à être mis à jour par le serveur au moment de la validation.
- Le mode administrateur conserve l’auto-validation des points ajouté en V288.
- Aucun devis, adresse, papier pro, fiche existante ou donnée utilisateur n’est supprimé.
