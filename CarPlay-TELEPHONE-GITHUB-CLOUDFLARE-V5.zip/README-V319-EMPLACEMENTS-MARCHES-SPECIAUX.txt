COUTEAU SUISSE — V319 — NOMBRE D’EMPLACEMENTS / EXPOSANTS

- Marchés de Noël : affiche « Emplacements / exposants ».
- Brocantes / vide-greniers / foires / braderies : affiche « Emplacements / exposants ».
- Marchés voyageurs : affiche aussi le nombre d’emplacements / exposants.
- Les marchés saisonniers / périodiques conservent la capacité dans leur fiche.
- Quand une source publie un nombre exact, une plage (ex. 50 à 100 exposants), ou un nombre de stands/chalets, le serveur le récupère automatiquement.
- Si la source ne publie rien, l’application affiche « À vérifier » au lieu d’inventer un chiffre.
- Les vérifications restent progressives par zone/catégorie comme en V318 afin d’éviter de rechercher tout le Web en même temps.
- Les numéros de téléphone, dates, présence des utilisateurs et confirmation avant effacement d’emplacement sont conservés.
