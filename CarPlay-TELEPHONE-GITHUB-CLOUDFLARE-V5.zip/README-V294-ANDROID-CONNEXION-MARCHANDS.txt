COUTEAU SUISSE V294

CORRECTIONS
1. Compte déjà connecté
- Une identité complète déjà enregistrée n’est plus rebloquée par le formulaire à cause d’une erreur réseau temporaire.
- Un ancien lien ?onboarding=identity ne force plus le formulaire si le compte est déjà complet.
- La synchronisation serveur se poursuit en arrière-plan.

2. Installation Android / iPhone
- Même parcours : vidéo -> INSTALLER L’APPLICATION -> Nom/Prénom/E-mail -> validation -> site.
- La progression vidéo est mémorisée pendant la lecture.
- Sur Android, un retour de plein écran ou une reprise de page ne remet plus la vidéo à zéro.
- La vidéo est validée à 90 % ou à l’événement de fin.
- Aucune navigation automatique après la vidéo : l’utilisateur appuie lui-même sur INSTALLER L’APPLICATION.

3. Bouton administrateur des marchands
- Si le compteur métier d’un marché est > 0, le bouton MARCHANDS INSCRITS apparaît en mode administrateur.
- Les inscriptions récentes affichent Nom + Prénom + Métier.
- Pour les anciennes inscriptions créées avant l’enregistrement d’identité, le bouton reste visible et indique qu’une ancienne inscription est détectée même si le nom historique n’existe pas encore.
- Dès que la personne utilise de nouveau Couteau Suisse pour un marché, son identité est enregistrée pour les prochaines listes.

CACHE
- Mise à jour ciblée des modules Installation et Marchés uniquement.
- Concours V293 et autres données conservés.
