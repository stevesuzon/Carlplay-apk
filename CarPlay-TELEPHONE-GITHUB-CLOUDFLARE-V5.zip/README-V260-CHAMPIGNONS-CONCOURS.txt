V260 — CHAMPIGNONS 1 AN + CONCOURS

- Abonnement Champignons : 50 € pour 1 an (365 jours).
- Les anciens codes gardent la durée enregistrée lors de leur création.
- Une fiche Champignons créée par une personne inscrite au concours arrive dans Admin > Demandes à valider.
- La demande affiche nom/prénom, bois, département, champignon, commentaire, statut privé/public et photo.
- Validation : +50 points de base, avec le multiplicateur de bonus concours actif s’il y en a un.
- Refus : 0 point.
- Une demande non traitée disparaît après 24 h.
- L’utilisateur reçoit une notification de validation/refus dans le concours.
- L’accès Champignons reste automatiquement ouvert pendant la période d’essai principale de Couteau Suisse.
- Toutes les corrections V256, V257, V258 et V259 sont conservées.
