(function(){
  var path=location.pathname.replace(/\/+$/,'')||'/';
  function homeExtras(){
    var grid=document.querySelector('.grid');if(!grid||document.getElementById('homeWorkLinks'))return;
    var links=document.createElement('div');links.id='homeWorkLinks';links.className='homeWorkLinks';
    links.innerHTML='<a class="homeWorkBtn place" href="/ou-trouver-place.html"><span class="homeWorkIcon">📍</span><span>OÙ TROUVER UNE PLACE</span></a><a class="homeWorkBtn docs" href="/documents-travail.html"><span class="homeWorkIcon">📄</span><span>DOCUMENTS DE TRAVAIL</span></a>';
    grid.insertAdjacentElement('beforebegin',links);
    var article=document.createElement('button');article.id='homeArticleBtn';article.type='button';article.innerHTML='<span>🧰</span>ARTICLE<br>DE TRAVAIL';
    var modal=document.createElement('div');modal.id='homeArticleModal';modal.innerHTML='<div class="panel"><h2>🧰 Article de travail</h2><p>Ici, je rajouterai tout ce qui concerne le travail : carnet de factures, cartes de visite, modification des papiers de travail, décennale, etc.</p><button type="button">FERMER</button></div>';
    article.onclick=function(){modal.classList.add('open')};modal.onclick=function(e){if(e.target===modal||e.target.tagName==='BUTTON')modal.classList.remove('open')};document.body.appendChild(article);document.body.appendChild(modal);
  }
  function belgiqueLock(){
    if(!/documents-travail\.html$/i.test(path))return;var card=document.getElementById('papierBelgiqueCard');if(!card)return;
    var oldLock=document.getElementById('belgiqueLock'),protectedBox=document.getElementById('belgiqueProtected');if(oldLock)oldLock.style.display='none';if(protectedBox)protectedBox.style.display='none';
    var box=document.createElement('div');box.className='belgiqueContactLock';box.innerHTML='<strong>🔒 PAPIER BELGIQUE BLOQUÉ</strong><p>Contactez Steve Suzon sur Snapchat pour l’ouverture des papiers.</p>';card.appendChild(box);
    card.onclick=function(){box.animate([{transform:'scale(1)'},{transform:'scale(1.03)'},{transform:'scale(1)'}],{duration:380})};
  }
  function syncMarketsAutomatically(){
    if(path!=='/'&&path!=='/index.html')return;
    var menu=document.getElementById('updateMenu'),row=menu&&menu.closest('.settingRow');if(row)row.remove();
    if(!navigator.onLine)return;
    var stamp=Date.now();
    fetch('/api/markets?automatic_update='+stamp,{cache:'no-store'}).then(function(r){if(!r.ok)throw new Error('sync');return r.json()}).then(function(j){
      localStorage.setItem('server_markets',JSON.stringify(j.markets||[]));
      localStorage.setItem('markets_last_update',new Date().toISOString());
    }).catch(function(){});
  }
  if(path==='/'||path==='/index.html'){homeExtras();syncMarketsAutomatically()}belgiqueLock();
})();
