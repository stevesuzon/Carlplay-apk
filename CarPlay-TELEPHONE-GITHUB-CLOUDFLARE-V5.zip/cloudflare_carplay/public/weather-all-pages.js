(function () {
  if (document.getElementById("weatherBubble")) return;

  var style = document.createElement("style");
  style.textContent = "#weatherBubble{position:fixed;z-index:2147483000;top:max(4px,env(safe-area-inset-top));left:50%;right:auto;transform:translateX(-50%);box-sizing:border-box;width:auto;max-width:calc(100vw - 20px);min-width:280px;padding:7px 13px;border-radius:18px;border:2px solid #f39b19;background:rgba(5,10,18,.96);color:#fff;text-align:center;font:900 15px Arial;box-shadow:0 5px 14px #0008;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}body:not(.homePage){padding-top:58px!important}@media(max-width:720px){#weatherBubble{top:max(3px,env(safe-area-inset-top));max-width:calc(100vw - 16px);min-width:0;padding:6px 10px;font-size:12px;line-height:1.15}}";
  document.head.appendChild(style);

  var bubble = document.createElement("div");
  bubble.id = "weatherBubble";
  bubble.textContent = localStorage.getItem("last_weather_text") || "🌤️ MÉTÉO — EN ATTENTE INTERNET/GPS";
  document.body.appendChild(bubble);

  function message(percent, code) {
    percent = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
    var icon = code >= 51 && code <= 99 ? "🌧️" : code <= 1 ? "☀️" : "⛅";
    var text = percent === 0 ? "TRÈS BON JOUR POUR TRAVAILLER" : percent < 60 ? "TU PEUX ENCORE ALLER TRAVAILLER" : percent < 80 ? "T’ES VAILLANT" : "RESTE CHEZ TOI, C’EST MIEUX";
    return icon + " " + percent + " % — " + text;
  }

  function refresh() {
    if (!navigator.onLine || !navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(function (position) {
      var url = "https://api.open-meteo.com/v1/forecast?latitude=" + position.coords.latitude + "&longitude=" + position.coords.longitude + "&current=weather_code&hourly=precipitation_probability&forecast_days=1&timezone=auto";
      fetch(url).then(function (response) { return response.json(); }).then(function (data) {
        var percent = 0;
        var code = data.current && data.current.weather_code || 0;
        if (data.hourly && data.hourly.precipitation_probability) {
          var values = data.hourly.precipitation_probability;
          var times = data.hourly.time || [];
          var now = Date.now();
          var closest = Infinity;
          for (var i = 0; i < times.length; i++) {
            var distance = Math.abs(new Date(times[i]).getTime() - now);
            if (distance < closest) { closest = distance; percent = values[i]; }
          }
        }
        var value = message(percent, code);
        bubble.textContent = value;
        localStorage.setItem("last_weather_text", value);
      }).catch(function () {});
    }, function () {}, { enableHighAccuracy: false, timeout: 8000, maximumAge: 600000 });
  }

  refresh();
  setInterval(refresh, 900000);
  addEventListener("online", refresh);
})();
