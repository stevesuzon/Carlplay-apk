(function () {
  if (document.getElementById("weatherBubble")) return;

  var style = document.createElement("style");
  style.textContent = "#weatherBubble{position:fixed;z-index:2147483000;top:max(4px,env(safe-area-inset-top));left:50%;right:auto;transform:translateX(-50%);box-sizing:border-box;width:auto;max-width:calc(100vw - 20px);min-width:280px;padding:7px 13px;border-radius:18px;border:2px solid #f39b19;background:rgba(5,10,18,.96);color:#fff;text-align:center;font:900 15px/1.15 Arial;box-shadow:0 5px 14px #0008;overflow:hidden;transition:opacity .18s ease,transform .18s ease}#weatherBubble .weatherMain{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#weatherBubble .weatherDay{margin-top:3px;font-size:12px;color:#fff}body:not(.homePage){padding-top:62px!important}body.weatherScrolled #weatherBubble{opacity:0!important;pointer-events:none!important;transform:translate(-50%,-90px)!important}@media(max-width:720px){#weatherBubble{top:max(3px,env(safe-area-inset-top));max-width:calc(100vw - 18px);min-width:0;width:auto;padding:6px 10px;font-size:12px}#weatherBubble .weatherDay{font-size:10px}}";
  document.head.appendChild(style);

  var bubble = document.createElement("div");
  bubble.id = "weatherBubble";
  bubble.dataset.weather = localStorage.getItem("last_weather_text") || "🌤️ MÉTÉO — EN ATTENTE INTERNET/GPS";
  document.body.appendChild(bubble);

  function render() {
    var n = new Date();
    var jour = n.toLocaleDateString("fr-FR", {weekday:"long"}).toUpperCase();
    var court = String(n.getDate()).padStart(2,"0") + "/" + String(n.getMonth()+1).padStart(2,"0") + "/" + String(n.getFullYear()).slice(-2);
    bubble.innerHTML = '<div class="weatherMain">' + bubble.dataset.weather + '</div><div class="weatherDay">' + jour + ' / ' + court + '</div>';
  }

  function message(percent, code) {
    percent = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
    var icon = code >= 51 && code <= 99 ? "🌧️" : code <= 1 ? "☀️" : "⛅";
    var text = percent === 0 ? "TRÈS BON JOUR POUR TRAVAILLER" : percent < 60 ? "TU PEUX ENCORE ALLER TRAVAILLER" : percent < 80 ? "T’ES VAILLANT" : "RESTE CHEZ TOI, C’EST MIEUX";
    return icon + " " + percent + " % — " + text;
  }

  function refresh() {
    if (!navigator.onLine || !navigator.geolocation) { render(); return; }
    navigator.geolocation.getCurrentPosition(function (position) {
      var url = "https://api.open-meteo.com/v1/forecast?latitude=" + position.coords.latitude + "&longitude=" + position.coords.longitude + "&current=weather_code&hourly=precipitation_probability&forecast_days=1&timezone=auto";
      fetch(url).then(function (response) { return response.json(); }).then(function (data) {
        var percent = 0;
        var code = data.current && data.current.weather_code || 0;
        if (data.hourly && data.hourly.precipitation_probability) {
          var values = data.hourly.precipitation_probability;
          var times = data.hourly.time || [];
          var now = Date.now();
          var closest = Infinity;
          for (var i = 0; i < times.length; i++) {
            var distance = Math.abs(new Date(times[i]).getTime() - now);
            if (distance < closest) { closest = distance; percent = values[i]; }
          }
        }
        var value = message(percent, code);
        bubble.dataset.weather = value;
        localStorage.setItem("last_weather_text", value);
        render();
      }).catch(function () { render(); });
    }, function () { render(); }, { enableHighAccuracy: false, timeout: 8000, maximumAge: 600000 });
  }

  function scrollState(){ document.body.classList.toggle('weatherScrolled',(window.scrollY||0)>45); }
  addEventListener('scroll',scrollState,{passive:true});
  scrollState();
  render();
  refresh();
  setInterval(render,30000);
  setInterval(refresh,900000);
  addEventListener("online", refresh);
})();
