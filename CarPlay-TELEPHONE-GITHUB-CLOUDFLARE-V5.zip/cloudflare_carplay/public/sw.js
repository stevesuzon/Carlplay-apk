const CACHE="carplay-v12-home-logos";
const CORE=["/index.html","/mobile-overrides.css?v=21","/weather-all-pages.js?v=21","/subscription-web.js?v=21","/home-work.css?v=21","/home-work.js?v=21","/ou-trouver-place.html","/documents-travail.html","/master-front.png","/tabbert.png","/chineur.webp"];
self.addEventListener("install",e=>{self.skipWaiting();
e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)))});
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",e=>{if(e.request.method!=="GET"||new URL(e.request.url).pathname.startsWith("/api/"))return;
e.respondWith(fetch(e.request,{cache:"no-store"}).then(r=>{let c=r.clone();
caches.open(CACHE).then(x=>x.put(e.request,c));
return r}).catch(()=>caches.match(e.request)))});
