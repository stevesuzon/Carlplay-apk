const CACHE="carplay-v27-v5-retour-departements-compteurs-zero";
const CORE=["/index.html","/mobile-overrides.css?v=34","/weather-all-pages.js?v=34","/subscription-web.js?v=34","/home-work.css?v=34","/home-work.js?v=34","/markets-final.css","/markets-final-picker.css","/choix-marches-final.html","/ou-trouver-place.html","/documents-travail.html","/master-front-transparent.png","/tabbert.png","/chineur.webp"];
self.addEventListener("install",e=>{self.skipWaiting();
e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)))});
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",e=>{if(e.request.method!=="GET"||new URL(e.request.url).pathname.startsWith("/api/"))return;
e.respondWith(fetch(e.request,{cache:"no-store"}).then(r=>{let c=r.clone();
caches.open(CACHE).then(x=>x.put(e.request,c));
return r}).catch(()=>caches.match(e.request)))});
