const CACHE="carplay-v42-alertes-papiers";
const CORE=["/index.html","/manifest.webmanifest","/carplay-noir-rouge-180.png","/carplay-noir-rouge-192.png","/carplay-noir-rouge-512.png","/mobile-overrides.css?v=35","/weather-all-pages.js?v=35","/subscription-web.js?v=35","/home-work.css?v=35","/home-work.js?v=35","/markets-final.css","/markets-final-picker.css","/choix-marches-final.html","/ou-trouver-place.html","/documents-travail.html","/master-front-transparent.png","/tabbert.png","/chineur.webp"];
self.addEventListener("install",e=>{self.skipWaiting();
e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)))});
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",e=>{if(e.request.method!=="GET"||new URL(e.request.url).pathname.startsWith("/api/"))return;
e.respondWith(fetch(e.request,{cache:"no-store"}).then(r=>{let c=r.clone();
caches.open(CACHE).then(x=>x.put(e.request,c));
return r}).catch(()=>caches.match(e.request)))});
