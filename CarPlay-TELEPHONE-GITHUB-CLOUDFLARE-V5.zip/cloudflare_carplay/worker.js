const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, POST, OPTIONS",
  "access-control-allow-headers": "content-type, authorization"
};
const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { ...cors, "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});

async function hashCode(code, pepper) {
  const bytes = new TextEncoder().encode(`${pepper}:${code}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, "0")).join("");
}

async function body(request) {
  try { return await request.json(); } catch { return {}; }
}

function validCode(value) { return /^\d{6}$/.test(String(value || "")); }
function validDevice(value) { return /^[a-zA-Z0-9-]{16,80}$/.test(String(value || "")); }

async function activate(request, env) {
  const data = await body(request);
  const code = String(data.code || "").replace(/\D/g, "");
  const deviceId = String(data.deviceId || "");
  const type = data.deviceType === "autoradio" ? "autoradio" : "phone";
  if (!validCode(code) || !validDevice(deviceId)) return json({ ok: false, error: "DONNEES_INVALIDES" }, 400);
  const codeHash = await hashCode(code, env.CODE_PEPPER);
  const row = await env.DB.prepare("SELECT * FROM subscriptions WHERE code_hash = ? AND active = 1").bind(codeHash).first();
  if (!row) return json({ ok: false, error: "CODE_INCORRECT" }, 403);
  if (!row.lifetime && (!row.expires_at || Date.parse(row.expires_at) <= Date.now())) return json({ ok: false, error: "ABONNEMENT_EXPIRE" }, 403);
  const column = type === "autoradio" ? "autoradio_device" : "phone_device";
  const registered = row[column];
  if (registered && registered !== deviceId) return json({ ok: false, error: type === "autoradio" ? "AUTORADIO_DEJA_UTILISE" : "TELEPHONE_DEJA_UTILISE" }, 409);
  if (!registered) await env.DB.prepare(`UPDATE subscriptions SET ${column} = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).bind(deviceId, row.id).run();
  return json({ ok: true, lifetime: !!row.lifetime, expiresAt: row.expires_at || null, deviceType: type });
}

async function createSubscription(request, env) {
  if (!env.ADMIN_SECRET || request.headers.get("authorization") !== `Bearer ${env.ADMIN_SECRET}`) return json({ ok: false }, 401);
  const data = await body(request);
  const code = String(data.code || "").replace(/\D/g, "");
  if (!validCode(code)) return json({ ok: false, error: "CODE_6_CHIFFRES_REQUIS" }, 400);
  const lifetime = data.lifetime === true;
  const days = Math.max(1, Math.min(3650, Number(data.days) || 365));
  const expires = lifetime ? null : new Date(Date.now() + days * 86400000).toISOString();
  const codeHash = await hashCode(code, env.CODE_PEPPER);
  try {
    await env.DB.prepare("INSERT INTO subscriptions(code_hash, expires_at, lifetime) VALUES (?, ?, ?)").bind(codeHash, expires, lifetime ? 1 : 0).run();
    return json({ ok: true, code, lifetime, expiresAt: expires });
  } catch { return json({ ok: false, error: "CODE_DEJA_UTILISE" }, 409); }
}

class InjectAppFiles {
  element(element) {
    element.append('<link rel="manifest" href="/manifest.webmanifest"><link rel="stylesheet" href="/mobile-overrides.css?v=5"><link rel="stylesheet" href="/subscription-locks.css?v=5"><script src="/subscription-web.js?v=5" defer></script>', { html: true });
  }
}

class FixAndroidLinks {
  element(element) {
    const href = element.getAttribute("href") || "";
    const prefix = "file:///android_asset/";
    if (href.startsWith(prefix)) element.setAttribute("href", "/" + href.slice(prefix.length));
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (url.pathname === "/api/activate" && request.method === "POST") return activate(request, env);
    if (url.pathname === "/api/admin/subscriptions" && request.method === "POST") return createSubscription(request, env);
    const response = await env.ASSETS.fetch(request);
    const type = response.headers.get("content-type") || "";
    if (type.includes("text/html") && url.pathname !== "/admin.html" && url.pathname !== "/admin") {
      return new HTMLRewriter().on("head", new InjectAppFiles()).on("a", new FixAndroidLinks()).transform(response);
    }
    return response;
  }
};
