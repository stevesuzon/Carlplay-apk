V291 — ESSAI + BANNIS
- Les utilisateurs en période d’essai de 7 jours voient en permanence en haut à gauche de l’écran d’accueil un bandeau avec le nombre de jours restants.
- Le bandeau disparaît dès qu’un abonnement payant/à vie est actif ou que l’essai est terminé.
- Les utilisateurs bannis voient un écran central avec le message : « Veuillez enregistrer votre vrai prénom et votre vraie adresse e-mail dans la section Réglages de Couteau Suisse. »
- Un rappel indique qu’il faut renseigner vrai nom, vrai prénom et vraie adresse e-mail dans Réglages pour être débanni.
- Le texte « POUR ÊTRE DÉBANNI » est affiché en gros en jaune.
- La demande de réactivation existante reste disponible.
