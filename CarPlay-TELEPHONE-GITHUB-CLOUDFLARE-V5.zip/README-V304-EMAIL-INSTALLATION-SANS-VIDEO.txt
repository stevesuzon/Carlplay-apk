COUTEAU SUISSE — V304 — CONFIRMATION E-MAIL + INSTALLATION SANS VIDÉO

1. INSCRIPTION / CONFIRMATION E-MAIL
- Nom + prénom + adresse e-mail obligatoires.
- Le bouton « CONFIRMER MON ADRESSE E-MAIL » reste gris tant que les 3 champs ne sont pas valides.
- Il devient bleu lorsque le formulaire est complet.
- Un e-mail Brevo est envoyé avec un bouton « CONFIRMER MON ADRESSE E-MAIL ».
- Le lien est valable 24 h.
- Après clic dans l’e-mail, l’adresse est validée et l’utilisateur est redirigé automatiquement vers Couteau Suisse.
- Tant que l’e-mail n’est pas confirmé, la personne n’est pas comptée comme utilisateur valide et n’est pas ajoutée au concours.
- Au passage en V304, les anciens participants non encore confirmés sont masqués du classement jusqu’à confirmation de leur e-mail.
- Le système conserve la logique de récupération d’un abonnement déjà existant.

2. PREMIÈRE OUVERTURE / INSTALLATION
- Suppression du tutoriel vidéo de départ et du fichier MP4 associé.
- Plus de lecture automatique ni de rafraîchissement lié à la vidéo.
- Premier bouton : « INSTALLATION iPHONE / ANDROID ».
- Au clic, affichage d’une explication courte : Safari > Partager > Sur l’écran d’accueil pour iPhone/iPad ; Chrome > menu ⋮ > Installer/Ajouter à l’écran d’accueil pour Android.
- Après consultation, le bouton « ALLER SUR LE SITE » est débloqué.
- Avant consultation, il indique « CLIQUEZ D’ABORD SUR INSTALLATION iPHONE / ANDROID » et reste désactivé.
- « ALLER SUR LE SITE » ouvre ensuite le formulaire d’identité et de confirmation e-mail.

3. CACHE
- Invalidation ciblée du module installation uniquement (cache install V304).
- Les autres caches/modules V302/V303 restent inchangés autant que possible.
