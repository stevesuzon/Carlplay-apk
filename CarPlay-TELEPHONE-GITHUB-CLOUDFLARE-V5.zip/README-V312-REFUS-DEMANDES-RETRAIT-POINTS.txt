V312 — REFUS DES DEMANDES ET RETRAIT DES POINTS

- Les demandes administrateur restent affichées dans Réglages comme sur la capture : compteur, puis petits carrés regroupés par personne.
- Chaque personne affiche son nom, son adresse e-mail et le nombre de demandes en attente.
- Il faut ouvrir la demande pour voir la fiche, la photo, le marché, le bois/champignon ou le texte du bug avant de confirmer/refuser.
- Si Steve confirme une fiche Marché ou Champignons : les points déjà gagnés avec cette fiche sont conservés et l’utilisateur reçoit « FICHE CONFIRMÉE ».
- Si Steve refuse une fiche Marché ou Champignons : seuls les points gagnés avec CETTE fiche sont retirés automatiquement du classement.
- L’utilisateur reçoit une notification détaillée indiquant la fiche concernée, « DEMANDE REFUSÉE », que la fiche a été mal renseignée / non confirmée, le nombre de points retirés et son nouveau total.
- Pour un bug / problème / idée refusé : aucun point ni bonus n’est conservé pour cette demande et l’utilisateur reçoit aussi une notification de refus.
- Sous les demandes, les dernières fiches confirmées affichent les gains sous la forme « Nom Prénom a gagné 17 pt ».
- Cache Administration / Abonnement passé en V312.
