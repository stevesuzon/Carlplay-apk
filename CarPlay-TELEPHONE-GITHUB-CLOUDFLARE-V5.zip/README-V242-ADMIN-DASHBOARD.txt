COUTEAU SUISSE V242 — ADMINISTRATION

- Historique des installations écran d’accueil conservé (plus de suppression automatique à 60 jours).
- Liste des personnes : nom, prénom, e-mail et date quand disponibles.
- Récupération des anciennes personnes depuis installations, identités et comptes abonnement existants.
- Section MESSAGES REÇUS avec compteur et cartes détaillées.
- Bannissement manuel depuis la liste des installations.
- Section PERSONNES BANNIES avec débannissement.
- Le blocage est contrôlé côté serveur et dans toute l’application.
- Seul Steve Suzon / appli.suzon@gmail.com peut ouvrir l’administration via confirmation e-mail.
- V240 champignons + fonctions précédentes conservées.
