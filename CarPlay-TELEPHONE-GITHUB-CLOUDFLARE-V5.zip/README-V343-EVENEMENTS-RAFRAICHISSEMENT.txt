V343
- Marchés hebdomadaires : aucun changement et aucun scan automatique par ce module.
- Brocantes / braderies / foires : contrôle automatique tous les 90 jours par zone.
- Marchés de voyageurs : contrôle automatique tous les 60 jours par zone.
- Une seule zone traitée par heure pour préserver le quota CPU Cloudflare.
- Les nouvelles fiches trouvées sont ajoutées / mises à jour dans D1 via upsert, avec coordonnées, téléphone et modalités d inscription quand la source les publie.
- Formulaire : bouton final e-mail clairement nommé. L utilisateur garde le dernier appui Envoyer dans son application Mail.
