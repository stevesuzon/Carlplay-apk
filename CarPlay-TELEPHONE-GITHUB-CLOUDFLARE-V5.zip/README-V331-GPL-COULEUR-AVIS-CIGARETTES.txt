V331 — STATIONS GPL : COULEUR DU MOT GPL + AVIS

- La fiche station ne devient plus verte.
- Seul le mot GPL change de couleur.
- GPL officiel accessible 24/24 : mot GPL vert.
- Pour les autres GPL : bouton GPL À VÉRIFIER et rond orange.
- Vérification : Arrangeant / Gentil / Pas la peine d’y aller.
- Arrangeant : mot GPL reste neutre.
- Gentil : mot GPL devient vert.
- Pas la peine d’y aller : mot GPL devient rouge.
- Après une vérification complète, le rond orange devient vert.
- Cigarettes : Oui / Non fait partie de la vérification.
- L’étoile ☆ / ★ reste uniquement le bouton Favori.
- Les favoris existants V330 sont conservés.
- Les vérifications sont enregistrées en D1 et partagées.
