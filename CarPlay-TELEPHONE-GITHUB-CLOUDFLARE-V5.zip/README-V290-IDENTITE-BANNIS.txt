Couteau Suisse V290 — identité des utilisateurs bannis

Quand un utilisateur banni renseigne son vrai nom, son vrai prénom et son adresse e-mail dans Réglages, l’identité est enregistrée côté serveur. Si son appareil ou son e-mail correspond à une fiche de bannissement, la fiche market_user_sanctions est synchronisée immédiatement.

Dans Administration > BANNIR / DÉBANNIR, la fiche affiche l’identité renseignée et un indicateur « IDENTITÉ RENSEIGNÉE » ou « IDENTITÉ À RENSEIGNER ».
