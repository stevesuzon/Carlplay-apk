V264 — Coin Détente & Champignons

- Un seul bouton : « AJOUTER UN BOIS ».
- Le bouton séparé « Reconnaître un champignon » est supprimé.
- Dans « Ajouter un bois » : GPS -> photo du champignon -> reconnaissance automatique -> nom du bois / privé / espèce / commentaire -> enregistrement.
- La fiche Champignons reste liée au concours (+50 points après validation admin).
- « Voir les coins » et le calcul avec maximum 15 km de détour sont conservés.
- Abonnement Champignons : 50 € pour 1 an.
