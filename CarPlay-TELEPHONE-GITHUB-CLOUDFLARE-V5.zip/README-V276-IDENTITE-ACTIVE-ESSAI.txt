VERSION V276 — PREMIÈRE IDENTIFICATION ET ESSAI GRATUIT

- À la première ouverture, le nom, le prénom et l'adresse e-mail sont enregistrés.
- Ces trois informations apparaissent automatiquement dans Réglages > Abonnement.
- Le nouvel utilisateur obtient immédiatement son essai gratuit avec la vraie date de fin du serveur.
- La fiche Abonnement affiche ACTIF et le nombre exact de jours restants après un rafraîchissement automatique.
- Une réinstallation ou un changement de téléphone ne crée jamais un second essai gratuit.
- Un abonnement déjà existant conserve sa date de fin et doit être récupéré avec le bouton prévu.
- Les pouvoirs administrateur ajoutés en V275 sont conservés.
