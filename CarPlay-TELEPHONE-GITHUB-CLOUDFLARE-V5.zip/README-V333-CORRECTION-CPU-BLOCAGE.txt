V333 — Correction blocages Cloudflare CPU

- Conservation du fonctionnement des pages comme dans la V331 (run_worker_first reste actif pour ne pas casser les injections existantes).
- Désactivation par défaut du scraping automatique lourd des marchés. Pour le réactiver volontairement : MARKET_AUTO_REFRESH=1.
- /api/market-verifications/batch : passage de centaines/milliers de requêtes D1 à 5 requêtes groupées maximum.
- /api/market-attendance/batch : une seule requête GROUP BY au lieu d'une requête par marché.
- market-auto-update : ne s'exécute plus sur toutes les pages, uniquement sur les pages de marchés, et rafraîchissement espacé.
- Accueil : évite le double rafraîchissement immédiat des marchés et réduit les appels présence inutiles.
- Observabilité Workers activée et conservée dans wrangler.jsonc.
- Aucune donnée D1, abonnement, photo, fiche ou réglage utilisateur n'est supprimé.
