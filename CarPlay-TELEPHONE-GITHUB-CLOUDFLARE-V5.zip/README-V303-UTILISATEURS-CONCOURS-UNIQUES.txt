COUTEAU SUISSE — V303 — UTILISATEURS RÉELS + CONCOURS AUTOMATIQUE

BUT
- Corriger l’écart entre le compteur utilisateurs et le nombre de participants au concours.
- Ne plus compter les téléphones/réinstallations comme des personnes différentes.
- Ajouter automatiquement au concours tout vrai compte possédant nom + prénom + e-mail valide.
- Laisser le compte administrateur hors concours et sans attribution de points.

MODIFICATIONS
1. Compteur utilisateurs
- Un utilisateur est maintenant identifié par son e-mail unique.
- Nom et prénom doivent être présents.
- Les anciennes installations/appareils seuls ne sont plus comptés.
- Une réinstallation du même compte ne fait plus monter le compteur.

2. Concours
- À l’enregistrement de l’identité dans l’application, le compte est automatiquement rattaché au concours.
- Un rattrapage V303 ajoute aussi les comptes valides déjà existants.
- La même adresse e-mail ne crée qu’un seul participant, même après changement de téléphone.
- Les nouveaux comptes sont synchronisés immédiatement ; le rattrapage global des anciens comptes est limité à une fois par 24 h pour économiser D1.

3. Administrateur
- appli.suzon@gmail.com reste compté comme compte utilisateur valide.
- Ce compte est marqué hors concours.
- Il est absent du classement et des gagnants.
- Un garde-fou central bloque toute nouvelle attribution de points au compte administrateur.

4. Cloudflare D1
- Les optimisations de la V302 sont conservées.
- Le compteur utilise des requêtes SQL agrégées au lieu de relire toutes les installations dans JavaScript.
- Deux index ciblés ont été ajoutés pour l’e-mail des participants et le classement éligible.

IMPORTANT APRÈS DÉPLOIEMENT
- Le premier accès au concours ou à l’administration du concours déclenche automatiquement le rattrapage V303 des anciens comptes valides.
- Le nombre « utilisateurs » peut donc diminuer par rapport à 114 si une partie des 114 correspondait seulement à d’anciens téléphones/installations sans nom + prénom + e-mail valide.
- Aucune fiche métier, photo, abonnement, marché ou donnée utilisateur existante n’est supprimée.
