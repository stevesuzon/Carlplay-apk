V326
- Bouton STATIONS 15 KM placé après le compteur total utilisateurs.
- Bouton discret, mais avec zone tactile agrandie et contour ambre visible.
- Ordre : connectés -> utilisateurs -> stations.
