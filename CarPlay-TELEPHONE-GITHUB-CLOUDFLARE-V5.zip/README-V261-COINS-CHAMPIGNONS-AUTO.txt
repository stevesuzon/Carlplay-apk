V261 — COINS CHAMPIGNONS VISIBLES AUTOMATIQUEMENT

- « Voir les coins » charge immédiatement les coins à moins de 100 km du point « Retourner sur la place ».
- Les résultats sont triés du plus proche au plus loin.
- « Sur mon trajet » reste disponible avec la règle max 10 km de détour.
- Si aucun coin ne respecte les 10 km de détour, l’application bascule automatiquement sur la liste à moins de 100 km au lieu de laisser un écran vide.
- Toutes les corrections de la V260 sont conservées.
