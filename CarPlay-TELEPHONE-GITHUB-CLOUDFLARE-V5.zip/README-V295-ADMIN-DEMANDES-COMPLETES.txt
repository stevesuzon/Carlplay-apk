COUTEAU SUISSE — V295 — DEMANDES ADMINISTRATEUR

Base : V294 Connexion Android / Marchands.

Modifications :
- Dans Réglages administrateur, « Demandes à valider » est placé en premier, tout en haut.
- Le compteur additionne toutes les demandes en attente : modifications de marchés (France, Belgique et Voyageurs via le circuit commun), fiches concours, champignons, bugs/problèmes/idées, changements de commune, alertes concours et messages de l’application.
- Le compteur se rafraîchit automatiquement toutes les 5 secondes dans Réglages.
- Dans Administration, les demandes sont regroupées par personne. Chaque groupe affiche nom/prénom, e-mail et nombre de messages.
- Un appui sur la personne affiche toutes ses demandes.
- Un appui sur une demande ouvre la fiche en grand écran avant décision.
- OUI / VALIDER sur une fiche concours attribue réellement les points côté serveur et actualise le classement. Les fiches Champignons et bugs/problèmes utilisent aussi le calcul de points serveur déjà prévu.
- Les demandes sans gain de points (modification de marché, commune, simple message, alerte) sont validées sans inventer de points.
- À la création d’une nouvelle demande, l’administrateur reçoit l’alerte push s’il a activé les notifications ; quand l’application est ouverte, le compteur et la bulle administrateur détectent également toutes les catégories de demandes.
- Cache ciblé : seuls le module Administration et les fichiers directement modifiés changent de version. Les données existantes ne sont pas supprimées.
