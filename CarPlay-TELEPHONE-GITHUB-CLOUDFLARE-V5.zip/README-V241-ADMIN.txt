V241 — correction accès Administration
- Section Réglages > Administration visible uniquement pour le compte appli.suzon@gmail.com (Steve Suzon).
- La présence admin serveur ne peut plus masquer la section sur le téléphone de Steve.
- Confirmation admin toujours obligatoire par code e-mail Brevo.
- Cache/service worker versionné pour forcer la mise à jour.
- Toutes les fonctions V240 conservées, dont Coin Détente & Champignons.
