COUTEAU SUISSE V242

- Administration Steve Suzon par confirmation e-mail.
- Historique « Installé sur l’écran d’accueil » conservé et reconstruit depuis les données existantes quand possible.
- Cartes avec nom, prénom, e-mail et date.
- Messages reçus avec compteur et détail de la personne.
- Demandes à valider placées juste sous les messages.
- Personnes bannies juste en dessous, avec bannir/débannir.
- Coin Champignons : correction Workers AI.
- Le modèle Llama 3.2 Vision reçoit bien la photo et, au premier échec, l’application accepte automatiquement la licence Meta puis réessaie.
- Liaison requise dans Cloudflare : Workers AI = AI.
