V258 — CHAMPIGNONS DÉBLOQUÉ PENDANT L’ESSAI

- Conserve toutes les corrections V256 et V257.
- Correction du vrai blocage : pendant la période gratuite générale Couteau Suisse, le Coin Détente & Champignons est débloqué pour tous les comptes principaux actifs, y compris ceux qui avaient déjà un abonnement principal.
- Après la période générale, l’essai personnel de 7 jours est également reconnu.
- Aucun code Champignons n’est demandé tant qu’un essai Couteau Suisse est actif.
- Un abonnement Champignons payant déjà existant n’est ni effacé ni raccourci.
- La page admin Bois et Champignons reste compacte.
- Cache/service worker renouvelé en V258.
