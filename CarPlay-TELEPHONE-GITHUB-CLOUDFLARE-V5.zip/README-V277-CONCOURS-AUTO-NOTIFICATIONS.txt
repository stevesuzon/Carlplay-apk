VERSION V277 — INSCRIPTION AUTOMATIQUE AU CONCOURS ET NOTIFICATIONS

- À la prochaine ouverture, chaque ancien compte possédant un nom, un prénom
  et une adresse e-mail valide est ajouté automatiquement au concours s'il
  manquait à cause de l'ancien bug.
- Aucun doublon n'est créé et les participants déjà présents gardent leurs points.
- Les comptes réparés apparaissent immédiatement dans le classement avec leurs
  points existants ou 0 point s'ils n'en avaient pas encore.
- Une grande confirmation et une notification affichent :
  « Bravo, vous participez au concours ».
- La confirmation n'apparaît qu'une fois par téléphone.
- Les nouveaux messages du concours, bonus, validations et demandes de réponse
  déclenchent de nouveau une notification lorsque les notifications sont activées.
- Les comptes réparés peuvent compléter leur commune sans recréer leur compte.
- Aucun point de déplacement n'est calculé depuis des coordonnées provisoires.
- Les corrections V275 et V276 sont conservées.
