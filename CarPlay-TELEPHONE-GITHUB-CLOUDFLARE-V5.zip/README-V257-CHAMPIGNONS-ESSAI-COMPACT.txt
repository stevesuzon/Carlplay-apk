V257 — COUTEAU SUISSE

Base : V256 conservée.

Corrections :
- Coin Détente & Champignons automatiquement ouvert pendant l’essai principal Couteau Suisse.
- L’identification Nom / Prénom / E-mail crée ou rattache l’essai principal sans redonner un nouvel essai à un ancien compte.
- Pendant l’essai, aucun code Champignons n’est demandé.
- À la fin de l’essai, le code Champignons redevient nécessaire si aucun abonnement Champignons n’est actif.
- L’abonnement Champignons existant reste prioritaire et conserve ses jours restants.
- Administration > Bois et Champignons : cartes réduites et grille compacte pour limiter le défilement.
- Toutes les modifications V256 Concours / Demandes à valider sont conservées.
