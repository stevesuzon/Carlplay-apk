V280 — MISE À JOUR AUTOMATIQUE

- À chaque ouverture ou retour dans l’application, le téléphone vérifie le nouveau service worker.
- Le nouveau service worker s’active immédiatement et recharge une seule fois l’application si nécessaire.
- Les pages, fichiers JavaScript, feuilles de style et données JSON utilisent le réseau en priorité afin d’afficher la dernière version dès la réouverture.
- Les anciens caches techniques Couteau Suisse / CarPlay sont supprimés sélectivement.
- Les clés localStorage, IndexedDB, comptes serveur, abonnements, points, fiches, photos, GPS, horaires et lots ne sont jamais supprimés ni renommés.
- Le cache de préférence des notifications est conservé.
- Après activation d’une nouvelle version, les téléphones ayant autorisé les notifications reçoivent une grande notification « Couteau Suisse mis à jour ».
- Les notifications push acceptent maintenant un titre, un texte et un lien propres à chaque changement de marché.
- sw.js et app-version.json restent servis sans cache par le Worker Cloudflare.

Déploiement : envoyer tout le contenu de cette archive dans le dépôt GitHub relié au Worker carplay-telephone, puis vérifier que le nouveau déploiement Cloudflare est actif à 100 %.
