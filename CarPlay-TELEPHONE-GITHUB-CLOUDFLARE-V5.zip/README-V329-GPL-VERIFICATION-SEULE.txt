V329 — STATIONS : VERIFICATION MANUELLE UNIQUEMENT POUR LE GPL

- Les stations, prix, horaires et automate 24/24 sont affichés depuis la source officielle : pas de bouton de vérification générale.
- Un repère "STATION — DONNÉES OFFICIELLES" remplace la vérification générale.
- La vérification manuelle ne concerne plus que le GPL.
- Pour le GPL : disponible / accessible 24/24 / passage boutique-caisse.
- Une fois les choix GPL enregistrés, le bouton orange devient vert avec une étoile.
- GPL disponible + 24/24 + sans boutique/caisse : fiche mise en évidence en vert "GPL 24/24 SANS BOUTIQUE".
- Compatibilité conservée avec les anciennes vérifications V328 en base D1.
