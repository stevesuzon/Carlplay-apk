V313 — NOTIFICATIONS PUBLIQUES APRÈS CONFIRMATION

- Quand l’administrateur confirme une fiche Marché avec des points, la personne concernée reçoit sa confirmation détaillée.
- Tous les autres participants reçoivent ensuite une notification courte, par exemple :
  « Toni Mordan a gagné 13 pt et est maintenant 3e du classement. »
- Même comportement pour une fiche Champignons confirmée.
- Même comportement pour un bug/problème confirmé lorsqu’il attribue des points.
- La place affichée est recalculée depuis le classement serveur au moment de la confirmation.
- Les refus restent privés : seul l’utilisateur concerné reçoit la notification de refus et de retrait des points.
- Les idées sans attribution directe de points ne déclenchent pas cette notification publique.
