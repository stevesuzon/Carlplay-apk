V273 — Parrainage + compte concours + vérification marché

- Si « J’AI COMPRIS » ou « PLUS TARD » est choisi sur le parrainage, cette fenêtre ne revient plus pour ce lien.
- Après envoi du mail de parrainage, la fenêtre ne revient plus non plus ; la validation continue depuis l’e-mail.
- Un nouveau lien de parrainage différent peut toujours être utilisé.
- Un filleul qui possède déjà un compte/une participation au concours garde le même compte et les mêmes points.
- Après suppression/réinstallation, le même nom + prénom + e-mail permet de rattacher le nouveau téléphone au compte existant et de retrouver le concours.
- Correction de l’écran « Vérifier ce marché » : l’API /api/subscription-profile-v156 existe maintenant.
- Les anciennes pages mises en cache restent compatibles : le serveur sait récupérer nom/e-mail du compte même si l’ancienne page ne les envoyait pas correctement.
- Les réponses API vides ne provoquent plus « Unexpected end of JSON input » dans la demande de modification.
- Une panne de notification push administrateur n’annule plus la demande : la demande est enregistrée quand même.
- Cache/service worker V273.
