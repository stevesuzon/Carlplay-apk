#!/usr/bin/env python3
import datetime as dt
import gzip
import json
import re
import sys
from pathlib import Path

import ijson

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "public"
SOURCE = Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/evenements.json.gz")
OUTPUT = PUBLIC / "markets-france-update-v139.js"
TODAY = dt.date(2026, 9, 7)
MONTHS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"]
DAY_NAMES = {"Monday":"lundi", "Tuesday":"mardi", "Wednesday":"mercredi", "Thursday":"jeudi", "Friday":"vendredi", "Saturday":"samedi", "Sunday":"dimanche"}


def scalar(value):
    if isinstance(value, dict):
        return str(value.get("@value") or value.get("rdfs:label", {}).get("@value") or "")
    return str(value or "")


def items(value):
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def first_dict(value):
    for candidate in items(value):
        if isinstance(candidate, dict):
            return candidate
    return {}


def parse_date(value):
    value = scalar(value)[:10]
    try:
        return dt.date.fromisoformat(value)
    except ValueError:
        return None


def french_date(value):
    return f"{value.day} {MONTHS[value.month-1]} {value.year}"


def type_names(obj):
    return {str(x).split(":")[-1] for x in items(obj.get("@type"))}


def text_blob(obj):
    return " ".join([scalar(obj.get("rdfs:label")), scalar(obj.get("rdfs:comment"))]).lower()


def get_periods(obj):
    return items(obj.get("takesPlaceAt"))


def get_days(obj):
    found = []
    holders = get_periods(obj)
    location = first_dict(obj.get("isLocatedAt"))
    holders += items(location.get("schema:openingHoursSpecification"))
    for holder in holders:
        for day in items(holder.get("appliesOnDay") or holder.get("schema:dayOfWeek")):
            raw = day.get("@id", "") if isinstance(day, dict) else str(day)
            english = raw.split(":")[-1]
            if english in DAY_NAMES and DAY_NAMES[english] not in found:
                found.append(DAY_NAMES[english])
    return found


def get_dates(obj):
    starts = [parse_date(obj.get("schema:startDate"))]
    ends = [parse_date(obj.get("schema:endDate"))]
    for period in get_periods(obj):
        starts.append(parse_date(period.get("startDate") or period.get("schema:startDate")))
        ends.append(parse_date(period.get("endDate") or period.get("schema:endDate")))
    starts = [x for x in starts if x]
    ends = [x for x in ends if x]
    return (min(starts) if starts else None, max(ends) if ends else None)


def get_hours(obj):
    starts, ends = [], []
    holders = get_periods(obj) + items(first_dict(obj.get("isLocatedAt")).get("schema:openingHoursSpecification"))
    for holder in holders:
        opening = scalar(holder.get("startTime") or holder.get("schema:opens"))[:5]
        closing = scalar(holder.get("endTime") or holder.get("schema:closes"))[:5]
        if opening and opening not in starts:
            starts.append(opening)
        if closing and closing not in ends:
            ends.append(closing)
    if starts and ends:
        return f"{starts[0].replace(':','h')}-{ends[0].replace(':','h')}"
    if starts:
        return f"À partir de {starts[0].replace(':','h')} — fermeture à vérifier"
    return "Horaire à vérifier"


def location_data(obj):
    place = first_dict(obj.get("isLocatedAt"))
    address = first_dict(place.get("schema:address"))
    city_node = first_dict(address.get("hasAddressCity"))
    city = scalar(address.get("schema:addressLocality")) or scalar(city_node.get("rdfs:label"))
    postal = scalar(address.get("schema:postalCode"))
    street = scalar(address.get("schema:streetAddress"))
    department = first_dict(city_node.get("isPartOfDepartment")).get("insee")
    department = scalar(department)
    if not department and postal:
        department = postal[:3] if postal.startswith(("971", "972", "973", "974", "976")) else postal[:2]
    geo = first_dict(place.get("schema:geo"))
    try:
        lat = float(scalar(geo.get("schema:latitude")))
        lon = float(scalar(geo.get("schema:longitude")))
    except ValueError:
        lat = lon = None
    address_text = ", ".join(x for x in [street, postal, city] if x) or city
    return department, city, address_text, lat, lon


def calendar_text(obj, start, end, days):
    if start and end and end < TODAY:
        return None
    if start and end:
        duration = (end - start).days
        if duration >= 300 and days:
            return ", ".join(days)
        if start == end:
            return french_date(start)
        return f"{french_date(start)} au {french_date(end)}"
    if days:
        return ", ".join(days)
    return "Date à vérifier"


existing_text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in PUBLIC.glob("market*.js"))
existing_ids = set(re.findall(r"https://data\.datatourisme\.fr/[A-Za-z0-9_-]+/[A-Za-z0-9-]+", existing_text))
seen_composites = set()
new_rows = []
counts = {"marche": 0, "brocante": 0, "noel": 0}

with gzip.open(SOURCE, "rb") as stream:
    for obj in ijson.items(stream, "@graph.item"):
        oid = str(obj.get("@id") or "")
        types = type_names(obj)
        if not ({"Market", "BricABrac", "GarageSale"} & types):
            continue
        if oid in existing_ids:
            continue
        label = scalar(obj.get("rdfs:label")).strip()
        if not label:
            continue
        blob = text_blob(obj)
        if re.search(r"\b(no[eë]l|christmas)\b", blob):
            kind = "noel"
        elif {"BricABrac", "GarageSale"} & types or re.search(r"brocante|vide[- ]grenier|puces", blob):
            kind = "brocante"
        else:
            kind = "marche"
        start, end = get_dates(obj)
        days = get_days(obj)
        calendar = calendar_text(obj, start, end, days)
        if calendar is None:
            continue
        department, city, address, lat, lon = location_data(obj)
        if not city:
            continue
        composite = (kind, re.sub(r"\W+", "", label.lower()), re.sub(r"\W+", "", city.lower()), calendar)
        if composite in seen_composites:
            continue
        seen_composites.add(composite)
        note = "Fiche ajoutée depuis le flux national DATAtourisme actualisé le 7 septembre 2026. Les informations non publiées restent à vérifier."
        row = [department or "À vérifier", kind, label, city, calendar, get_hours(obj), note, "Nombre de places à vérifier", address or city, [oid, "https://www.data.gouv.fr/datasets/donnees-touristiques-de-la-base-datatourisme"], lat, lon, "Tirage au sort à vérifier", "Contacter la mairie, le placier ou l’organisateur officiel"]
        new_rows.append(row)
        counts[kind] += 1

payload = "window.data=Array.isArray(window.data)?window.data:[];window.data.push(..." + json.dumps(new_rows, ensure_ascii=False, separators=(",", ":")) + ");\n"
OUTPUT.write_text(payload, encoding="utf-8")
print(json.dumps({"added": len(new_rows), "counts": counts, "output": str(OUTPUT)}, ensure_ascii=False))
