#!/usr/bin/env python3
import concurrent.futures
import html
import json
import re
import sys
import unicodedata
import urllib.request
import urllib.parse
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EXISTING=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/all-fr-v142.json')
DEPARTMENT_URL='https://www.jours-de-marche.fr/35-ille-et-vilaine/'
OUTPUT=ROOT/'public'/'markets-35-missing-v143.js'
DAYS=['lundi','mardi','mercredi','jeudi','vendredi','samedi','dimanche']

def norm(value):
    value=''.join(c for c in unicodedata.normalize('NFD',html.unescape(str(value or '')).lower()) if unicodedata.category(c)!='Mn')
    return re.sub(r'[^a-z0-9]+',' ',value).strip()

def clean(value):
    return re.sub(r'\s+',' ',html.unescape(re.sub(r'<[^>]+>',' ',str(value or '')))).strip()

def fetch(url):
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 CarPlay market audit'})
    with urllib.request.urlopen(req,timeout=30) as response:return response.read().decode('utf-8','ignore')

department_html=fetch(DEPARTMENT_URL)
city_urls=sorted(set(re.findall(r'https://www\.jours-de-marche\.fr/\d{5}-[a-z0-9-]+/',department_html,re.I)))

def parse_city(url):
    try:page=fetch(url)
    except Exception:return []
    city_match=re.search(r'<li class="breadcrumb-item active">([^<]+)</li>',page,re.I)
    city=clean(city_match.group(1)) if city_match else clean(re.search(r'Les jours de marché à ([^<]+)',page,re.I).group(1))
    postal=re.search(r'/([0-9]{5})-',url).group(1)
    rows=[]
    blocks=re.findall(r'<div id="marche\d+" class="col-12">(.*?)(?=<div id="marche\d+" class="col-12">|<div class="text-center"><h2)',page,re.I|re.S)
    for block in blocks:
        name_match=re.search(r'<h3[^>]*>.*?<b>(.*?)</b>',block,re.I|re.S)
        schedule_match=re.search(r'<b>Ce marché a lieu(.*?)</b>',block,re.I|re.S)
        link_match=re.search(r'<h3[^>]*>\s*<a href="([^"]+)"',block,re.I|re.S)
        if not name_match or not schedule_match:continue
        name=clean(name_match.group(1));schedule=clean(schedule_match.group(1));source=link_match.group(1) if link_match else url
        found_days=[day for day in DAYS if re.search(r'\b'+day+r'\b',norm(schedule))]
        if not found_days:continue
        hours_match=re.search(r'de\s+(\d{1,2})h(?:(\d{2}))?\s+[àa]\s+(\d{1,2})h(?:(\d{2}))?',schedule,re.I)
        hours=(hours_match.group(1)+'h'+(hours_match.group(2) or '')+'-'+hours_match.group(3)+'h'+(hours_match.group(4) or '')) if hours_match else 'Horaire à vérifier'
        address_match=re.search(r'Adresse\s*:\s*(.*?)(?:<br\s*/?>)',block,re.I|re.S)
        address=clean(address_match.group(1)) if address_match else city
        if postal not in address:address=', '.join(x for x in [address,postal,city] if x)
        for day in found_days:rows.append({'name':name,'city':city,'postal':postal,'day':day,'hours':hours,'address':address,'source':source})
    return rows

scraped=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=14) as pool:
    for rows in pool.map(parse_city,city_urls):scraped.extend(rows)

existing=json.loads(EXISTING.read_text())
def same_market(item,row):
    if str(row[0])!='35' or norm(row[3])!=norm(item['city']) or item['day'] not in norm(row[4]):return False
    old_name,old_address=norm(row[2]),norm(row[8])
    new_name,new_address=norm(item['name']),norm(item['address'])
    generic=('marche de '+norm(item['city']))
    return old_name==new_name or (new_name==generic and 'marche' in old_name) or (new_name==generic and new_address and new_address in old_address) or (old_name==generic and old_address and old_address in new_address) or (len(new_address)>8 and (new_address in old_address or old_address in new_address))

missing=[]
for item in scraped:
    if any(same_market(item,row) for row in existing):continue
    if any(norm(x['city'])==norm(item['city']) and x['day']==item['day'] and (norm(x['name'])==norm(item['name']) or norm(x['address'])==norm(item['address'])) for x in missing):continue
    missing.append(item)

def geocode(item):
    query=item['address'] if item['postal'] in item['address'] else f"{item['address']} {item['postal']} {item['city']}"
    url='https://api-adresse.data.gouv.fr/search/?'+urllib.parse.urlencode({'q':query,'postcode':item['postal'],'limit':1})
    try:
        result=json.loads(fetch(url)).get('features',[])
        if result:
            lon,lat=result[0]['geometry']['coordinates']
            return lat,lon
    except Exception:pass
    try:
        fallback='https://api-adresse.data.gouv.fr/search/?'+urllib.parse.urlencode({'q':f"{item['city']} {item['postal']}",'postcode':item['postal'],'limit':1})
        result=json.loads(fetch(fallback)).get('features',[])
        if result:
            lon,lat=result[0]['geometry']['coordinates']
            return lat,lon
    except Exception:pass
    return None,None

# Réutilise un GPS déjà connu à la même adresse/commune, puis complète avec la Base Adresse Nationale.
geocoded={}
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
    for item,coords in zip(missing,pool.map(geocode,missing)):geocoded[id(item)]=coords

out=[]
for item in missing:
    lat,lon=geocoded[id(item)]
    for row in existing:
        if len(row)>11 and str(row[0])=='35' and norm(row[3])==norm(item['city']) and row[10] is not None and row[11] is not None:
            if norm(item['address']) in norm(row[8]) or norm(row[8]) in norm(item['address']):lat,lon=row[10],row[11];break
    note="Fiche complémentaire trouvée lors du contrôle commune par commune du département 35. Source participative : informations à vérifier auprès de la mairie."
    out.append(['35','marche',item['name'],item['city'],item['day'],item['hours'],note,'Nombre de places à vérifier',item['address'],[item['source'],DEPARTMENT_URL],lat,lon,'Tirage au sort à vérifier','Contacter la mairie ou le placier'])

OUTPUT.write_text("window.data=Array.isArray(window.data)?window.data:[];window.data.push(..."+json.dumps(out,ensure_ascii=False,separators=(',',':'))+");\n",encoding='utf-8')
(ROOT/'AUDIT-MARCHES-MANQUANTS-35-V143.json').write_text(json.dumps({'source':DEPARTMENT_URL,'cityPages':len(city_urls),'scrapedRows':len(scraped),'missingAdded':len(out),'withGps':sum(1 for r in out if r[10] is not None and r[11] is not None),'markets':missing},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'cityPages':len(city_urls),'scrapedRows':len(scraped),'missingAdded':len(out),'withGps':sum(1 for r in out if r[10] is not None and r[11] is not None)},ensure_ascii=False))
