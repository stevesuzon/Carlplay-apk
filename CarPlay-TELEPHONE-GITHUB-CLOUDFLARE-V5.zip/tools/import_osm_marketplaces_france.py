#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path

from shapely.geometry import Point, shape
from shapely.strtree import STRtree

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "public"
OSM_FILE = Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/osm-fr-marketplaces.json")
EXISTING_FILE = Path(sys.argv[2] if len(sys.argv) > 2 else "/tmp/existing-fr-v139.json")
COMMUNES_FILE = Path(sys.argv[3] if len(sys.argv) > 3 else "/tmp/communes-france.geojson")
OUTPUT = PUBLIC / "markets-france-osm-v139.js"
DAYS = {"Mo":"lundi", "Tu":"mardi", "We":"mercredi", "Th":"jeudi", "Fr":"vendredi", "Sa":"samedi", "Su":"dimanche"}


def norm(value):
    import unicodedata
    return re.sub(r"[^a-z0-9]+", "", unicodedata.normalize("NFD", str(value or "").lower()).encode("ascii", "ignore").decode())


existing = json.loads(EXISTING_FILE.read_text())
grid = {}
known_names = set()
for row in existing:
    known_names.add((norm(row[2]), norm(row[3])))
    try:
        lat, lon = float(row[10]), float(row[11])
    except (TypeError, ValueError):
        continue
    grid.setdefault((round(lat * 100), round(lon * 100)), []).append((lat, lon))


def near_existing(lat, lon):
    x, y = round(lat * 100), round(lon * 100)
    for gx in range(x - 1, x + 2):
        for gy in range(y - 1, y + 2):
            for old_lat, old_lon in grid.get((gx, gy), []):
                # Environ 200 m : évite de dupliquer le même marché dessiné différemment.
                if abs(old_lat - lat) < 0.002 and abs(old_lon - lon) < 0.003:
                    return True
    return False


elements = []
for element in json.loads(OSM_FILE.read_text()).get("elements", []):
    center = element.get("center") or {}
    lat, lon = element.get("lat", center.get("lat")), element.get("lon", center.get("lon"))
    if lat is None or lon is None:
        continue
    lat, lon = float(lat), float(lon)
    if near_existing(lat, lon):
        continue
    elements.append((element, lat, lon))

commune_geojson = json.loads(COMMUNES_FILE.read_text())
commune_features = commune_geojson.get("features", [])
commune_shapes = [shape(feature["geometry"]) for feature in commune_features]
commune_tree = STRtree(commune_shapes)


def commune_for(item):
    element, lat, lon = item
    tags = element.get("tags") or {}
    city = tags.get("addr:city") or tags.get("contact:city")
    postal = tags.get("addr:postcode") or ""
    code = ""
    if not city:
        try:
            matches = commune_tree.query(Point(lon, lat), predicate="within")
            if len(matches):
                properties = commune_features[int(matches[0])].get("properties", {})
                city = properties.get("nom") or ""
                code = properties.get("code") or ""
        except Exception:
            pass
    return element, lat, lon, city or "Commune à vérifier", postal, code


resolved = [commune_for(item) for item in elements]


rows = []
seen = set()
for element, lat, lon, city, postal, code in resolved:
    tags = element.get("tags") or {}
    name = tags.get("name") or tags.get("official_name") or f"Marché de {city}"
    if (norm(name), norm(city)) in known_names:
        continue
    key = (norm(name), norm(city), round(lat, 4), round(lon, 4))
    if key in seen:
        continue
    seen.add(key)
    opening = tags.get("opening_hours") or ""
    found_days = []
    for token in re.findall(r"\b(?:Mo|Tu|We|Th|Fr|Sa|Su)\b", opening):
        if DAYS[token] not in found_days:
            found_days.append(DAYS[token])
    day = ", ".join(found_days) if found_days else "Jour à vérifier"
    hours_match = re.search(r"(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})", opening)
    hours = f"{hours_match.group(1)}h{hours_match.group(2)}-{hours_match.group(3)}h{hours_match.group(4)}" if hours_match else "Horaire à vérifier"
    street = " ".join(x for x in [tags.get("addr:housenumber", ""), tags.get("addr:street", "")] if x).strip()
    address = ", ".join(x for x in [street, postal, city] if x) or city
    if not code and postal:
        code = postal[:3] if postal.startswith(("971", "972", "973", "974", "976")) else postal[:2]
    department = code[:3] if code.startswith(("971", "972", "973", "974", "976")) else code[:2]
    osm_url = f"https://www.openstreetmap.org/{element.get('type','node')}/{element.get('id')}"
    note = "Emplacement trouvé dans la cartographie nationale OpenStreetMap. Jour et horaire marqués à vérifier lorsqu’ils ne sont pas publiés."
    rows.append([department or "À vérifier", "marche", name, city, day, hours, note, "Nombre de places à vérifier", address, [osm_url], lat, lon, "Tirage au sort à vérifier", "Contacter la mairie ou le placier"])

OUTPUT.write_text("window.data=Array.isArray(window.data)?window.data:[];window.data.push(..." + json.dumps(rows, ensure_ascii=False, separators=(",", ":")) + ");\n", encoding="utf-8")
print(json.dumps({"osm_candidates": len(elements), "added": len(rows), "output": str(OUTPUT)}, ensure_ascii=False))
