COUTEAU SUISSE — V300 — CONCOURS AUTOMATIQUE + CONTRÔLE ADMIN + GASOIL PARTOUT

1. Fiches terrain : points immédiats
- Marchés hebdomadaires, brocantes, marchés de Noël, saisonniers, voyageurs et autres fiches utilisant la vérification marché : points ajoutés automatiquement dès l’enregistrement valide.
- Champignons : +50 points de fiche + points du trajet aller/gasoil ajoutés automatiquement.
- Les anciens formulaires encore en attente sont rattrapés automatiquement une seule fois, avec anti-doublon.

2. Gasoil
- Même logique de trajet aller pour les fiches marché/événement et Champignons.
- La bulle participant affiche : kilomètres, litres utilisés, coût total du gasoil et points déplacement.
- Le prix au litre reste interne et n’est pas affiché dans la bulle.

3. Contrôle administrateur après attribution
- Chaque fiche reste visible dans Administration avec le nom de la personne.
- OUI : la fiche passe validée, les points déjà gagnés restent acquis et l’utilisateur reçoit « L’administrateur a validé ».
- NON : les points de cette fiche sont retirés du classement et l’utilisateur reçoit le refus.
- Bug / problème et idée : restent les seuls gains qui attendent la validation administrateur avant attribution du gain/bonus.

4. Interface concours
- Boutons BONUS, POINTS, CAMPING, BUG / IDÉE et RÈGLES agrandis, notamment sur téléphone.
- Règles et textes Champignons mis à jour pour expliquer le fonctionnement automatique.

5. Notifications admin
- Les nouvelles fiches restent regroupées par nom dans Administration.
- Quand l’application administrateur est ouverte, le compteur est actualisé automatiquement et la notification locale indique le nom de la dernière personne.
- Le push de fond reste le réveil générique qui ouvre directement les demandes à contrôler.

6. Cache
- Invalidation ciblée : modules Concours, Administration, Champignons et le petit module d’affichage du compteur administrateur.
- Les adresses, devis, photos, GPS mémorisés, abonnements et autres données utilisateur ne sont pas supprimés.
