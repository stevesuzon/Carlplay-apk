V268 — WORKERS AI + VIDÉO → SITE

- Base : V267 complète.
- Ajout de wrangler.jsonc dans le ZIP avec toutes les liaisons connues et conservées :
  • ASSETS -> ./public
  • D1 binding DB -> carplay-metiers
  • R2 binding MARKET_PHOTOS -> carplay-market-photos
  • Workers AI binding AI
- Le but est d’éviter que la liaison Workers AI disparaisse lors d’un nouveau déploiement basé sur cette configuration.
- Après la vidéo, le bouton devient « ALLER SUR LE SITE » et ouvre /index.html (avec le parrainage conservé si présent).
- Cache passé en V268.
