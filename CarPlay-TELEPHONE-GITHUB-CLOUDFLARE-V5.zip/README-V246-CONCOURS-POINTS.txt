V246 — FIABILISATION DES POINTS DU CONCOURS

- Toutes les catégories affichées restent attribuées au joueur après les validations prévues.
- Un bonus actif multiplie désormais tous les nouveaux points : fiches, déplacements, bugs/problèmes et parrainages.
- Le bonus d'un trajet aller supérieur à 150 km démarre seulement après l'accord de l'administrateur.
- Les points de parrainage sont visibles séparément dans « Mes points » et restent inclus dans le total et le classement.
- La protection contre le double crédit d'une même action reste active.
- L'accès gratuit du concours reste valable jusqu'à la fin du concours plus 5 jours.
- Les routes, noms de bindings, tables D1 et liaisons Cloudflare existants n'ont pas été renommés.

IMPORTANT POUR LES PROCHAINES VERSIONS

Toujours repartir de cette version ou d'une version plus récente. Ne jamais remplacer src/index.js,
la base D1, les routes /api existantes ni les noms des bindings Cloudflare par ceux d'un ancien ZIP.
