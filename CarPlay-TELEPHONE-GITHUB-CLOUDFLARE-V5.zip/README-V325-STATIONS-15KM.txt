COUTEAU SUISSE — V325 — STATIONS CARBURANT ≤ 15 KM

Ajouts :
- petit bouton « ⛽ 15 KM » à côté du compteur des utilisateurs connectés ;
- ouverture automatique d’une page Stations avec géolocalisation du téléphone ;
- rayon maximum : 15 km ;
- choix carburant : Gazole, E10, SP95, SP98, E85, GPLc ;
- tri du prix le moins cher au plus cher ;
- distance à vol d’oiseau calculée depuis le GPS actuel ;
- affichage ouvert / fermé d’après les horaires publiés ;
- si automate CB déclaré : affichage « Carte 24/24 » ;
- détection « Boutique » lorsque la source publie « Boutique alimentaire » ;
- liste détaillée des services ;
- bouton ALLER À LA STATION utilisant le GPS préféré (Waze / Google Maps / Plans Apple) ;
- source serveur : jeu officiel français « Prix des carburants en France - Flux instantané - v2 » ;
- endpoint Worker /api/fuel-stations avec rayon serveur limité à 15 km ;
- données de paiement espèces non inventées : affichage « à vérifier » si non publié.

Note : le jeu officiel fournit les stations et prix français. Le paiement en espèces et l’enseigne commerciale ne sont pas systématiquement présents dans la source officielle.
