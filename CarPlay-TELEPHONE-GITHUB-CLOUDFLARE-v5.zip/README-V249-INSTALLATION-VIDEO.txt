COUTEAU SUISSE — V249

Modification :
- À la fin de la vidéo, plus de redirection automatique.
- Un bouton jaune « INSTALLER L’APPLICATION » apparaît.
- Ce bouton ouvre /index.html et conserve le code de parrainage ref s’il existe.
- La V248 Champignons reste incluse.
- Cache PWA renouvelé en V249 pour forcer la mise à jour.
