(function () {
  if ("serviceWorker" in navigator) addEventListener("load", function () { navigator.serviceWorker.register("/sw.js").catch(function () {}); });
  var KEY = "carplay_shared_subscription";

  function id() {
    var v = localStorage.getItem("carplay_device_id");
    if (!v) {
      v = crypto.randomUUID ? crypto.randomUUID() : "dev-" + Date.now() + "-" + Math.random().toString(36).slice(2);
      localStorage.setItem("carplay_device_id", v);
    }
    return v;
  }

  function saved() { try { return JSON.parse(localStorage.getItem(KEY) || "null"); } catch (_) { return null; } }
  function valid(s) { return s && (s.lifetime || (s.expiresAt && Date.parse(s.expiresAt) > Date.now())); }
  function detectedType() { return /Android/i.test(navigator.userAgent) && Math.min(screen.width, screen.height) >= 600 ? "autoradio" : "phone"; }
  function messageFor(e) {
    if (e && e.error === "ABONNEMENT_EXPIRE") return "ABONNEMENT EXPIRÉ";
    if (e && e.error && e.error.indexOf("DEJA_UTILISE") > -1) return "CET EMPLACEMENT EST DÉJÀ UTILISÉ";
    return "CODE INCORRECT OU INTERNET INDISPONIBLE";
  }

  function activate(code, deviceType, done, failed) {
    fetch("/api/activate", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ code: code, deviceId: id(), deviceType: deviceType })
    }).then(function (r) {
      return r.json().then(function (j) { if (!r.ok) throw j; return j; });
    }).then(function (j) {
      j.code = code;
      localStorage.setItem(KEY, JSON.stringify(j));
      done(j);
    }).catch(failed);
  }

  function overlay() {
    if (document.getElementById("subscriptionGate")) return;
    var box = document.createElement("div");
    box.id = "subscriptionGate";
    box.innerHTML = '<div class="sub-card"><h1>APPLICATION BLOQUÉE</h1><p>Entrez votre abonnement à 6 chiffres pour continuer.</p><input id="subCode" inputmode="numeric" maxlength="6" placeholder="000 000"><div class="sub-types"><button data-type="autoradio">AUTORADIO / TABLETTE</button><button data-type="phone">TÉLÉPHONE</button></div><button id="subActivate">ACTIVER MON ABONNEMENT</button><div id="subMessage"></div><small>Le même code active 1 autoradio ou tablette + 1 téléphone Android ou iPhone.</small></div>';
    document.documentElement.appendChild(box);
    document.documentElement.classList.add("sub-ready");
    var deviceType = detectedType();
    box.querySelectorAll("[data-type]").forEach(function (b) {
      b.onclick = function () {
        deviceType = b.dataset.type;
        box.querySelectorAll("[data-type]").forEach(function (x) { x.classList.toggle("chosen", x === b); });
      };
      if (b.dataset.type === deviceType) b.classList.add("chosen");
    });
    box.querySelector("#subActivate").onclick = function () {
      var code = box.querySelector("#subCode").value.replace(/\D/g, "");
      var msg = box.querySelector("#subMessage");
      if (code.length !== 6) { msg.textContent = "ENTREZ EXACTEMENT 6 CHIFFRES"; return; }
      msg.textContent = "VÉRIFICATION…";
      activate(code, deviceType, function () {
        msg.textContent = "ABONNEMENT ACTIVÉ";
        setTimeout(function () { location.reload(); }, 600);
      }, function (e) { msg.textContent = messageFor(e); });
    };
  }

  function settingsPanel() {
    var settings = document.getElementById("settings");
    if (!settings || document.getElementById("subscriptionSettings")) return;
    var panel = document.createElement("div");
    panel.className = "settingRow";
    panel.id = "subscriptionSettings";
    var s = saved();
    var status = valid(s) ? (s.lifetime ? "ACTIF À VIE" : "ACTIF JUSQU’AU " + new Date(s.expiresAt).toLocaleDateString("fr-FR")) : "NON ACTIVÉ";
    panel.innerHTML = '<div class="settingHead"><span>🔐 ABONNEMENT</span><span>⌄</span></div><div class="settingBody"><div class="sub-settings"><div class="sub-settings-status">' + status + '</div><input inputmode="numeric" maxlength="6" placeholder="CODE À 6 CHIFFRES"><button>ACTIVER / CHANGER LE CODE</button><div class="sub-settings-message"></div></div></div>';
    var firstSetting = settings.querySelector(".settingRow");
    if (firstSetting) settings.insertBefore(panel, firstSetting); else settings.appendChild(panel);
    panel.querySelector(".settingHead").onclick = function () {
      var body = panel.querySelector(".settingBody");
      body.classList.toggle("open");
    };
    panel.querySelector("button").onclick = function () {
      var code = panel.querySelector("input").value.replace(/\D/g, "");
      var msg = panel.querySelector(".sub-settings-message");
      if (code.length !== 6) { msg.textContent = "Entrez exactement 6 chiffres."; return; }
      msg.textContent = "Vérification…";
      activate(code, detectedType(), function () { msg.textContent = "Abonnement activé."; setTimeout(function () { location.reload(); }, 600); }, function (e) { msg.textContent = messageFor(e); });
    };
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (!valid(saved())) overlay();
    else document.documentElement.classList.add("sub-ready");
    settingsPanel();
  });
})();
